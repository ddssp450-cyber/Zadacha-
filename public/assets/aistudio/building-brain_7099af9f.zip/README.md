# BUILDING BRAIN

Една сграда. Един календар. Един интелигентен асистент.

Next.js 15 + TypeScript + Tailwind 4, Supabase (Postgres + auth + private storage, run locally in Docker), Google Gemini for AI.

## Run

```bash
npx supabase start          # Docker must be running
npx supabase db reset       # schema + demo building
# create .env.local (below), then:
npm run dev                 # http://localhost:3000
npm test                    # logic self-checks
```

`.env.local` (create it yourself; never commit it):

```
NEXT_PUBLIC_SUPABASE_URL=http://127.0.0.1:54321
NEXT_PUBLIC_SUPABASE_ANON_KEY=<"anon"/"publishable" key from: npx supabase status>
GEMINI_API_KEY=<your Gemini key>
# GEMINI_MODEL=gemini-flash-latest   (optional)
```

Sign in with a demo email, e.g. `owner@demo.bg`, `tenant@demo.bg`, `builder@demo.bg`, `tech@demo.bg`. The 6-digit code arrives in the local inbox at http://127.0.0.1:54324.

## Where things are

- `supabase/migrations/…_init.sql` — tables, row-level security per role, payment RPCs, storage policies. Access is enforced here.
- `supabase/seed.sql` — synthetic demo building (ул. Кожух 12).
- `lib/vocab.ts` — the one status vocabulary (payments, repairs, events) and formatting.
- `lib/brief.ts` — the deterministic "today" list per role; AI only words it (`lib/ai/prose.ts`).
- `lib/ai/tools.ts` — assistant tools. Read tools query as the user (RLS applies); write tools only create proposals.
- `app/api/chat` — Gemini function-calling loop; `app/api/chat/confirm` runs a proposal after the user presses „Потвърди“.
- `app/api/extract` — reads amount/date/reference from a payment proof; never confirms anything.

## Rules the AI follows

- Every fact comes from a tool call on stored data; no invented numbers or actions.
- Payments confirmations, expense approvals, reminders to many tenants and calendar entries are proposals until the user confirms.
