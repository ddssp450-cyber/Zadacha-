// One closed state vocabulary, used identically on every screen and by the assistant.

export type Role = "owner" | "tenant" | "builder" | "technician";
export const ROLE: Record<Role, string> = {
  owner: "Собственик",
  tenant: "Наемател",
  builder: "Строител",
  technician: "Майстор",
};

export type Tone = "ok" | "wait" | "bad" | "idle" | "info";

export type PayStatus = "unpaid" | "declared" | "pending_review" | "confirmed" | "partial" | "overdue";
export const PAY: Record<PayStatus, { label: string; short: string; tone: Tone }> = {
  unpaid: { label: "Неплатено", short: "неплатено", tone: "idle" },
  declared: { label: "Декларирано платено", short: "декларирано", tone: "wait" },
  pending_review: { label: "Чака потвърждение", short: "за проверка", tone: "wait" },
  confirmed: { label: "Платено — потвърдено", short: "платено", tone: "ok" },
  partial: { label: "Частично платено", short: "частично", tone: "wait" },
  overdue: { label: "Просрочено", short: "просрочено", tone: "bad" },
};

export type RepairStatus = "new" | "approved" | "scheduled" | "in_progress" | "done" | "rejected";
export const REPAIR: Record<RepairStatus, { label: string; tone: Tone }> = {
  new: { label: "Нова", tone: "wait" },
  approved: { label: "Одобрена", tone: "info" },
  scheduled: { label: "Насрочена", tone: "info" },
  in_progress: { label: "В процес", tone: "info" },
  done: { label: "Приключена", tone: "ok" },
  rejected: { label: "Отхвърлена", tone: "idle" },
};

export const EVENT_KIND: Record<string, string> = {
  repair: "Ремонт",
  construction: "Строителство",
  viewing: "Оглед",
  maintenance: "Профилактика",
  cleaning: "Почистване",
  inspection: "Проверка",
  meeting: "Среща",
  other: "Друго",
};

export const EVENT_STATUS: Record<string, { label: string; tone: Tone }> = {
  proposed: { label: "Предложено", tone: "wait" },
  planned: { label: "Планирано", tone: "info" },
  done: { label: "Изпълнено", tone: "ok" },
  cancelled: { label: "Отменено", tone: "idle" },
};

export const RECURRENCE: Record<string, string> = { none: "Еднократно", weekly: "Всяка седмица", monthly: "Всеки месец", yearly: "Всяка година" };

export const APPLIANCE_KIND: Record<string, string> = {
  ac: "Климатик",
  boiler: "Бойлер",
  elevator: "Асансьор",
  pump: "Помпа",
  heating: "Отопление",
  kitchen: "Кухненски уред",
  other: "Друго",
};

export const EXPENSE_CATEGORY: Record<string, string> = {
  repair: "Ремонти",
  maintenance: "Поддръжка",
  cleaning: "Почистване",
  utilities: "Комунални",
  construction: "Строителство",
  other: "Друго",
};

export const TZ = "Europe/Sofia";

/** YYYY-MM-DD in Sofia time. */
export function isoDay(d: Date = new Date()) {
  return d.toLocaleDateString("sv-SE", { timeZone: TZ });
}

/** Overdue is derived, never stored: unpaid or partial past the due date. */
export function payStatus(p: { status: PayStatus; due_date: string }, today = isoDay()): PayStatus {
  if ((p.status === "unpaid" || p.status === "partial") && p.due_date < today) return "overdue";
  return p.status;
}

const money = new Intl.NumberFormat("bg-BG", { style: "currency", currency: "EUR", maximumFractionDigits: 2 });
export const eur = (n: number | string | null | undefined) => money.format(Number(n ?? 0));

export const fmtDate = (d: string | Date, opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" }) =>
  new Date(d).toLocaleDateString("bg-BG", { timeZone: TZ, ...opts });

export const fmtTime = (d: string | Date) =>
  new Date(d).toLocaleTimeString("bg-BG", { timeZone: TZ, hour: "2-digit", minute: "2-digit" });

export function daysBetween(a: string, b: string) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);
}
