import { test } from "node:test";
import assert from "node:assert/strict";
import { expand, monthGrid } from "./calendar";
import { payStatus } from "./vocab";

const ev = (over: Partial<Parameters<typeof expand>[0][0]>) => ({
  id: "e", title: "t", kind: "cleaning", starts_at: "2026-10-06T07:00:00Z", ends_at: "2026-10-06T09:00:00Z",
  status: "planned", recurrence: "none", unit_id: null, repair_id: null, assignee_id: null, description: "", ...over,
});

test("weekly event repeats inside the window only", () => {
  const items = expand([ev({ recurrence: "weekly" })], new Date("2026-10-10T00:00:00Z"), new Date("2026-11-01T00:00:00Z"));
  assert.deepEqual(items.map((i) => i.day), ["2026-10-13", "2026-10-20", "2026-10-27"]);
  assert.equal(items[0].end!.getTime() - items[0].start.getTime(), 2 * 3600_000);
});

test("one-off event outside the window is skipped", () => {
  assert.equal(expand([ev({})], new Date("2026-10-07T00:00:00Z"), new Date("2026-10-30T00:00:00Z")).length, 0);
  assert.equal(expand([ev({})], new Date("2026-10-01T00:00:00Z"), new Date("2026-10-30T00:00:00Z")).length, 1);
});

test("month grid starts on Monday and covers six weeks", () => {
  const g = monthGrid(new Date("2026-10-15T00:00:00Z"));
  assert.equal(g.length, 42);
  assert.equal(g[0], "2026-09-28");
  assert.ok(g.includes("2026-10-31"));
});

test("overdue is derived from due date", () => {
  assert.equal(payStatus({ status: "unpaid", due_date: "2026-10-01" }, "2026-10-24"), "overdue");
  assert.equal(payStatus({ status: "partial", due_date: "2026-10-01" }, "2026-10-24"), "overdue");
  assert.equal(payStatus({ status: "declared", due_date: "2026-10-01" }, "2026-10-24"), "declared");
  assert.equal(payStatus({ status: "unpaid", due_date: "2026-10-30" }, "2026-10-24"), "unpaid");
});
