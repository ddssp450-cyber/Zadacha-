import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "./supabase";
import type { Role } from "./vocab";

export type Profile = { id: string; email: string; full_name: string; role: Role; phone: string | null };
export type Building = { id: string; name: string; address: string; owner_id: string };

export const me = cache(async () => {
  const supabase = await db();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login");
  const [{ data: profile }, { data: buildings }] = await Promise.all([
    supabase.from("profiles").select("id, email, full_name, role, phone").eq("id", auth.user.id).single<Profile>(),
    supabase.from("buildings").select("id, name, address, owner_id").order("created_at").returns<Building[]>(),
  ]);
  if (!profile) redirect("/login");
  const list = buildings ?? [];
  const chosen = (await cookies()).get("bb")?.value;
  const building = list.find((b) => b.id === chosen) ?? list[0] ?? null;
  return { supabase, profile, buildings: list, building, isOwner: profile.role === "owner" };
});

/** Pages that need a building; owners without one are sent to create it. */
export async function meWithBuilding() {
  const ctx = await me();
  if (!ctx.building) redirect("/buildings");
  return { ...ctx, building: ctx.building };
}
