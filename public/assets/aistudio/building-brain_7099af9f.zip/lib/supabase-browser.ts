"use client";
import { createBrowserClient } from "@supabase/ssr";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "http://127.0.0.1:54321";
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const browserDb = () => createBrowserClient(url, anon);

// Files go straight to the private bucket under the building folder; storage RLS checks access.
export async function uploadFile(buildingId: string, file: File) {
  const safe = file.name.normalize("NFKD").replace(/[^\w.-]+/g, "_").slice(-80);
  const path = `${buildingId}/${crypto.randomUUID()}-${safe}`;
  const { error } = await browserDb().storage.from("files").upload(path, file, { contentType: file.type });
  if (error) throw new Error(error.message);
  return path;
}
