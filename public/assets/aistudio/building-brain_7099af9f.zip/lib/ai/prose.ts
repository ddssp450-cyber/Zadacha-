import { aiEnabled, generate, textOf } from "./gemini";
import type { Brief } from "../brief";
import { ROLE, type Role } from "../vocab";

const cache = new Map<string, { at: number; text: string }>();

/** Two or three sentences over the already-computed brief. It may only restate what is in the list. */
export async function briefProse(userId: string, role: Role, name: string, brief: Brief): Promise<string | null> {
  if (!aiEnabled() || brief.items.length === 0) return null;
  const facts = JSON.stringify({ items: brief.items.map((i) => ({ tone: i.tone, text: i.text })), stats: brief.stats });
  const key = `${userId}:${facts}`;
  const hit = cache.get(key);
  // shortcut: in-memory cache per server process, fine for one instance; move to a table when deployed to many.
  if (hit && Date.now() - hit.at < 15 * 60_000) return hit.text;
  const res = await generate({
    system:
      "Ти си асистентът на Building Brain. Пишеш кратко дневно обобщение на български за човека с роля " +
      ROLE[role] + ". Използвай САМО фактите от JSON. Не добавяй числа, имена или събития, които ги няма. " +
      "2–3 изречения, най-важното първо (просрочено, чакащо потвърждение), без поздрав, без списъци, без markdown.",
    contents: [{ role: "user", parts: [{ text: `Име: ${name}\nФакти: ${facts}` }] }],
  });
  const text = textOf(res);
  cache.set(key, { at: Date.now(), text });
  return text;
}
