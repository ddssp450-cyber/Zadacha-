import type { DB } from "../supabase";
import type { Building, Profile } from "../session";
import type { FunctionDecl } from "./gemini";
import { expand, type CalEvent } from "../calendar";
import { APPLIANCE_KIND, EVENT_KIND, EXPENSE_CATEGORY, isoDay, PAY, payStatus, REPAIR, type PayStatus, type RepairStatus } from "../vocab";

export type Ctx = { supabase: DB; profile: Profile; building: Building };
export type Proposal = { id: string; type: "event" | "repair" | "payment_review" | "reminders"; summary: string; args: Record<string, unknown> };

const str = { type: "string" };
const date = { type: "string", description: "YYYY-MM-DD" };

export const READ_TOOLS: FunctionDecl[] = [
  { name: "list_units", description: "Апартаментите в сградата: етаж, номер, наемател." },
  {
    name: "list_payments",
    description: "Задължения за наем и сметки. Статусите: unpaid, declared, pending_review, confirmed, partial, overdue (просрочено се изчислява от срока).",
    parameters: { type: "object", properties: { status: { type: "string", enum: Object.keys(PAY) }, unit_number: str, period: { type: "string", description: "YYYY-MM" } } },
  },
  {
    name: "list_repairs",
    description: "Ремонтни заявки и строителни дефекти с номер, статус, локация, етаж, срок, бюджет и разход.",
    parameters: { type: "object", properties: { status: { type: "string", enum: Object.keys(REPAIR) }, kind: { type: "string", enum: ["repair", "defect"] }, floor: { type: "integer" }, open_only: { type: "boolean" } } },
  },
  {
    name: "list_events",
    description: "Събития и задачи в календара (повтарящите се са разгънати), плюс крайни срокове на плащания. Включва просрочени задачи.",
    parameters: { type: "object", properties: { from: date, to: date, overdue_only: { type: "boolean" } }, required: ["from", "to"] },
  },
  {
    name: "find_free_slots",
    description: "Свободни интервали между събитията в календара на сградата (пон–съб).",
    parameters: { type: "object", properties: { from: date, to: date, duration_minutes: { type: "integer" }, day_start: { type: "string", description: "HH:MM" }, day_end: { type: "string", description: "HH:MM" } }, required: ["from", "to"] },
  },
  {
    name: "spending",
    description: "Разходи за период: общо, по категория и по ремонт.",
    parameters: { type: "object", properties: { from: date, to: date, category: { type: "string", enum: Object.keys(EXPENSE_CATEGORY) } } },
  },
  { name: "list_appliances", description: "Уредите: вид, модел, апартамент, гаранция, следваща профилактика.", parameters: { type: "object", properties: { kind: { type: "string", enum: Object.keys(APPLIANCE_KIND) } } } },
];

const PROPOSE_EVENT: FunctionDecl = {
  name: "propose_event",
  description: "Предлага събитие/задача за календара. НЕ записва — потребителят потвърждава с бутон. Извикай веднъж за всяко събитие.",
  parameters: {
    type: "object",
    properties: {
      title: str, kind: { type: "string", enum: Object.keys(EVENT_KIND) }, date, time: { type: "string", description: "HH:MM" },
      end_time: { type: "string", description: "HH:MM" }, unit_number: str, recurrence: { type: "string", enum: ["none", "weekly", "monthly", "yearly"] },
      description: str, repair_code: { type: "string", description: "напр. Р-0002, ако е посещение по ремонт" },
    },
    required: ["title", "kind", "date", "time"],
  },
};
const PROPOSE_REPAIR: FunctionDecl = {
  name: "propose_repair",
  description: "Предлага нова ремонтна заявка (или дефект за строител). Прикачените снимки от съобщението се добавят автоматично. НЕ записва без потвърждение.",
  parameters: { type: "object", properties: { title: str, description: str, location: str, unit_number: str }, required: ["title", "description"] },
};
const PROPOSE_REVIEW: FunctionDecl = {
  name: "propose_payment_review",
  description: "Предлага потвърждаване или отхвърляне на декларирано плащане. Никога не потвърждавай сам — само предлагаш.",
  parameters: { type: "object", properties: { payment_id: str, approve: { type: "boolean" }, note: str }, required: ["payment_id", "approve"] },
};
const PROPOSE_REMINDERS: FunctionDecl = {
  name: "propose_reminders",
  description: "Предлага напомняния до наемателите за посочените задължения (масово съобщение — изисква потвърждение).",
  parameters: { type: "object", properties: { payment_ids: { type: "array", items: str } }, required: ["payment_ids"] },
};

export function toolsFor(role: Profile["role"]): FunctionDecl[] {
  if (role === "owner") return [...READ_TOOLS, PROPOSE_EVENT, PROPOSE_REPAIR, PROPOSE_REVIEW, PROPOSE_REMINDERS];
  if (role === "technician") return [...READ_TOOLS, PROPOSE_EVENT];
  return [...READ_TOOLS, PROPOSE_REPAIR];
}

type Args = Record<string, unknown>;
const a = (x: Args, k: string) => (x[k] == null || x[k] === "" ? undefined : String(x[k]));

export async function runTool(ctx: Ctx, name: string, args: Args, proposals: Proposal[], photoPaths: string[]): Promise<unknown> {
  const { supabase, building, profile } = ctx;
  const b = building.id;
  const today = isoDay();

  switch (name) {
    case "list_units": {
      const { data } = await supabase.from("units").select("number, floor, entrance, area, profiles(full_name)").eq("building_id", b).order("floor");
      return { units: (data ?? []).map((u) => ({ ap: u.number, floor: u.floor, entrance: u.entrance, tenant: (u.profiles as unknown as { full_name: string } | null)?.full_name ?? "свободен" })) };
    }
    case "list_payments": {
      let q = supabase.from("payments").select("id, title, kind, amount, paid_amount, period, due_date, status, review_note, proof_extracted, units!inner(number), profiles(full_name)").eq("building_id", b).order("due_date");
      if (a(args, "unit_number")) q = q.eq("units.number", a(args, "unit_number")!);
      if (a(args, "period")) q = q.eq("period", a(args, "period")!);
      const { data, error } = await q;
      if (error) return { error: error.message };
      const rows = (data ?? []).map((p) => {
        const st = payStatus(p as { status: PayStatus; due_date: string }, today);
        return {
          id: p.id, ap: (p.units as unknown as { number: string }).number, tenant: (p.profiles as unknown as { full_name: string } | null)?.full_name ?? null,
          title: p.title, amount_eur: Number(p.amount), paid_eur: Number(p.paid_amount), due: p.due_date, status: st, status_bg: PAY[st].label,
          owner_note: p.review_note, extracted_from_proof: p.proof_extracted,
        };
      });
      return { payments: a(args, "status") ? rows.filter((r) => r.status === a(args, "status")) : rows };
    }
    case "list_repairs": {
      let q = supabase.from("repairs").select("id, code, kind, title, description, location, status, due_date, budget, cost, created_at, resolved_at, units(number, floor), assignee:profiles!repairs_assignee_id_fkey(full_name)").eq("building_id", b).order("created_at", { ascending: false });
      if (a(args, "status")) q = q.eq("status", a(args, "status")!);
      if (a(args, "kind")) q = q.eq("kind", a(args, "kind")!);
      if (args.open_only) q = q.not("status", "in", "(done,rejected)");
      const { data, error } = await q;
      if (error) return { error: error.message };
      let rows = (data ?? []).map((r) => {
        const u = r.units as unknown as { number: string; floor: number } | null;
        return {
          code: r.code, kind: r.kind, title: r.title, description: r.description, location: r.location, ap: u?.number ?? null, floor: u?.floor ?? null,
          status: REPAIR[r.status as RepairStatus].label, due: r.due_date, budget_eur: r.budget, cost_eur: r.cost,
          assignee: (r.assignee as unknown as { full_name: string } | null)?.full_name ?? null, reported: r.created_at.slice(0, 10), link: `/repairs/${r.id}`,
        };
      });
      const floor = args.floor == null ? null : Number(args.floor);
      if (floor != null) rows = rows.filter((r) => r.floor === floor || r.location.includes(`ет. ${floor}`) || r.location.includes(`${floor}`));
      return { repairs: rows };
    }
    case "list_events": {
      const from = new Date(`${a(args, "from") ?? today}T00:00:00`);
      const to = new Date(`${a(args, "to") ?? today}T23:59:59`);
      const { data } = await supabase.from("events").select("*").eq("building_id", b).neq("status", "cancelled");
      const now = new Date();
      let items = expand((data ?? []) as CalEvent[], from, to).map((i) => ({
        title: i.title, kind: EVENT_KIND[i.kind] ?? i.kind, day: i.day,
        start: i.start.toLocaleTimeString("bg-BG", { timeZone: "Europe/Sofia", hour: "2-digit", minute: "2-digit" }),
        status: i.status, overdue: i.status === "planned" && i.start < now && i.event?.recurrence === "none",
      }));
      if (args.overdue_only) items = items.filter((i) => i.overdue);
      const { data: dues } = profile.role === "owner" || profile.role === "tenant"
        ? await supabase.from("payments").select("title, due_date, status, units(number)").eq("building_id", b).gte("due_date", a(args, "from") ?? today).lte("due_date", a(args, "to") ?? today).not("status", "eq", "confirmed")
        : { data: [] };
      return { events: items, payment_deadlines: (dues ?? []).map((d) => ({ title: d.title, ap: (d.units as unknown as { number: string } | null)?.number, due: d.due_date })) };
    }
    case "find_free_slots": {
      const dur = Number(args.duration_minutes ?? 60) * 60_000;
      const [sh, sm] = (a(args, "day_start") ?? "09:00").split(":").map(Number);
      const [eh, em] = (a(args, "day_end") ?? "18:00").split(":").map(Number);
      const from = new Date(`${a(args, "from")}T00:00:00`);
      const to = new Date(`${a(args, "to")}T23:59:59`);
      const { data } = await supabase.from("events").select("*").eq("building_id", b).in("status", ["planned", "proposed"]);
      const busy = expand((data ?? []) as CalEvent[], from, to).map((i) => [i.start.getTime(), (i.end ?? new Date(i.start.getTime() + 3600_000)).getTime()]);
      const slots: string[] = [];
      for (let d = new Date(from); d <= to && slots.length < 12; d.setDate(d.getDate() + 1)) {
        if (d.getDay() === 0) continue;
        const dayStart = new Date(d); dayStart.setHours(sh, sm, 0, 0);
        const dayEnd = new Date(d); dayEnd.setHours(eh, em, 0, 0);
        for (let t = Math.max(dayStart.getTime(), Date.now()); t + dur <= dayEnd.getTime(); t += 30 * 60_000) {
          if (busy.some(([s, e]) => t < e && t + dur > s)) continue;
          slots.push(`${isoDay(new Date(t))} ${new Date(t).toLocaleTimeString("bg-BG", { hour: "2-digit", minute: "2-digit" })}`);
          t += dur - 30 * 60_000;
          if (slots.length >= 12) break;
        }
      }
      return { free_slots: slots, busy_count: busy.length };
    }
    case "spending": {
      let q = supabase.from("expenses").select("amount, category, spent_on, note, repairs(code, title)").eq("building_id", b);
      if (a(args, "from")) q = q.gte("spent_on", a(args, "from")!);
      if (a(args, "to")) q = q.lte("spent_on", a(args, "to")!);
      if (a(args, "category")) q = q.eq("category", a(args, "category")!);
      const { data, error } = await q;
      if (error) return { error: error.message, note: "Само собственикът вижда разходите." };
      const by: Record<string, number> = {};
      let total = 0;
      for (const e of data ?? []) {
        total += Number(e.amount);
        const k = EXPENSE_CATEGORY[e.category] ?? e.category;
        by[k] = (by[k] ?? 0) + Number(e.amount);
      }
      return { total_eur: Math.round(total * 100) / 100, by_category_eur: by, items: (data ?? []).map((e) => ({ amount_eur: Number(e.amount), date: e.spent_on, note: e.note })) };
    }
    case "list_appliances": {
      let q = supabase.from("appliances").select("name, kind, model, warranty_until, next_service, notes, units(number)").eq("building_id", b);
      if (a(args, "kind")) q = q.eq("kind", a(args, "kind")!);
      const { data } = await q;
      return { appliances: (data ?? []).map((x) => ({ ...x, kind: APPLIANCE_KIND[x.kind] ?? x.kind, ap: (x.units as unknown as { number: string } | null)?.number ?? "общи части", units: undefined })) };
    }
    case "propose_event": {
      const summary = `${a(args, "title")} · ${a(args, "date")} ${a(args, "time")}${a(args, "end_time") ? `–${a(args, "end_time")}` : ""}${a(args, "unit_number") ? ` · ап. ${a(args, "unit_number")}` : ""}${args.recurrence && args.recurrence !== "none" ? ` · ${args.recurrence === "weekly" ? "седмично" : args.recurrence === "monthly" ? "месечно" : "годишно"}` : ""}`;
      proposals.push({ id: crypto.randomUUID(), type: "event", summary, args });
      return { status: "proposed_awaiting_user_confirmation" };
    }
    case "propose_repair": {
      proposals.push({ id: crypto.randomUUID(), type: "repair", summary: `${a(args, "title")}${a(args, "location") ? ` · ${a(args, "location")}` : ""}${photoPaths.length ? ` · ${photoPaths.length} снимки` : ""}`, args: { ...args, paths: photoPaths } });
      return { status: "proposed_awaiting_user_confirmation" };
    }
    case "propose_payment_review": {
      const { data: p } = await supabase.from("payments").select("id, title, paid_amount, units(number)").eq("id", a(args, "payment_id") ?? "").maybeSingle();
      if (!p) return { error: "Няма такова плащане. Вземи id от list_payments." };
      proposals.push({ id: crypto.randomUUID(), type: "payment_review", summary: `${args.approve ? "Потвърди" : "Отхвърли"}: ${p.title}, ап. ${(p.units as unknown as { number: string }).number}, ${p.paid_amount} €`, args });
      return { status: "proposed_awaiting_user_confirmation" };
    }
    case "propose_reminders": {
      const ids = (args.payment_ids as string[] | undefined) ?? [];
      if (!ids.length) return { error: "Няма посочени плащания." };
      proposals.push({ id: crypto.randomUUID(), type: "reminders", summary: `Напомняне до ${ids.length} наематели`, args: { payment_ids: ids } });
      return { status: "proposed_awaiting_user_confirmation" };
    }
  }
  return { error: `Непознат инструмент ${name}` };
}
