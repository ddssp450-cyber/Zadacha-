// Gemini over plain REST: no SDK. The key is not NEXT_PUBLIC, so it never reaches the browser.
export type Part =
  | { text: string; thought?: boolean; thoughtSignature?: string }
  | { inlineData: { mimeType: string; data: string } }
  | { functionCall: { name: string; args: Record<string, unknown> }; thoughtSignature?: string }
  | { functionResponse: { name: string; response: Record<string, unknown> } };
export type Content = { role: "user" | "model"; parts: Part[] };
export type FunctionDecl = { name: string; description: string; parameters?: Record<string, unknown> };

const MODEL = process.env.GEMINI_MODEL || "gemini-flash-latest";
const KEY = process.env.GEMINI_API_KEY || "";

const ENDPOINTS = [
  (m: string) => `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent`,
  // Vertex AI express-mode keys use this host with the same request body.
  (m: string) => `https://aiplatform.googleapis.com/v1/publishers/google/models/${m}:generateContent`,
];
let working: number | null = null;

export const aiEnabled = () => KEY.length > 0;

export class AiError extends Error {}

export async function generate(body: {
  system?: string;
  contents: Content[];
  tools?: FunctionDecl[];
  json?: boolean;
}): Promise<Content> {
  if (!aiEnabled()) throw new AiError("AI не е настроен: липсва GEMINI_API_KEY в .env.local");
  const payload = JSON.stringify({
    ...(body.system && { systemInstruction: { parts: [{ text: body.system }] } }),
    contents: body.contents,
    ...(body.tools && { tools: [{ functionDeclarations: body.tools }] }),
    generationConfig: { temperature: 0.2, ...(body.json && { responseMimeType: "application/json" }) },
  });
  const order = working == null ? [0, 1] : [working];
  let last = "";
  for (const i of order) {
    const res = await fetch(ENDPOINTS[i](MODEL), {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": KEY },
      body: payload,
      signal: AbortSignal.timeout(45_000),
    });
    if (res.ok) {
      working = i;
      const data = await res.json();
      const content = data.candidates?.[0]?.content as Content | undefined;
      if (!content?.parts) throw new AiError("AI върна празен отговор");
      return { role: "model", parts: content.parts };
    }
    const err = await res.json().catch(() => ({}));
    last = `${res.status} ${err?.error?.status ?? ""} ${err?.error?.message ?? ""}`.trim();
    // Only an auth/not-found failure is worth trying on the other host.
    if (![400, 401, 403, 404].includes(res.status)) break;
  }
  throw new AiError(`Gemini отказа заявката (${last.slice(0, 200)})`);
}

export const textOf = (c: Content) =>
  c.parts
    .map((p) => ("text" in p && !p.thought ? p.text : ""))
    .join("")
    .trim();
