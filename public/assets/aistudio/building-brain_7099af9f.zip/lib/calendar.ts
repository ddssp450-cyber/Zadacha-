import { isoDay } from "./vocab";

export type CalEvent = {
  id: string;
  title: string;
  kind: string;
  starts_at: string;
  ends_at: string | null;
  status: string;
  recurrence: string;
  unit_id: string | null;
  repair_id: string | null;
  assignee_id: string | null;
  description: string;
};

export type CalItem = {
  key: string;
  day: string; // YYYY-MM-DD Sofia
  start: Date;
  end: Date | null;
  title: string;
  kind: string; // event kind, or "payment"
  status: string;
  href?: string;
  event?: CalEvent;
};

function addStep(d: Date, rec: string, n: number) {
  const x = new Date(d);
  if (rec === "weekly") x.setUTCDate(x.getUTCDate() + 7 * n);
  else if (rec === "monthly") x.setUTCMonth(x.getUTCMonth() + n);
  else if (rec === "yearly") x.setUTCFullYear(x.getUTCFullYear() + n);
  return x;
}

/** Repeats recurring events inside [from, to). Occurrences keep the original duration. */
export function expand(events: CalEvent[], from: Date, to: Date): CalItem[] {
  const out: CalItem[] = [];
  for (const e of events) {
    const start = new Date(e.starts_at);
    const dur = e.ends_at ? Date.parse(e.ends_at) - start.getTime() : null;
    const step = e.recurrence ?? "none";
    for (let n = 0; n < 400; n++) {
      const s = step === "none" ? start : addStep(start, step, n);
      if (s >= to || (step === "none" && n > 0)) break;
      if (s >= from) {
        out.push({
          key: `${e.id}:${n}`,
          day: isoDay(s),
          start: s,
          end: dur == null ? null : new Date(s.getTime() + dur),
          title: e.title,
          kind: e.kind,
          // Past occurrences of a recurring task are history, not overdue work.
          status: n > 0 && e.status === "done" ? "planned" : e.status,
          href: e.repair_id ? `/repairs/${e.repair_id}` : undefined,
          event: e,
        });
      }
      if (step === "none") break;
    }
  }
  return out.sort((a, b) => a.start.getTime() - b.start.getTime());
}

/** Monday-first weeks covering the month of `d`. */
export function monthGrid(d: Date) {
  const first = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
  const offset = (first.getUTCDay() + 6) % 7;
  const start = new Date(first);
  start.setUTCDate(1 - offset);
  const days: string[] = [];
  for (let i = 0; i < 42; i++) {
    const x = new Date(start);
    x.setUTCDate(start.getUTCDate() + i);
    days.push(x.toISOString().slice(0, 10));
  }
  return days;
}

export function weekDays(d: Date) {
  const offset = (d.getUTCDay() + 6) % 7;
  return Array.from({ length: 7 }, (_, i) => {
    const x = new Date(d);
    x.setUTCDate(d.getUTCDate() - offset + i);
    return x.toISOString().slice(0, 10);
  });
}
