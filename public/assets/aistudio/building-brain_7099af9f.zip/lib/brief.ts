import type { DB } from "./supabase";
import type { Profile } from "./session";
import { daysBetween, eur, fmtDate, fmtTime, isoDay, payStatus, type PayStatus, type Tone } from "./vocab";
import { expand, type CalEvent } from "./calendar";

export type BriefItem = { tone: Tone; text: string; href: string; cta: string; at: string };
export type Brief = { items: BriefItem[]; stats: { label: string; value: string; tone?: Tone }[] };

type Pay = {
  id: string; unit_id: string; title: string; amount: number; paid_amount: number; due_date: string;
  status: PayStatus; period: string; kind: string; review_note: string | null; units: { number: string } | null;
};

const unitNo = (u: { number: string } | null) => (u ? `ап. ${u.number}` : "общи части");

/** Deterministic list of what needs this person today. The AI only words it, never adds to it. */
export async function collectBrief(supabase: DB, profile: Profile, buildingId: string): Promise<Brief> {
  const today = isoDay();
  const now = new Date();
  const weekAhead = new Date(now.getTime() + 7 * 86_400_000);
  const items: BriefItem[] = [];
  const role = profile.role;

  const [{ data: events }, { data: pays }, { data: repairs }] = await Promise.all([
    supabase.from("events").select("*").eq("building_id", buildingId).neq("status", "cancelled"),
    supabase.from("payments").select("id, unit_id, title, amount, paid_amount, due_date, status, period, kind, review_note, units(number)").eq("building_id", buildingId).returns<Pay[]>(),
    supabase.from("repairs").select("id, code, title, status, kind, due_date, assignee_id, reported_by, created_at, units(number)").eq("building_id", buildingId).not("status", "in", "(done,rejected)"),
  ]);

  // Calendar: today's items, overdue one-off tasks, proposals waiting for the owner.
  const startOfDay = new Date(`${today}T00:00:00`);
  for (const ev of expand((events ?? []) as CalEvent[], new Date(startOfDay.getTime() - 86_400_000 * 30), weekAhead)) {
    if (ev.status === "proposed") {
      if (role === "owner") items.push({ tone: "wait", text: `Предложен час: ${ev.title}, ${fmtDate(ev.start)} ${fmtTime(ev.start)}`, href: ev.href ?? "/calendar?view=list", cta: "Одобри", at: ev.start.toISOString() });
      continue;
    }
    if (ev.status !== "planned") continue;
    if (ev.day === today) items.push({ tone: "info", text: `${fmtTime(ev.start)} ${ev.title}`, href: ev.href ?? "/calendar?view=list", cta: "Виж", at: ev.start.toISOString() });
    else if (ev.start < startOfDay && ev.event?.recurrence === "none") items.push({ tone: "bad", text: `Просрочена задача: ${ev.title}`, href: "/calendar?view=list&filter=overdue", cta: "Отвори", at: ev.start.toISOString() });
  }

  for (const p of pays ?? []) {
    const st = payStatus(p, today);
    const owed = Number(p.amount) - Number(p.paid_amount);
    if (role === "owner") {
      if (st === "declared" || st === "pending_review")
        items.push({ tone: "wait", text: `Потвърди ${p.title.toLowerCase()} ${unitNo(p.units)} · ${eur(p.paid_amount)}`, href: `/payments?status=review#${p.id}`, cta: "Провери", at: `${p.due_date}T08:00:00` });
      else if (st === "overdue")
        items.push({ tone: "bad", text: `${p.title} ${unitNo(p.units)} е просрочен ${daysBetween(p.due_date, today)} дни · ${eur(owed)}`, href: `/payments?status=overdue#${p.id}`, cta: "Напомни", at: `${p.due_date}T08:00:00` });
    } else if (role === "tenant") {
      if (st === "overdue") items.push({ tone: "bad", text: `${p.title} е просрочен с ${daysBetween(p.due_date, today)} дни · ${eur(owed)}`, href: `/payments#${p.id}`, cta: "Плати", at: `${p.due_date}T08:00:00` });
      else if ((st === "unpaid" || st === "partial") && daysBetween(today, p.due_date) <= 7)
        items.push({ tone: "wait", text: `${p.title} до ${fmtDate(p.due_date)} · ${eur(owed)}`, href: `/payments#${p.id}`, cta: "Плати", at: `${p.due_date}T08:00:00` });
      else if (st === "unpaid" && p.review_note)
        items.push({ tone: "bad", text: `Собственикът отхвърли плащане: ${p.review_note}`, href: `/payments#${p.id}`, cta: "Виж", at: `${p.due_date}T08:00:00` });
    }
  }

  for (const r of repairs ?? []) {
    const label = `${r.code} ${r.title}`;
    const at = r.due_date ? `${r.due_date}T09:00:00` : r.created_at;
    const late = r.due_date && r.due_date < today;
    if (role === "owner" && r.status === "new")
      items.push({ tone: "wait", text: `${r.kind === "defect" ? "Дефект от строителя" : "Нова заявка"}: ${label}`, href: `/repairs/${r.id}`, cta: "Отвори", at: r.created_at });
    else if (role === "owner" && late)
      items.push({ tone: "bad", text: `Срокът мина: ${label}`, href: `/repairs/${r.id}`, cta: "Отвори", at });
    else if ((role === "technician" || role === "builder") && r.assignee_id === profile.id)
      items.push({ tone: late ? "bad" : r.status === "new" ? "wait" : "info", text: `${label}${r.due_date ? `, срок ${fmtDate(r.due_date)}` : ""}`, href: `/repairs/${r.id}`, cta: "Отвори", at });
    else if (role === "builder" && r.kind === "defect")
      items.push({ tone: "info", text: label, href: `/repairs/${r.id}`, cta: "Отвори", at });
    else if (role === "tenant" && r.reported_by === profile.id)
      items.push({ tone: "info", text: `Вашият сигнал ${r.code}: ${r.status === "new" ? "чака собственика" : "в работа"}`, href: `/repairs/${r.id}`, cta: "Виж", at: r.created_at });
  }

  if (role === "builder" || role === "technician") {
    const since = new Date(now.getTime() - 3 * 86_400_000).toISOString();
    const { data: comments } = await supabase.from("comments").select("id, body, created_at, repair_id, author_id, repairs(code)").neq("author_id", profile.id).gte("created_at", since);
    for (const c of comments ?? []) {
      const code = (c.repairs as unknown as { code: string } | null)?.code ?? "";
      items.push({ tone: "wait", text: `Въпрос по ${code}: „${c.body.slice(0, 70)}“`, href: `/repairs/${c.repair_id}`, cta: "Отговори", at: c.created_at });
    }
  }

  if (role === "owner") {
    const soon = isoDay(new Date(now.getTime() + 30 * 86_400_000));
    const { data: apps } = await supabase.from("appliances").select("id, name, warranty_until, next_service, units(number)").eq("building_id", buildingId);
    for (const a of apps ?? []) {
      const u = a.units as unknown as { number: string } | null;
      if (a.warranty_until && a.warranty_until >= today && a.warranty_until <= soon)
        items.push({ tone: "info", text: `Гаранцията на ${a.name.toLowerCase()} ${unitNo(u)} изтича ${fmtDate(a.warranty_until)}`, href: `/appliances/${a.id}`, cta: "Уред", at: `${a.warranty_until}T09:00:00` });
      if (a.next_service && a.next_service <= isoDay(weekAhead))
        items.push({ tone: a.next_service < today ? "bad" : "info", text: `Профилактика: ${a.name} ${unitNo(u)}, ${fmtDate(a.next_service)}`, href: `/appliances/${a.id}`, cta: "Планирай", at: `${a.next_service}T09:00:00` });
    }
  }

  if (role === "tenant") {
    const { data: notes } = await supabase.from("notifications").select("id, body, link, created_at").is("read_at", null);
    for (const n of notes ?? []) items.push({ tone: "wait", text: n.body, href: n.link ?? "/", cta: "Виж", at: n.created_at });
  }

  items.sort((a, b) => a.at.localeCompare(b.at));

  const stats: Brief["stats"] = [];
  if (role === "owner") {
    const month = today.slice(0, 7);
    const cur = (pays ?? []).filter((p) => p.period === month);
    const collected = cur.filter((p) => p.status === "confirmed" || p.status === "partial").reduce((s, p) => s + Number(p.paid_amount), 0);
    const overdue = (pays ?? []).filter((p) => payStatus(p, today) === "overdue").reduce((s, p) => s + Number(p.amount) - Number(p.paid_amount), 0);
    const { data: exp } = await supabase.from("expenses").select("amount").eq("building_id", buildingId).gte("spent_on", `${month}-01`);
    const spent = (exp ?? []).reduce((s, e) => s + Number(e.amount), 0);
    stats.push(
      { label: "Събрано този месец", value: eur(collected), tone: "ok" },
      { label: "Просрочено", value: eur(overdue), tone: overdue > 0 ? "bad" : undefined },
      { label: "Разходи този месец", value: eur(spent) },
    );
  }
  return { items, stats };
}
