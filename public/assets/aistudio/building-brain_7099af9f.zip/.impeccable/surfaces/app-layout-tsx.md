---
version: 1
slug: "app-layout-tsx"
primary_target: "app/layout.tsx"
related_targets: []
---

# App shell (all signed-in screens)

Scope: every signed-in screen (dashboard, buildings, people, appliances, payments, repairs, calendar, expenses, assistant). Mode: Operate. Audience: owners first, then tenants, builders, technicians, each seeing only their world. Language Bulgarian.

## Direction contract

THESIS: The building is drawn as a façade of cobalt enamel apartment plates, Sofia house-number style; refuses the white-SaaS sidebar-plus-KPI-cards dashboard.

OWN-WORLD: Cobalt enamel (#1d4596) rail and plates with a white inset keyline; cool porcelain ground (#f2f4f8); ink #0d1830; enamel red/amber/green only as state. Sofia Sans for UI, Sofia Sans Condensed 800 for numbers and plate labels. Radii 9–12px, hairline borders, no shadows, no gradients.

STORY: Owner sees who paid, what is broken and what to do today, then acts from one button per line. Tenants see their own plate, their dues and their reports.

FIRST VIEWPORT: Left cobalt rail with building plaque and the nine sections, badges on Плащания/Ремонти. Centre: greeting + date line, façade board (floors as rows, apartment plates with status tab), three money figures below. Right 380px column: AI "Днес накратко" paragraph, time-ranked action rows with one button each, ask box. Primary action: first action row's button.

FORM: Enamel house plates, assigned direction (candidate 4 of 7), raised by: split-flap (fixed columns, time-ranked rows), transit diagram (one closed state vocabulary), monochrome canon (every AI sentence links to its record). seed:68149b082f63e18e

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance
