"use client";
import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { Loader2, Paperclip, X } from "lucide-react";
import { uploadFile } from "@/lib/supabase-browser";
import { btn } from "./ui";

export type ActionState = { error?: string; ok?: string } | null;
type Action = (prev: ActionState, fd: FormData) => Promise<ActionState>;

export function ActionForm({
  action,
  children,
  className = "grid gap-3",
  submit,
  submitClass = btn,
}: {
  action: Action;
  children: React.ReactNode;
  className?: string;
  submit?: string;
  submitClass?: string;
}) {
  const [state, run] = useActionState(action, null);
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (state?.ok) ref.current?.reset();
  }, [state]);
  return (
    <form ref={ref} action={run} className={className}>
      {children}
      {state?.error && (
        <p role="alert" className="rounded-lg bg-red-soft px-3 py-2 text-sm text-red">
          {state.error}
        </p>
      )}
      {state?.ok && (
        <p role="status" className="rounded-lg bg-green-soft px-3 py-2 text-sm text-green">
          {state.ok}
        </p>
      )}
      {submit && <Submit className={submitClass}>{submit}</Submit>}
    </form>
  );
}

export function Submit({ children, className = btn, name, value }: { children: React.ReactNode; className?: string; name?: string; value?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" name={name} value={value} disabled={pending} className={className}>
      {pending && <Loader2 className="size-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

/** Uploads on pick and hands the stored paths to the form as hidden inputs. */
export function FileField({
  building,
  name = "paths",
  multiple = true,
  accept = "image/*,application/pdf",
  onUploaded,
}: {
  building: string;
  name?: string;
  multiple?: boolean;
  accept?: string;
  onUploaded?: (file: File, path: string) => void;
}) {
  const [files, setFiles] = useState<{ name: string; path: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function pick(e: React.ChangeEvent<HTMLInputElement>) {
    const list = Array.from(e.target.files ?? []);
    e.target.value = "";
    if (!list.length) return;
    setBusy(true);
    setError("");
    try {
      for (const f of list) {
        if (f.size > 15 * 1024 * 1024) throw new Error(`${f.name} е над 15 MB`);
        const path = await uploadFile(building, f);
        setFiles((prev) => (multiple ? [...prev, { name: f.name, path }] : [{ name: f.name, path }]));
        onUploaded?.(f, path);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Качването не успя");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="grid gap-2">
      <label className="inline-flex w-fit cursor-pointer items-center gap-2 rounded-lg border border-dashed border-cobalt/50 px-3 py-2 text-sm font-semibold text-cobalt hover:bg-cobalt-soft">
        {busy ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Paperclip className="size-4" aria-hidden />}
        {busy ? "Качване…" : multiple ? "Прикачи снимки или PDF" : "Прикачи файл"}
        <input type="file" className="sr-only" accept={accept} multiple={multiple} onChange={pick} disabled={busy} />
      </label>
      {files.map((f) => (
        <div key={f.path} className="flex items-center gap-2 text-sm text-mute">
          <input type="hidden" name={name} value={f.path} />
          <span className="truncate">{f.name}</span>
          <button
            type="button"
            aria-label={`Премахни ${f.name}`}
            className="rounded p-0.5 hover:bg-line"
            onClick={() => setFiles((prev) => prev.filter((x) => x.path !== f.path))}
          >
            <X className="size-3.5" />
          </button>
        </div>
      ))}
      {error && <p className="text-sm text-red">{error}</p>}
    </div>
  );
}
