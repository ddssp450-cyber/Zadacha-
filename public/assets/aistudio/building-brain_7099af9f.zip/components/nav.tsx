"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bot, Building2, CalendarDays, Gauge, Receipt, Users, Wallet, Wrench, Refrigerator,
} from "lucide-react";

const ICONS = { Gauge, Building2, Users, Refrigerator, Wallet, Wrench, CalendarDays, Receipt, Bot };
export type NavItem = { href: string; label: string; icon: keyof typeof ICONS; badge?: number };

export function Nav({ items }: { items: NavItem[] }) {
  const path = usePathname();
  return (
    <ul className="flex gap-1 overflow-x-auto px-3 pb-3 lg:grid lg:overflow-visible lg:px-0 lg:pb-0">
      {items.map((it) => {
        const on = it.href === "/" ? path === "/" : path.startsWith(it.href);
        const Icon = ICONS[it.icon];
        return (
          <li key={it.href} className="shrink-0">
            <Link
              href={it.href}
              aria-current={on ? "page" : undefined}
              className={`flex items-center gap-2.5 rounded-lg px-2.5 py-2 text-[14.5px] transition-colors ${
                on ? "bg-white font-bold text-cobalt" : "text-[#dce4f5] hover:bg-white/10 hover:text-white"
              }`}
            >
              <Icon className="size-4 shrink-0" aria-hidden strokeWidth={on ? 2.4 : 2} />
              <span className="whitespace-nowrap">{it.label}</span>
              {!!it.badge && (
                <span className="ml-auto rounded-full bg-red px-1.5 text-[11px] font-bold leading-[18px] text-white num">{it.badge}</span>
              )}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

export function BuildingSwitch({ buildings, current }: { buildings: { id: string; name: string }[]; current: string }) {
  if (buildings.length < 2) return null;
  return (
    <select
      aria-label="Смени сградата"
      defaultValue={current}
      onChange={(e) => {
        document.cookie = `bb=${e.target.value}; path=/; max-age=31536000; samesite=lax`;
        location.reload();
      }}
      className="mt-2 w-full rounded-md border border-white/30 bg-cobalt-deep px-2 py-1 text-xs text-white"
    >
      {buildings.map((b) => (
        <option key={b.id} value={b.id}>
          {b.name}
        </option>
      ))}
    </select>
  );
}
