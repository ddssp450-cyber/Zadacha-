import Link from "next/link";
import type { Tone } from "@/lib/vocab";

export const btn =
  "inline-flex items-center justify-center gap-1.5 rounded-lg bg-cobalt px-3.5 py-2 text-sm font-semibold text-white transition-colors hover:bg-cobalt-deep disabled:cursor-not-allowed disabled:opacity-50";
export const btnGhost =
  "inline-flex items-center justify-center gap-1.5 rounded-lg border border-cobalt bg-paper px-3 py-1.5 text-[13px] font-semibold text-cobalt transition-colors hover:bg-cobalt-soft disabled:cursor-not-allowed disabled:opacity-50";
export const btnDanger =
  "inline-flex items-center justify-center gap-1.5 rounded-lg border border-red bg-paper px-3 py-1.5 text-[13px] font-semibold text-red transition-colors hover:bg-red-soft disabled:opacity-50";
export const input =
  "w-full rounded-lg border border-line bg-paper px-3 py-2 text-[15px] text-ink placeholder:text-mute/80 hover:border-[#c3cbdc] focus:border-cobalt focus:outline-none focus:ring-2 focus:ring-cobalt/20";

const TONE: Record<Tone, string> = {
  ok: "bg-green-soft text-green",
  wait: "bg-amber-soft text-[#7a5a05]",
  bad: "bg-red text-white",
  idle: "bg-[#eceff5] text-mute",
  info: "bg-cobalt-soft text-cobalt",
};

export function Tag({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  return (
    <span className={`inline-flex items-center whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-semibold ${TONE[tone]}`}>
      {children}
    </span>
  );
}

export const DOT: Record<Tone, string> = {
  ok: "bg-green",
  wait: "bg-amber",
  bad: "bg-red",
  idle: "bg-[#b5bdcc]",
  info: "bg-cobalt",
};

export function PageHead({ title, sub, children }: { title: string; sub?: React.ReactNode; children?: React.ReactNode }) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-plate text-[34px] font-extrabold leading-tight tracking-[-0.01em] text-balance">{title}</h1>
        {sub && <p className="mt-0.5 text-[15px] text-mute">{sub}</p>}
      </div>
      {children && <div className="flex flex-wrap gap-2">{children}</div>}
    </header>
  );
}

export function Section({
  title,
  action,
  children,
  className = "",
}: {
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-xl border border-line bg-paper p-4 sm:p-5 ${className}`}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 className="text-[13px] font-bold uppercase tracking-[0.08em] text-mute">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return <p className="rounded-lg border border-dashed border-line px-4 py-6 text-center text-sm text-mute">{children}</p>;
}

export function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <label className="grid gap-1 text-sm">
      <span className="font-semibold text-ink">{label}</span>
      {children}
      {hint && <span className="text-xs text-mute">{hint}</span>}
    </label>
  );
}

export function Plate({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <div className={`plate px-3.5 py-2.5 ${className}`}>{children}</div>;
}

export function TextLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="font-semibold text-cobalt underline-offset-4 hover:underline">
      {children}
    </Link>
  );
}

export function Table({ head, children }: { head: React.ReactNode[]; children: React.ReactNode }) {
  return (
    <div className="-mx-4 overflow-x-auto sm:mx-0">
      <table className="w-full min-w-[640px] border-collapse text-[14px]">
        <thead>
          <tr className="text-left text-xs font-bold uppercase tracking-[0.06em] text-mute">
            {head.map((h, i) => (
              <th key={i} className="border-b border-line px-3 py-2 font-bold first:pl-4 sm:first:pl-3">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="[&_td]:border-b [&_td]:border-line [&_td]:px-3 [&_td]:py-2.5 [&_td:first-child]:pl-4 sm:[&_td:first-child]:pl-3 [&_tr:last-child_td]:border-0 [&_tr:hover]:bg-[#f7f9fc]">
          {children}
        </tbody>
      </table>
    </div>
  );
}
