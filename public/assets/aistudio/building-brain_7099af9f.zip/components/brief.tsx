import Link from "next/link";
import { Suspense } from "react";
import { Sparkles } from "lucide-react";
import type { Brief } from "@/lib/brief";
import { briefProse } from "@/lib/ai/prose";
import type { Profile } from "@/lib/session";
import { DOT, Empty } from "./ui";
import { AskBox } from "./chat";

async function Prose({ profile, brief }: { profile: Profile; brief: Brief }) {
  let text: string | null = null;
  let failed = false;
  try {
    text = await briefProse(profile.id, profile.role, profile.full_name, brief);
  } catch {
    failed = true;
  }
  if (failed) return <p className="text-sm text-mute">AI обобщението не е налично в момента. Списъкът долу е пълен.</p>;
  if (!text) return null;
  return <p className="settle text-[15.5px] leading-relaxed text-ink">{text}</p>;
}

export function BriefColumn({ profile, brief }: { profile: Profile; brief: Brief }) {
  return (
    <aside className="border-line bg-paper px-4 py-6 sm:px-6 xl:min-h-dvh xl:border-l">
      <h2 className="flex items-center gap-2 text-[13px] font-bold uppercase tracking-[0.08em] text-mute">
        <Sparkles className="size-3.5 text-cobalt" aria-hidden /> Днес накратко
      </h2>
      <div className="mb-4 mt-3 min-h-6">
        <Suspense fallback={<div className="h-14 animate-pulse rounded-lg bg-ground" aria-label="AI подготвя обобщението" />}>
          <Prose profile={profile} brief={brief} />
        </Suspense>
      </div>
      {brief.items.length === 0 ? (
        <Empty>Нищо не чака вас днес.</Empty>
      ) : (
        <ol>
          {brief.items.map((it, i) => (
            <li key={i} className="grid grid-cols-[10px_1fr_auto] items-start gap-3 border-t border-line py-3 text-[14.5px]">
              <span className={`mt-[7px] size-2.5 rounded-full ${DOT[it.tone]}`} aria-hidden />
              <span className="leading-snug">{it.text}</span>
              <Link href={it.href} className="rounded-lg border border-cobalt px-2.5 py-1 text-[12.5px] font-semibold text-cobalt hover:bg-cobalt-soft">
                {it.cta}
              </Link>
            </li>
          ))}
        </ol>
      )}
      <div className="mt-5">
        <AskBox
          hints={
            profile.role === "owner"
              ? ["Кой не е платил наема?", "Какви задачи има утре?", "Колко сме похарчили за ремонти?"]
              : profile.role === "tenant"
                ? ["Какво дължа този месец?", "Кога е следващото почистване?"]
                : ["Какви задачи трябва да свърша днес?", "Кои срокове наближават?"]
          }
        />
      </div>
    </aside>
  );
}
