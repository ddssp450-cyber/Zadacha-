"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { ArrowUp, Bot, Check, ImagePlus, Loader2, X } from "lucide-react";
import { uploadFile } from "@/lib/supabase-browser";

type Img = { mimeType: string; data: string; path?: string; name: string };
type Proposal = { id: string; type: string; summary: string; args: Record<string, unknown> };
type Msg = { role: "user" | "assistant"; text: string; images?: Img[]; proposals?: Proposal[]; error?: boolean };

const ASK = "bb-ask";
export const ask = (q: string) => window.dispatchEvent(new CustomEvent(ASK, { detail: q }));

const toBase64 = (f: File) =>
  new Promise<string>((ok, bad) => {
    const r = new FileReader();
    r.onload = () => ok(String(r.result).split(",")[1]);
    r.onerror = bad;
    r.readAsDataURL(f);
  });

export function Chat({ building, full = false, initial }: { building?: string; full?: boolean; initial?: string }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [imgs, setImgs] = useState<Img[]>([]);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<Record<string, { ok?: string; error?: string; href?: string } | "busy" | "dismissed">>({});
  const end = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const sentInitial = useRef(false);

  useEffect(() => end.current?.scrollIntoView({ block: "end", behavior: "smooth" }), [msgs, busy]);

  async function send(q: string) {
    if ((!q.trim() && !imgs.length) || busy) return;
    const next: Msg[] = [...msgs, { role: "user", text: q.trim(), images: imgs }];
    setMsgs(next);
    setText("");
    setImgs([]);
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ messages: next.map((m) => ({ role: m.role, text: m.text, images: m.images?.map(({ mimeType, data, path }) => ({ mimeType, data, path })) })) }),
      });
      const data = await res.json();
      setMsgs((m) => [...m, data.error ? { role: "assistant", text: data.error, error: true } : { role: "assistant", text: data.reply, proposals: data.proposals }]);
    } catch {
      setMsgs((m) => [...m, { role: "assistant", text: "Няма връзка със сървъра.", error: true }]);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (initial && !sentInitial.current) {
      sentInitial.current = true;
      send(initial);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial]);

  async function attach(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []).slice(0, 4);
    e.target.value = "";
    for (const f of files) {
      if (f.size > 8 * 1024 * 1024) continue;
      const data = await toBase64(f);
      const path = building ? await uploadFile(building, f).catch(() => undefined) : undefined;
      setImgs((x) => [...x, { mimeType: f.type, data, path, name: f.name }]);
    }
  }

  async function confirm(p: Proposal) {
    setDone((d) => ({ ...d, [p.id]: "busy" }));
    const res = await fetch("/api/chat/confirm", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(p) });
    const data = await res.json().catch(() => ({ error: "Грешка" }));
    setDone((d) => ({ ...d, [p.id]: data }));
    if (data.ok) router.refresh();
  }

  return (
    <div className={`flex min-h-0 flex-col ${full ? "h-[calc(100dvh-180px)] min-h-[420px]" : "h-full"}`}>
      <div className="min-h-0 flex-1 space-y-3 overflow-y-auto px-1 py-2" aria-live="polite">
        {msgs.length === 0 && (
          <div className="grid gap-2 py-4 text-sm text-mute">
            <p>Питайте за плащания, ремонти, календар или разходи. Мога да предлагам събития и заявки, но нищо не записвам без вашето „Потвърди“.</p>
            <div className="flex flex-wrap gap-2">
              {["Какво се случи днес в сградата?", "Кои задачи са просрочени?", "Намери свободен час за оглед следващата седмица"].map((h) => (
                <button key={h} onClick={() => send(h)} className="rounded-full border border-line bg-paper px-3 py-1.5 text-left text-[13px] text-ink hover:border-cobalt">
                  {h}
                </button>
              ))}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={`settle flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[88%] whitespace-pre-wrap rounded-xl px-3.5 py-2.5 text-[14.5px] leading-relaxed ${
                m.role === "user" ? "bg-cobalt text-white" : m.error ? "bg-red-soft text-red" : "border border-line bg-paper text-ink"
              }`}
            >
              {m.images?.length ? <p className="mb-1 text-xs opacity-80">{m.images.length} прикачени</p> : null}
              {m.text}
              {m.proposals?.map((p) => {
                const st = done[p.id];
                return (
                  <div key={p.id} className="mt-3 rounded-lg border border-cobalt/40 bg-cobalt-soft p-3 text-ink">
                    <p className="text-[12px] font-bold uppercase tracking-[0.06em] text-cobalt">
                      {p.type === "event" ? "Ново събитие" : p.type === "repair" ? "Нова заявка" : p.type === "payment_review" ? "Плащане" : "Напомняния"}
                    </p>
                    <p className="mt-0.5 font-semibold">{p.summary}</p>
                    {st === "dismissed" ? (
                      <p className="mt-2 text-sm text-mute">Отказано.</p>
                    ) : st && st !== "busy" ? (
                      <p className={`mt-2 text-sm ${st.error ? "text-red" : "text-green"}`}>
                        {st.error ?? st.ok} {st.href && <Link href={st.href} className="font-semibold underline">Отвори</Link>}
                      </p>
                    ) : (
                      <div className="mt-2 flex gap-2">
                        <button onClick={() => confirm(p)} disabled={st === "busy"} className="inline-flex items-center gap-1 rounded-lg bg-cobalt px-3 py-1.5 text-[13px] font-semibold text-white hover:bg-cobalt-deep disabled:opacity-60">
                          {st === "busy" ? <Loader2 className="size-3.5 animate-spin" /> : <Check className="size-3.5" />} Потвърди
                        </button>
                        <button onClick={() => setDone((d) => ({ ...d, [p.id]: "dismissed" }))} className="rounded-lg border border-line bg-paper px-3 py-1.5 text-[13px] font-semibold">
                          Откажи
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-sm text-mute">
            <Loader2 className="size-4 animate-spin" /> Проверявам данните…
          </div>
        )}
        <div ref={end} />
      </div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(text);
        }}
        className="mt-2 rounded-xl border-[1.5px] border-cobalt bg-paper p-2 focus-within:ring-2 focus-within:ring-cobalt/20"
      >
        {imgs.length > 0 && (
          <div className="mb-2 flex flex-wrap gap-2 px-1">
            {imgs.map((im, i) => (
              <span key={i} className="inline-flex items-center gap-1 rounded-md bg-ground px-2 py-1 text-xs">
                {im.name}
                <button type="button" aria-label="Премахни" onClick={() => setImgs((x) => x.filter((_, j) => j !== i))}>
                  <X className="size-3" />
                </button>
              </span>
            ))}
          </div>
        )}
        <div className="flex items-end gap-1">
          <label className="cursor-pointer rounded-lg p-2 text-mute hover:bg-ground hover:text-cobalt" title="Прикачи снимки">
            <ImagePlus className="size-5" aria-hidden />
            <span className="sr-only">Прикачи снимки</span>
            <input type="file" accept="image/*,application/pdf" multiple className="sr-only" onChange={attach} />
          </label>
          <textarea
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(text);
              }
            }}
            placeholder="Попитайте или възложете задача…"
            aria-label="Съобщение до асистента"
            className="max-h-32 min-h-10 flex-1 resize-none bg-transparent px-1 py-2 text-[15px] outline-none placeholder:text-mute"
          />
          <button disabled={busy || (!text.trim() && !imgs.length)} className="rounded-lg bg-cobalt p-2 text-white hover:bg-cobalt-deep disabled:opacity-40" aria-label="Изпрати">
            <ArrowUp className="size-5" />
          </button>
        </div>
      </form>
    </div>
  );
}

/** Floating assistant on every page except the full assistant page. */
export function ChatDock({ building }: { building?: string }) {
  const [open, setOpen] = useState(false);
  const [initial, setInitial] = useState<string>();
  const [key, setKey] = useState(0);
  const path = usePathname();
  useEffect(() => {
    const on = (e: Event) => {
      setInitial((e as CustomEvent<string>).detail);
      setKey((k) => k + 1);
      setOpen(true);
    };
    window.addEventListener(ASK, on);
    return () => window.removeEventListener(ASK, on);
  }, []);
  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, []);
  if (path.startsWith("/assistant")) return null;
  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-4 right-4 z-30 inline-flex items-center gap-2 rounded-full bg-cobalt py-3 pl-4 pr-5 font-semibold text-white shadow-[0_8px_24px_-6px_rgba(20,51,111,.55)] hover:bg-cobalt-deep"
        >
          <Bot className="size-5" aria-hidden /> Попитай
        </button>
      )}
      <section
        aria-label="AI асистент"
        hidden={!open}
        className="fixed inset-x-0 bottom-0 z-40 flex h-[78dvh] flex-col rounded-t-2xl border border-line bg-ground p-3 shadow-[0_-12px_40px_-12px_rgba(13,24,48,.35)] sm:inset-x-auto sm:bottom-4 sm:right-4 sm:h-[620px] sm:w-[420px] sm:rounded-2xl"
      >
        <header className="flex items-center justify-between px-1 pb-1">
          <p className="flex items-center gap-2 font-plate text-lg font-extrabold">
            <Bot className="size-5 text-cobalt" aria-hidden /> Асистент
          </p>
          <button onClick={() => setOpen(false)} className="rounded-lg p-1.5 hover:bg-line" aria-label="Затвори">
            <X className="size-5" />
          </button>
        </header>
        <Chat key={key} building={building} initial={initial} />
      </section>
    </>
  );
}

export function AskBox({ hints }: { hints: string[] }) {
  const [q, setQ] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (q.trim()) ask(q.trim());
        setQ("");
      }}
    >
      <label className="flex items-center gap-2 rounded-xl border-[1.5px] border-cobalt bg-paper px-3 py-2 focus-within:ring-2 focus-within:ring-cobalt/20">
        <span className="sr-only">Попитайте асистента</span>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={`Попитай: „${hints[0]}“`} className="min-w-0 flex-1 bg-transparent py-1 text-[15px] outline-none placeholder:text-mute" />
        <button className="rounded-lg bg-cobalt p-1.5 text-white" aria-label="Попитай">
          <ArrowUp className="size-4" />
        </button>
      </label>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {hints.slice(1).map((h) => (
          <button key={h} type="button" onClick={() => ask(h)} className="rounded-full border border-line px-2.5 py-1 text-[12.5px] text-mute hover:border-cobalt hover:text-cobalt">
            {h}
          </button>
        ))}
      </div>
    </form>
  );
}
