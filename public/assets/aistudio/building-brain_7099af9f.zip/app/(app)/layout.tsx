import { me } from "@/lib/session";
import { ROLE } from "@/lib/vocab";
import { BuildingSwitch, Nav, type NavItem } from "@/components/nav";
import { ChatDock } from "@/components/chat";
import { signOut } from "./actions";
import { LogOut } from "lucide-react";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { supabase, profile, buildings, building } = await me();
  const role = profile.role;

  let reviews = 0;
  let newRepairs = 0;
  if (building && role === "owner") {
    const [p, r] = await Promise.all([
      supabase.from("payments").select("id", { count: "exact", head: true }).eq("building_id", building.id).in("status", ["declared", "pending_review"]),
      supabase.from("repairs").select("id", { count: "exact", head: true }).eq("building_id", building.id).eq("status", "new"),
    ]);
    reviews = p.count ?? 0;
    newRepairs = r.count ?? 0;
  }

  const all: (NavItem & { roles: string[] })[] = [
    { href: "/", label: "Табло", icon: "Gauge", roles: ["owner", "tenant", "builder", "technician"] },
    { href: "/buildings", label: role === "tenant" ? "Моят апартамент" : "Сгради и апартаменти", icon: "Building2", roles: ["owner", "tenant", "builder"] },
    { href: "/people", label: "Наематели и строители", icon: "Users", roles: ["owner"] },
    { href: "/appliances", label: "Уреди", icon: "Refrigerator", roles: ["owner", "tenant", "technician"] },
    { href: "/payments", label: "Плащания", icon: "Wallet", badge: reviews, roles: ["owner", "tenant"] },
    { href: "/repairs", label: role === "builder" ? "Дефекти и задачи" : role === "tenant" ? "Сигнали и ремонти" : "Ремонти", icon: "Wrench", badge: newRepairs, roles: ["owner", "tenant", "builder", "technician"] },
    { href: "/calendar", label: "Календар и задачи", icon: "CalendarDays", roles: ["owner", "tenant", "builder", "technician"] },
    { href: "/expenses", label: role === "owner" ? "Разходи и документи" : "Документи", icon: "Receipt", roles: ["owner", "builder"] },
    { href: "/assistant", label: "AI асистент", icon: "Bot", roles: ["owner", "tenant", "builder", "technician"] },
  ];
  const items = all.filter((i) => i.roles.includes(role));

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[236px_1fr]">
      <aside className="bg-cobalt text-white lg:sticky lg:top-0 lg:flex lg:h-dvh lg:flex-col lg:gap-5 lg:p-4">
        <div className="flex items-center justify-between gap-3 p-3 lg:block lg:p-0">
          <div className="plate plate-deep min-w-0 px-3.5 py-3">
            <p className="font-plate text-[21px] font-extrabold leading-none tracking-[0.01em]">{building?.name ?? "Building Brain"}</p>
            <p className="mt-1 truncate text-[12px] text-[#c9d4ee]">{building?.address || "Добавете първата сграда"}</p>
            {building && <BuildingSwitch buildings={buildings} current={building.id} />}
          </div>
        </div>
        <nav aria-label="Основно меню" className="lg:flex-1">
          <Nav items={items} />
        </nav>
        <div className="hidden border-t border-white/15 pt-3 text-[13px] lg:block">
          <p className="font-semibold">{profile.full_name}</p>
          <p className="text-[#c9d4ee]">{ROLE[role]}</p>
          <form action={signOut}>
            <button className="mt-2 inline-flex items-center gap-1.5 text-[#dce4f5] hover:text-white">
              <LogOut className="size-3.5" aria-hidden /> Изход
            </button>
          </form>
        </div>
      </aside>
      <div className="min-w-0">
        {children}
        <form action={signOut} className="px-4 pb-24 text-sm text-mute lg:hidden">
          {profile.full_name} · {ROLE[role]} · <button className="font-semibold text-cobalt">Изход</button>
        </form>
      </div>
      <ChatDock building={building?.id} />
    </div>
  );
}
