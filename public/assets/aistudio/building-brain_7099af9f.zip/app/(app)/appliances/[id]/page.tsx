import Link from "next/link";
import { notFound } from "next/navigation";
import { FileText } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { APPLIANCE_KIND, eur, fmtDate, isoDay, REPAIR, type RepairStatus } from "@/lib/vocab";
import { Empty, PageHead, Section, Tag, TextLink } from "@/components/ui";

export default async function AppliancePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase } = await meWithBuilding();
  const { data: a } = await supabase.from("appliances").select("*, units(number, floor), profiles(full_name)").eq("id", id).maybeSingle();
  if (!a) notFound();
  const [{ data: repairs }, { data: files }] = await Promise.all([
    supabase.from("repairs").select("id, code, title, status, created_at, cost").eq("appliance_id", id).order("created_at", { ascending: false }),
    supabase.from("files").select("id, path, name, kind").eq("appliance_id", id),
  ]);
  const paths = [a.photo_path, ...(files ?? []).map((f) => f.path)].filter((x): x is string => !!x);
  const signed = paths.length ? (await supabase.storage.from("files").createSignedUrls(paths, 900)).data ?? [] : [];
  const url = new Map(signed.map((s) => [s.path, s.signedUrl ?? undefined]));
  const u = a.units as { number: string; floor: number } | null;
  const today = isoDay();
  const totalCost = (repairs ?? []).reduce((s, r) => s + Number(r.cost ?? 0), 0);

  return (
    <main className="px-4 py-6 sm:px-8">
      <Link href="/appliances" className="text-sm font-semibold text-cobalt">← Всички уреди</Link>
      <PageHead title={a.name} sub={`${APPLIANCE_KIND[a.kind]} · ${u ? `ап. ${u.number}, ет. ${u.floor}` : "общи части"}`} />
      <div className="grid gap-4 xl:grid-cols-[360px_1fr] xl:items-start">
        <Section title="Профил">
          {a.photo_path && url.get(a.photo_path) && (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={url.get(a.photo_path)} alt={a.name} className="mb-4 aspect-[4/3] w-full rounded-lg object-cover" />
          )}
          <dl className="grid grid-cols-2 gap-3 text-[14.5px]">
            <div><dt className="text-[13px] text-mute">Модел</dt><dd className="font-semibold">{a.model || "—"}</dd></div>
            <div><dt className="text-[13px] text-mute">Сериен №</dt><dd className="num font-semibold">{a.serial || "—"}</dd></div>
            <div><dt className="text-[13px] text-mute">Гаранция до</dt><dd className={`font-semibold ${a.warranty_until && a.warranty_until < today ? "text-mute line-through" : ""}`}>{a.warranty_until ? fmtDate(a.warranty_until, { day: "numeric", month: "long", year: "numeric" }) : "—"}</dd></div>
            <div><dt className="text-[13px] text-mute">Профилактика</dt><dd className="font-semibold">{a.next_service ? fmtDate(a.next_service, { day: "numeric", month: "long" }) : "—"}</dd></div>
            <div><dt className="text-[13px] text-mute">Собственик</dt><dd className="font-semibold">{(a.profiles as { full_name: string } | null)?.full_name ?? "—"}</dd></div>
            <div><dt className="text-[13px] text-mute">Ремонти общо</dt><dd className="num font-semibold">{eur(totalCost)}</dd></div>
          </dl>
          {a.notes && <p className="mt-4 text-[14.5px]">{a.notes}</p>}
        </Section>
        <div className="grid gap-4">
          <Section title="История на повредите и ремонтите" action={<TextLink href="/repairs/new">Докладвай повреда</TextLink>}>
            {!repairs?.length ? <Empty>Няма ремонти по този уред.</Empty> : (
              <ul>
                {repairs.map((r) => (
                  <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-line py-2.5 first:border-0">
                    <span className="num font-plate font-bold text-cobalt">{r.code}</span>
                    <Link href={`/repairs/${r.id}`} className="flex-1 font-semibold hover:underline">{r.title}</Link>
                    <span className="text-sm text-mute">{fmtDate(r.created_at)}</span>
                    {r.cost && <span className="num text-sm">{eur(r.cost)}</span>}
                    <Tag tone={REPAIR[r.status as RepairStatus].tone}>{REPAIR[r.status as RepairStatus].label}</Tag>
                  </li>
                ))}
              </ul>
            )}
          </Section>
          <Section title="Документи">
            {!files?.length ? <Empty>Няма документи (гаранционна карта, инструкция, фактура).</Empty> : (
              <ul className="grid gap-2">
                {files.map((f) => (
                  <li key={f.id}><a href={url.get(f.path)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 font-semibold text-cobalt hover:underline"><FileText className="size-4" />{f.name}</a></li>
                ))}
              </ul>
            )}
          </Section>
        </div>
      </div>
    </main>
  );
}
