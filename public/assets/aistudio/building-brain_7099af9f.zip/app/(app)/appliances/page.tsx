import Link from "next/link";
import { meWithBuilding } from "@/lib/session";
import { APPLIANCE_KIND, daysBetween, fmtDate, isoDay } from "@/lib/vocab";
import { Empty, PageHead, Section, Tag } from "@/components/ui";
import { ApplianceForm } from "./forms";

export default async function Appliances() {
  const { supabase, building, profile } = await meWithBuilding();
  const today = isoDay();
  const [{ data }, { data: units }, { data: open }] = await Promise.all([
    supabase.from("appliances").select("id, name, kind, model, warranty_until, next_service, photo_path, units(number)").eq("building_id", building.id).order("name"),
    supabase.from("units").select("id, number, floor, tenant_id").eq("building_id", building.id).order("floor"),
    supabase.from("repairs").select("appliance_id").eq("building_id", building.id).not("status", "in", "(done,rejected)").not("appliance_id", "is", null),
  ]);
  const photos = (data ?? []).map((a) => a.photo_path).filter((x): x is string => !!x);
  const signed = photos.length ? (await supabase.storage.from("files").createSignedUrls(photos, 900)).data ?? [] : [];
  const url = new Map(signed.map((s) => [s.path, s.signedUrl ?? undefined]));
  const broken = new Set((open ?? []).map((r) => r.appliance_id));
  const canAdd = profile.role === "owner" || profile.role === "tenant";
  const myUnits = profile.role === "tenant" ? (units ?? []).filter((u) => u.tenant_id === profile.id) : units ?? [];

  return (
    <main className="px-4 py-6 sm:px-8">
      <PageHead title="Уреди" sub={`${data?.length ?? 0} уреда с дигитален профил`} />
      <div className="grid gap-4 xl:grid-cols-[1fr_360px] xl:items-start">
        <Section title="Всички уреди">
          {!data?.length ? <Empty>Няма добавени уреди.</Empty> : (
            <ul className="grid gap-2 sm:grid-cols-2">
              {data.map((a) => {
                const u = a.units as unknown as { number: string } | null;
                const w = a.warranty_until;
                const wTone = !w ? null : w < today ? "idle" : daysBetween(today, w) <= 30 ? "wait" : "ok";
                const service = a.next_service && daysBetween(today, a.next_service) <= 14;
                const photo = a.photo_path ? url.get(a.photo_path) : null;
                return (
                  <li key={a.id}>
                    <Link href={`/appliances/${a.id}`} className="flex gap-3 rounded-lg border border-line p-3 hover:border-cobalt">
                      {photo ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={photo} alt="" className="size-14 rounded-md object-cover" />
                      ) : (
                        <div className="plate grid size-14 shrink-0 place-items-center font-plate text-[13px] font-extrabold">{u ? u.number : "ОЧ"}</div>
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold">{a.name} <span className="font-normal text-mute">· {u ? `ап. ${u.number}` : "общи части"}</span></p>
                        <p className="truncate text-[13px] text-mute">{APPLIANCE_KIND[a.kind]} · {a.model || "без модел"}</p>
                        <div className="mt-1.5 flex flex-wrap gap-1.5">
                          {broken.has(a.id) && <Tag tone="bad">в ремонт</Tag>}
                          {wTone && <Tag tone={wTone}>{wTone === "idle" ? "без гаранция" : `гаранция до ${fmtDate(w!)}`}</Tag>}
                          {service && <Tag tone="info">профилактика {fmtDate(a.next_service!)}</Tag>}
                        </div>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </Section>
        {canAdd && (
          <Section title="Нов уред">
            <ApplianceForm building={building.id} units={myUnits.map((u) => ({ id: u.id, label: `ап. ${u.number}` }))} />
          </Section>
        )}
      </div>
    </main>
  );
}
