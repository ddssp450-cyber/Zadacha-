"use client";
import { ActionForm, FileField } from "@/components/form";
import { Field, input } from "@/components/ui";
import { APPLIANCE_KIND } from "@/lib/vocab";
import { createAppliance } from "../actions";

export function ApplianceForm({ building, units }: { building: string; units: { id: string; label: string }[] }) {
  return (
    <ActionForm action={createAppliance} submit="Добави уред">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Име"><input name="name" required className={input} placeholder="Климатик хол" /></Field>
        <Field label="Вид">
          <select name="kind" className={input}>
            {Object.entries(APPLIANCE_KIND).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Модел"><input name="model" className={input} /></Field>
        <Field label="Сериен №"><input name="serial" className={input} /></Field>
      </div>
      <Field label="Апартамент">
        <select name="unit" className={input} defaultValue={units.length === 1 ? units[0].id : ""}>
          {units.length !== 1 && <option value="">Общи части</option>}
          {units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Гаранция до"><input name="warranty_until" type="date" className={input} /></Field>
        <Field label="Следваща профилактика"><input name="next_service" type="date" className={input} /></Field>
      </div>
      <Field label="Бележки"><textarea name="notes" rows={2} className={input} /></Field>
      <Field label="Снимка и документи" hint="Първият файл става снимка на уреда, останалите — документи.">
        <FileField building={building} />
      </Field>
    </ActionForm>
  );
}
