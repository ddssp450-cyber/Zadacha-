"use client";
import { ActionForm, Submit } from "@/components/form";
import { btnGhost, Field, input } from "@/components/ui";
import { EVENT_KIND, RECURRENCE } from "@/lib/vocab";
import { createEvent, setEventStatus } from "../actions";

type Opt = { id: string; label: string };

export function EventForm({ units, people, day }: { units: Opt[]; people: Opt[]; day: string }) {
  return (
    <ActionForm action={createEvent} submit="Добави в календара">
      <Field label="Заглавие"><input name="title" required className={input} placeholder="Профилактика на климатиците" /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Вид">
          <select name="kind" className={input} defaultValue="maintenance">
            {Object.entries(EVENT_KIND).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Повторение">
          <select name="recurrence" className={input}>
            {Object.entries(RECURRENCE).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <Field label="Дата"><input name="date" type="date" required defaultValue={day} className={input} /></Field>
        <Field label="От"><input name="time" type="time" defaultValue="09:00" className={input} /></Field>
        <Field label="До"><input name="end" type="time" className={input} /></Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Отговорник">
          <select name="assignee" className={input} defaultValue="">
            <option value="">—</option>
            {people.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
          </select>
        </Field>
        <Field label="Апартамент">
          <select name="unit" className={input} defaultValue="">
            <option value="">Цялата сграда</option>
            {units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Описание"><textarea name="description" rows={2} className={input} /></Field>
    </ActionForm>
  );
}

export function StatusButtons({ id, status, owner }: { id: string; status: string; owner: boolean }) {
  return (
    <ActionForm action={setEventStatus} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="id" value={id} />
      {owner && status === "proposed" && <Submit name="status" value="planned" className={btnGhost}>Одобри</Submit>}
      {status === "planned" && <Submit name="status" value="done" className={btnGhost}>Изпълнено</Submit>}
      {(owner || status === "proposed") && status !== "done" && <Submit name="status" value="cancelled" className="text-[13px] font-semibold text-mute hover:text-red">Отмени</Submit>}
    </ActionForm>
  );
}
