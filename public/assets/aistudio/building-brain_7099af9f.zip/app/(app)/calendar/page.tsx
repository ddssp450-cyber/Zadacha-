import Link from "next/link";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { expand, monthGrid, weekDays, type CalEvent, type CalItem } from "@/lib/calendar";
import { EVENT_KIND, EVENT_STATUS, fmtDate, fmtTime, isoDay, ROLE, type Role } from "@/lib/vocab";
import { Empty, PageHead, Section, Tag } from "@/components/ui";
import { EventForm, StatusButtons } from "./forms";

const KIND_COLOR: Record<string, string> = {
  payment: "bg-amber-soft text-[#6b4e00]",
  repair: "bg-red-soft text-red",
  construction: "bg-[#ece7f8] text-[#4b3a8c]",
  maintenance: "bg-cobalt-soft text-cobalt",
  inspection: "bg-cobalt-soft text-cobalt",
  cleaning: "bg-green-soft text-green",
  viewing: "bg-[#e6f2f6] text-[#1f5f73]",
  meeting: "bg-[#eceff5] text-ink",
  other: "bg-[#eceff5] text-ink",
};
const WEEK = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд"];

export default async function Calendar({ searchParams }: { searchParams: Promise<{ view?: string; d?: string; filter?: string }> }) {
  const { supabase, building, profile, isOwner } = await meWithBuilding();
  const sp = await searchParams;
  const view = sp.view === "week" || sp.view === "list" ? sp.view : "month";
  const today = isoDay();
  const anchor = new Date(`${/^\d{4}-\d{2}-\d{2}$/.test(sp.d ?? "") ? sp.d : today}T12:00:00Z`);

  const days = view === "month" ? monthGrid(anchor) : view === "week" ? weekDays(anchor) : [];
  const from = view === "list" ? new Date(anchor.getTime() - 30 * 86_400_000) : new Date(`${days[0]}T00:00:00Z`);
  const to = view === "list" ? new Date(anchor.getTime() + 60 * 86_400_000) : new Date(new Date(`${days.at(-1)}T00:00:00Z`).getTime() + 2 * 86_400_000);

  const [{ data: events }, { data: dues }, { data: units }, { data: members }] = await Promise.all([
    supabase.from("events").select("*").eq("building_id", building.id).neq("status", "cancelled"),
    isOwner || profile.role === "tenant"
      ? supabase.from("payments").select("id, title, due_date, status, units(number)").eq("building_id", building.id).gte("due_date", isoDay(from)).lte("due_date", isoDay(to)).neq("status", "confirmed")
      : Promise.resolve({ data: [] }),
    isOwner ? supabase.from("units").select("id, number").eq("building_id", building.id).order("floor") : Promise.resolve({ data: [] }),
    isOwner ? supabase.from("building_members").select("user_id, role, profiles(full_name)").eq("building_id", building.id) : Promise.resolve({ data: [] }),
  ]);

  const now = new Date();
  let items: CalItem[] = [
    ...expand((events ?? []) as CalEvent[], from, to),
    ...(dues ?? []).map((p) => ({
      key: `p:${p.id}`, day: p.due_date, start: new Date(`${p.due_date}T09:00:00`), end: null,
      title: `Срок: ${p.title}${(p.units as unknown as { number: string } | null) ? `, ап. ${(p.units as unknown as { number: string }).number}` : ""}`,
      kind: "payment", status: "planned", href: `/payments#${p.id}`,
    })),
  ].sort((a, b) => a.start.getTime() - b.start.getTime());
  const isOverdue = (i: CalItem) => i.kind !== "payment" && i.status === "planned" && i.start < now && i.event?.recurrence === "none" && i.day < today;
  if (sp.filter === "overdue") items = items.filter(isOverdue);

  const byDay = new Map<string, CalItem[]>();
  for (const i of items) byDay.set(i.day, [...(byDay.get(i.day) ?? []), i]);

  const step = (n: number) => {
    const x = new Date(anchor);
    if (view === "month") x.setUTCMonth(x.getUTCMonth() + n);
    else x.setUTCDate(x.getUTCDate() + (view === "week" ? 7 : 30) * n);
    return x.toISOString().slice(0, 10);
  };
  const link = (o: { view?: string; d?: string; filter?: string }) => {
    const q = new URLSearchParams({ view: o.view ?? view, d: o.d ?? isoDay(anchor) });
    if (o.filter) q.set("filter", o.filter);
    return `/calendar?${q}`;
  };
  const heading = view === "month"
    ? anchor.toLocaleDateString("bg-BG", { month: "long", year: "numeric", timeZone: "UTC" })
    : view === "week" ? `${fmtDate(`${days[0]}T12:00:00Z`)} – ${fmtDate(`${days[6]}T12:00:00Z`, { day: "numeric", month: "short", year: "numeric" })}` : "Списък";
  const overdueCount = items.filter(isOverdue).length;

  return (
    <main className="px-4 py-6 sm:px-8">
      <PageHead title="Календар и задачи" sub={profile.role === "tenant" ? "Събитията, които засягат вас" : profile.role === "owner" ? "Наеми, ремонти, строителство, огледи и профилактика на едно място" : "Вашите посещения и срокове"} />
      <div className="grid gap-4 2xl:grid-cols-[1fr_340px] 2xl:items-start">
        <Section
          title={heading}
          action={
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex rounded-lg border border-line p-0.5 text-[13px] font-semibold" role="tablist" aria-label="Изглед">
                {[["month", "Месец"], ["week", "Седмица"], ["list", "Списък"]].map(([k, l]) => (
                  <Link key={k} href={link({ view: k })} role="tab" aria-selected={view === k} className={`rounded-md px-2.5 py-1 ${view === k ? "bg-cobalt text-white" : "text-mute hover:text-ink"}`}>{l}</Link>
                ))}
              </div>
              <Link href={link({ d: step(-1) })} className="rounded-lg border border-line p-1.5 hover:border-cobalt" aria-label="Назад"><ChevronLeft className="size-4" /></Link>
              <Link href={link({ d: today })} className="rounded-lg border border-line px-2.5 py-1 text-[13px] font-semibold hover:border-cobalt">Днес</Link>
              <Link href={link({ d: step(1) })} className="rounded-lg border border-line p-1.5 hover:border-cobalt" aria-label="Напред"><ChevronRight className="size-4" /></Link>
            </div>
          }
        >
          {overdueCount > 0 && sp.filter !== "overdue" && (
            <Link href={link({ view: "list", filter: "overdue" })} className="mb-3 flex items-center gap-2 rounded-lg bg-red-soft px-3 py-2 text-sm font-semibold text-red">
              {overdueCount === 1 ? "1 просрочена задача" : `${overdueCount} просрочени задачи`} → покажи
            </Link>
          )}

          {view === "month" && (
            <div className="-mx-4 overflow-x-auto sm:mx-0">
              <div className="grid min-w-[720px] grid-cols-7 overflow-hidden rounded-lg border border-line bg-line gap-px">
                {WEEK.map((w) => <div key={w} className="bg-ground px-2 py-1.5 text-xs font-bold uppercase tracking-[0.06em] text-mute">{w}</div>)}
                {days.map((d) => {
                  const list = byDay.get(d) ?? [];
                  const inMonth = d.slice(0, 7) === isoDay(anchor).slice(0, 7);
                  return (
                    <div key={d} className={`min-h-[104px] bg-paper p-1.5 ${inMonth ? "" : "bg-[#fafbfd] text-mute/70"}`}>
                      <Link href={link({ view: "list", d })} className={`num mb-1 inline-grid size-6 place-items-center rounded-full text-[13px] font-semibold ${d === today ? "bg-cobalt text-white" : ""}`}>{Number(d.slice(8))}</Link>
                      <ul className="grid gap-0.5">
                        {list.slice(0, 3).map((i) => <Chip key={i.key} i={i} late={isOverdue(i)} />)}
                        {list.length > 3 && <li className="px-1 text-[11.5px] text-mute">+{list.length - 3} още</li>}
                      </ul>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {view === "week" && (
            <div className="-mx-4 overflow-x-auto sm:mx-0">
              <div className="grid min-w-[760px] grid-cols-7 gap-2">
                {days.map((d, idx) => (
                  <div key={d} className={`rounded-lg border p-2 ${d === today ? "border-cobalt" : "border-line"}`}>
                    <p className="mb-2 text-xs font-bold uppercase tracking-[0.06em] text-mute">{WEEK[idx]} <span className={`num ml-1 ${d === today ? "text-cobalt" : "text-ink"}`}>{Number(d.slice(8))}</span></p>
                    <ul className="grid gap-1.5">
                      {(byDay.get(d) ?? []).map((i) => (
                        <li key={i.key} className={`rounded-md px-2 py-1.5 text-[12.5px] ${KIND_COLOR[i.kind] ?? KIND_COLOR.other} ${isOverdue(i) ? "ring-2 ring-red" : ""}`}>
                          <p className="num font-bold">{i.kind === "payment" ? "срок" : fmtTime(i.start)}</p>
                          {i.href ? <Link href={i.href} className="hover:underline">{i.title}</Link> : <p>{i.title}</p>}
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          )}

          {view === "list" && (
            items.length === 0 ? <Empty>{sp.filter === "overdue" ? "Няма просрочени задачи." : "Няма събития в този период."}</Empty> : (
              <ol>
                {items.map((i) => {
                  const late = isOverdue(i);
                  const st = i.kind === "payment" ? null : EVENT_STATUS[i.status];
                  const canAct = i.event && (isOwner || i.event.assignee_id === profile.id) && i.status !== "done";
                  return (
                    <li key={i.key} className="grid grid-cols-[88px_56px_1fr] items-start gap-3 border-t border-line py-3 first:border-0 sm:grid-cols-[110px_64px_1fr_auto]">
                      <span className={`num text-[13.5px] font-semibold ${i.day === today ? "text-cobalt" : late ? "text-red" : ""}`}>{fmtDate(`${i.day}T12:00:00Z`, { weekday: "short", day: "numeric", month: "short" })}</span>
                      <span className="num text-[13.5px] text-mute">{i.kind === "payment" ? "срок" : fmtTime(i.start)}</span>
                      <div className="min-w-0">
                        <p className="font-semibold">{i.href ? <Link href={i.href} className="hover:underline">{i.title}</Link> : i.title}</p>
                        <div className="mt-1 flex flex-wrap gap-1.5">
                          <span className={`rounded px-1.5 text-[11.5px] font-semibold leading-5 ${KIND_COLOR[i.kind] ?? KIND_COLOR.other}`}>{i.kind === "payment" ? "Плащане" : EVENT_KIND[i.kind]}</span>
                          {late ? <Tag tone="bad">Просрочено</Tag> : st && <Tag tone={st.tone}>{st.label}</Tag>}
                          {i.event?.recurrence && i.event.recurrence !== "none" && <Tag tone="idle">повтаря се</Tag>}
                        </div>
                        {i.event?.description && <p className="mt-1 text-[13.5px] text-mute">{i.event.description}</p>}
                      </div>
                      {canAct && i.event && (
                        <div className="col-span-3 sm:col-span-1"><StatusButtons id={i.event.id} status={i.status} owner={isOwner} /></div>
                      )}
                    </li>
                  );
                })}
              </ol>
            )
          )}
        </Section>

        {isOwner && (
          <Section title="Ново събитие или задача">
            <EventForm
              day={view === "list" ? isoDay(anchor) : today}
              units={(units ?? []).map((u) => ({ id: u.id, label: `ап. ${u.number}` }))}
              people={(members ?? []).map((m) => ({ id: m.user_id, label: `${(m.profiles as unknown as { full_name: string }).full_name} · ${ROLE[m.role as Role]}` }))}
            />
            <p className="mt-3 text-[13px] text-mute">Или кажете на асистента: „Направи график за профилактика на климатиците“.</p>
          </Section>
        )}
      </div>
    </main>
  );
}

function Chip({ i, late }: { i: CalItem; late: boolean }) {
  const body = (
    <span className={`block truncate rounded px-1.5 py-0.5 text-[11.5px] font-semibold ${KIND_COLOR[i.kind] ?? KIND_COLOR.other} ${late ? "ring-1 ring-red" : ""}`}>
      {i.kind !== "payment" && <span className="num mr-1 font-bold">{fmtTime(i.start)}</span>}
      {i.title}
    </span>
  );
  return <li>{i.href ? <Link href={i.href}>{body}</Link> : body}</li>;
}
