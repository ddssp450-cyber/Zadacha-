"use client";
import { useState } from "react";
import { ActionForm } from "@/components/form";
import { Field, input } from "@/components/ui";
import { invite } from "../actions";

export function InviteForm({ building, units, unit }: { building: string; units: { id: string; label: string }[]; unit?: string }) {
  const [role, setRole] = useState("tenant");
  return (
    <ActionForm action={invite} submit="Изпрати покана">
      <input type="hidden" name="building" value={building} />
      <Field label="Имейл"><input name="email" type="email" required className={input} /></Field>
      <Field label="Роля">
        <select name="role" className={input} value={role} onChange={(e) => setRole(e.target.value)}>
          <option value="tenant">Наемател</option>
          <option value="builder">Строител</option>
          <option value="technician">Майстор / техник</option>
        </select>
      </Field>
      {role === "tenant" && (
        <Field label="Апартамент">
          <select name="unit" required className={input} defaultValue={unit ?? ""}>
            <option value="" disabled>Изберете…</option>
            {units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
          </select>
        </Field>
      )}
    </ActionForm>
  );
}
