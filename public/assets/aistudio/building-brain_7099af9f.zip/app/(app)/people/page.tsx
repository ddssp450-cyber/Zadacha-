import { redirect } from "next/navigation";
import { meWithBuilding } from "@/lib/session";
import { fmtDate, ROLE, type Role } from "@/lib/vocab";
import { Empty, PageHead, Section, Table, Tag } from "@/components/ui";
import { InviteForm } from "./invite";

export default async function People({ searchParams }: { searchParams: Promise<{ unit?: string }> }) {
  const { supabase, building, isOwner } = await meWithBuilding();
  if (!isOwner) redirect("/");
  const { unit } = await searchParams;
  const [{ data: units }, { data: members }, { data: invites }] = await Promise.all([
    supabase.from("units").select("id, number, floor, tenant_id, profiles(full_name, email, phone)").eq("building_id", building.id).order("floor").order("number"),
    supabase.from("building_members").select("role, profiles(id, full_name, email, phone)").eq("building_id", building.id),
    supabase.from("invitations").select("id, email, role, created_at, accepted_at, units(number)").eq("building_id", building.id).order("created_at", { ascending: false }),
  ]);
  const tenants = (units ?? []).filter((u) => u.tenant_id);
  const pending = (invites ?? []).filter((i) => !i.accepted_at);

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-8">
      <PageHead title="Наематели и строители" sub={`${tenants.length} наематели · ${members?.length ?? 0} строители и майстори`} />
      <div className="grid gap-4 lg:grid-cols-[1fr_340px] lg:items-start">
        <div className="grid gap-4">
          <Section title="Наематели">
            {tenants.length === 0 ? <Empty>Още няма наематели.</Empty> : (
              <Table head={["Ап.", "Име", "Имейл", "Телефон"]}>
                {tenants.map((u) => {
                  const p = u.profiles as unknown as { full_name: string; email: string; phone: string | null };
                  return (
                    <tr key={u.id}>
                      <td className="font-plate text-[17px] font-bold text-cobalt">{u.number}</td>
                      <td className="font-semibold">{p.full_name}</td>
                      <td><a className="text-cobalt hover:underline" href={`mailto:${p.email}`}>{p.email}</a></td>
                      <td>{p.phone ?? "—"}</td>
                    </tr>
                  );
                })}
              </Table>
            )}
          </Section>
          <Section title="Строители и майстори">
            {!members?.length ? <Empty>Още няма строители и майстори.</Empty> : (
              <Table head={["Роля", "Име", "Имейл"]}>
                {members.map((m) => {
                  const p = m.profiles as unknown as { id: string; full_name: string; email: string };
                  return (
                    <tr key={p.id}>
                      <td><Tag tone="info">{ROLE[m.role as Role]}</Tag></td>
                      <td className="font-semibold">{p.full_name}</td>
                      <td><a className="text-cobalt hover:underline" href={`mailto:${p.email}`}>{p.email}</a></td>
                    </tr>
                  );
                })}
              </Table>
            )}
          </Section>
          {pending.length > 0 && (
            <Section title="Чакащи покани">
              <ul>
                {pending.map((i) => (
                  <li key={i.id} className="flex flex-wrap items-center gap-3 border-t border-line py-2.5 first:border-0">
                    <span className="font-semibold">{i.email}</span>
                    <Tag tone="wait">{ROLE[i.role as Role]}</Tag>
                    {(i.units as unknown as { number: string } | null) && <span className="text-sm text-mute">ап. {(i.units as unknown as { number: string }).number}</span>}
                    <span className="ml-auto text-sm text-mute">от {fmtDate(i.created_at)}</span>
                  </li>
                ))}
              </ul>
            </Section>
          )}
        </div>
        <Section title="Покана">
          <p className="mb-3 text-sm text-mute">Поканеният влиза с имейла си и автоматично получава достъп до своя апартамент или до сградата.</p>
          <InviteForm building={building.id} units={(units ?? []).filter((u) => !u.tenant_id).map((u) => ({ id: u.id, label: `ап. ${u.number}, ет. ${u.floor}` }))} unit={unit} />
        </Section>
      </div>
    </main>
  );
}
