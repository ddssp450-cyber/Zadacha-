"use client";
import { useState } from "react";
import { ActionForm, FileField, Submit } from "@/components/form";
import { btn, btnDanger, btnGhost, Field, input } from "@/components/ui";
import { addFiles, bookCost, comment, createEvent, reportRepair, setEventStatus, updateRepair } from "../actions";

type Opt = { id: string; label: string };

export function ReportForm({ building, builder, units, appliances }: { building: string; builder: boolean; units: Opt[]; appliances: Opt[] }) {
  return (
    <ActionForm action={reportRepair} submit={builder ? "Докладвай дефекта" : "Изпрати заявката"}>
      <Field label="Какъв е проблемът?"><input name="title" required className={input} placeholder="Бойлерът тече от фланеца" /></Field>
      <Field label="Подробности"><textarea name="description" rows={4} className={input} placeholder="Откога, колко често, какво сте опитали" /></Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Местоположение"><input name="location" className={input} placeholder="Баня, стълбище ет. 3…" /></Field>
        <Field label="Апартамент">
          <select name="unit" className={input} defaultValue="">
            <option value="">Общи части</option>
            {units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Уред">
          <select name="appliance" className={input} defaultValue="">
            <option value="">Няма</option>
            {appliances.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}
          </select>
        </Field>
        {builder && <Field label="Срок за отстраняване"><input name="due_date" type="date" className={input} /></Field>}
      </div>
      <Field label="Снимки"><FileField building={building} /></Field>
    </ActionForm>
  );
}

export function ApproveForm({ id, people, budget, due }: { id: string; people: Opt[]; budget?: number | null; due?: string | null }) {
  const [rejecting, setRejecting] = useState(false);
  return (
    <ActionForm action={updateRepair} className="grid gap-3">
      <input type="hidden" name="id" value={id} />
      <Field label="Отговорник">
        <select name="assignee" className={input} defaultValue="">
          <option value="">Не е назначен</option>
          {people.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Бюджет, €"><input name="budget" inputMode="decimal" defaultValue={budget ?? ""} className={`${input} num`} /></Field>
        <Field label="Срок"><input name="due_date" type="date" defaultValue={due ?? ""} className={input} /></Field>
      </div>
      <div className="flex flex-wrap gap-2">
        <Submit name="step" value="approve" className={btn}>Одобри</Submit>
        {rejecting ? <Submit name="step" value="reject" className={btnDanger}>Да, отхвърли</Submit> : (
          <button type="button" onClick={() => setRejecting(true)} className="text-sm font-semibold text-red">Отхвърли</button>
        )}
      </div>
    </ActionForm>
  );
}

export function ScheduleForm({ repair, unit, assignee }: { repair: string; unit: string | null; assignee: string | null }) {
  return (
    <ActionForm action={createEvent} submit="Насрочи в календара" submitClass={btnGhost} className="grid gap-3">
      <input type="hidden" name="repair" value={repair} />
      <input type="hidden" name="kind" value="repair" />
      {unit && <input type="hidden" name="unit" value={unit} />}
      {assignee && <input type="hidden" name="assignee" value={assignee} />}
      <Field label="Заглавие"><input name="title" required className={input} defaultValue="Посещение на майстор" /></Field>
      <div className="grid grid-cols-3 gap-2">
        <Field label="Дата"><input name="date" type="date" required className={input} /></Field>
        <Field label="От"><input name="time" type="time" required defaultValue="10:00" className={input} /></Field>
        <Field label="До"><input name="end" type="time" defaultValue="11:00" className={input} /></Field>
      </div>
    </ActionForm>
  );
}

export function ProposeVisitForm({ repair, unit }: { repair: string; unit: string | null }) {
  return (
    <ActionForm action={createEvent} submit="Предложи час" submitClass={btnGhost} className="grid gap-3">
      <input type="hidden" name="repair" value={repair} />
      <input type="hidden" name="kind" value="repair" />
      <input type="hidden" name="title" value="Посещение по ремонт" />
      {unit && <input type="hidden" name="unit" value={unit} />}
      <div className="grid grid-cols-3 gap-2">
        <Field label="Дата"><input name="date" type="date" required className={input} /></Field>
        <Field label="От"><input name="time" type="time" required defaultValue="10:00" className={input} /></Field>
        <Field label="До"><input name="end" type="time" defaultValue="11:00" className={input} /></Field>
      </div>
    </ActionForm>
  );
}

export function WorkForm({ id, building, status }: { id: string; building: string; status: string }) {
  return (
    <div className="grid gap-4">
      {(status === "approved" || status === "scheduled") && (
        <ActionForm action={updateRepair}>
          <input type="hidden" name="id" value={id} />
          <Submit name="step" value="start" className={btnGhost}>Започни работа</Submit>
        </ActionForm>
      )}
      <ActionForm action={updateRepair} className="grid gap-3">
        <input type="hidden" name="id" value={id} />
        <Field label="Какво е направено"><textarea name="result" rows={3} required className={input} /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Разход, €"><input name="cost" inputMode="decimal" className={`${input} num`} /></Field>
          <Field label="Материали"><input name="materials" className={input} /></Field>
        </div>
        <Field label="Снимки след ремонта"><FileField building={building} /></Field>
        <Submit name="step" value="finish" className={btn}>Приключи</Submit>
      </ActionForm>
    </div>
  );
}

export function UploadForm({ building, repair, kinds }: { building: string; repair: string; kinds: [string, string][] }) {
  return (
    <ActionForm action={addFiles} submit="Качи" submitClass={btnGhost} className="grid gap-3">
      <input type="hidden" name="building" value={building} />
      <input type="hidden" name="repair" value={repair} />
      <select name="kind" className={input}>
        {kinds.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
      </select>
      <FileField building={building} />
    </ActionForm>
  );
}

export function CommentForm({ repair }: { repair: string }) {
  return (
    <ActionForm action={comment} submit="Изпрати" submitClass={btnGhost} className="grid gap-2">
      <input type="hidden" name="repair" value={repair} />
      <textarea name="body" rows={2} required className={input} placeholder="Въпрос или бележка" aria-label="Коментар" />
    </ActionForm>
  );
}

export function EventStatusButtons({ id, approve }: { id: string; approve: boolean }) {
  return (
    <ActionForm action={setEventStatus} className="flex gap-2">
      <input type="hidden" name="id" value={id} />
      {approve && <Submit name="status" value="planned" className={btnGhost}>Одобри часа</Submit>}
      <Submit name="status" value="cancelled" className="text-[13px] font-semibold text-mute hover:text-red">Откажи</Submit>
    </ActionForm>
  );
}

export function BookCostButton({ id }: { id: string }) {
  return (
    <ActionForm action={bookCost}>
      <input type="hidden" name="id" value={id} />
      <Submit className={btnGhost}>Запиши в разходите</Submit>
    </ActionForm>
  );
}
