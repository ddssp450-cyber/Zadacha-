import Link from "next/link";
import { notFound } from "next/navigation";
import { FileText } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { eur, EVENT_STATUS, fmtDate, fmtTime, isoDay, REPAIR, ROLE, type RepairStatus, type Role } from "@/lib/vocab";
import { Empty, PageHead, Section, Tag, TextLink } from "@/components/ui";
import { ApproveForm, BookCostButton, CommentForm, EventStatusButtons, ProposeVisitForm, ScheduleForm, UploadForm, WorkForm } from "../forms";

const KIND: Record<string, string> = { photo: "Снимка", before: "Преди", after: "След", report: "Отчет", document: "Документ", invoice: "Фактура" };

export default async function RepairPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { supabase, building, profile, isOwner } = await meWithBuilding();
  const { data: r } = await supabase
    .from("repairs")
    .select("*, units(number, floor), appliances(id, name, model), reporter:profiles!repairs_reported_by_fkey(full_name, role), assignee:profiles!repairs_assignee_id_fkey(full_name)")
    .eq("id", id)
    .maybeSingle();
  if (!r) notFound();

  const [{ data: files }, { data: comments }, { data: events }, { data: members }, { data: booked }] = await Promise.all([
    supabase.from("files").select("id, path, name, kind, created_at").eq("repair_id", id).order("created_at"),
    supabase.from("comments").select("id, body, created_at, author_id, profiles(full_name, role)").eq("repair_id", id).order("created_at"),
    supabase.from("events").select("id, title, starts_at, ends_at, status").eq("repair_id", id).order("starts_at"),
    isOwner ? supabase.from("building_members").select("user_id, role, profiles(full_name)").eq("building_id", building.id) : Promise.resolve({ data: [] }),
    isOwner ? supabase.from("expenses").select("id").eq("repair_id", id) : Promise.resolve({ data: [] }),
  ]);
  const signed = files?.length ? (await supabase.storage.from("files").createSignedUrls(files.map((f) => f.path), 900)).data ?? [] : [];
  const url = new Map(signed.map((s) => [s.path, s.signedUrl ?? undefined]));

  const unit = r.units as { number: string; floor: number } | null;
  const status = r.status as RepairStatus;
  const late = r.due_date && r.due_date < isoDay() && status !== "done";
  const mine = r.assignee_id === profile.id;
  const canWork = (mine || (profile.role === "builder" && r.kind === "defect")) && ["approved", "scheduled", "in_progress", "new"].includes(status) && !(status === "new" && profile.role !== "builder");

  return (
    <main className="px-4 py-6 sm:px-8">
      <Link href="/repairs" className="text-sm font-semibold text-cobalt">← Всички ремонти</Link>
      <PageHead
        title={`${r.code} · ${r.title}`}
        sub={<>{r.kind === "defect" ? "Дефект" : "Ремонт"} · {unit ? `ап. ${unit.number}, ет. ${unit.floor}` : "общи части"}{r.location ? ` · ${r.location}` : ""}</>}
      >
        <Tag tone={late ? "bad" : REPAIR[status].tone}>{late ? "Просрочен срок" : REPAIR[status].label}</Tag>
      </PageHead>

      <div className="grid gap-4 xl:grid-cols-[1fr_380px] xl:items-start">
        <div className="grid gap-4">
          <Section title="Детайли">
            <dl className="grid gap-x-6 gap-y-3 text-[14.5px] sm:grid-cols-3">
              <Item k="Подаден от" v={`${(r.reporter as { full_name: string; role: Role } | null)?.full_name ?? "—"} · ${fmtDate(r.created_at)}`} />
              <Item k="Отговорник" v={(r.assignee as { full_name: string } | null)?.full_name ?? "не е назначен"} />
              <Item k="Срок" v={r.due_date ? fmtDate(r.due_date, { day: "numeric", month: "long" }) : "—"} bad={!!late} />
              <Item k="Бюджет" v={r.budget ? eur(r.budget) : "—"} />
              <Item k="Разход" v={r.cost ? eur(r.cost) : "—"} />
              <Item k="Уред" v={r.appliances ? <TextLink href={`/appliances/${(r.appliances as { id: string }).id}`}>{(r.appliances as { name: string }).name}</TextLink> : "—"} />
            </dl>
            {r.description && <p className="mt-4 max-w-[70ch] whitespace-pre-wrap leading-relaxed">{r.description}</p>}
            {(r.result || r.materials) && (
              <div className="mt-4 rounded-lg bg-green-soft p-3 text-[14.5px]">
                {r.result && <p><b>Резултат:</b> {r.result}</p>}
                {r.materials && <p><b>Материали:</b> {r.materials}</p>}
              </div>
            )}
          </Section>

          <Section title="Снимки и документи">
            {!files?.length ? <Empty>Още няма прикачени файлове.</Empty> : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                {files.map((f) => {
                  const u = url.get(f.path);
                  const img = /\.(jpe?g|png|webp|gif|heic)$/i.test(f.name);
                  return (
                    <a key={f.id} href={u} target="_blank" rel="noreferrer" className="group overflow-hidden rounded-lg border border-line bg-ground">
                      {img && u ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={u} alt={`${KIND[f.kind]}: ${f.name}`} className="aspect-[4/3] w-full object-cover" />
                      ) : (
                        <div className="grid aspect-[4/3] place-items-center text-mute"><FileText className="size-8" /></div>
                      )}
                      <p className="flex items-center justify-between gap-2 px-2 py-1.5 text-xs">
                        <Tag tone={f.kind === "after" ? "ok" : f.kind === "before" ? "wait" : "idle"}>{KIND[f.kind]}</Tag>
                        <span className="truncate text-mute">{f.name}</span>
                      </p>
                    </a>
                  );
                })}
              </div>
            )}
            {status !== "rejected" && (
              <div className="mt-4 border-t border-line pt-4">
                <UploadForm building={building.id} repair={r.id} kinds={profile.role === "builder" ? [["report", "Отчет"], ["photo", "Снимка"], ["document", "Документ"]] : [["photo", "Снимка"], ["before", "Преди"], ["after", "След"], ["invoice", "Фактура"], ["document", "Документ"]]} />
              </div>
            )}
          </Section>

          <Section title="Коментари">
            {!comments?.length ? <Empty>Няма коментари.</Empty> : (
              <ul className="mb-3 grid gap-3">
                {comments.map((c) => {
                  const a = c.profiles as unknown as { full_name: string; role: Role };
                  return (
                    <li key={c.id} className={`max-w-[85%] rounded-xl px-3.5 py-2.5 ${c.author_id === profile.id ? "ml-auto bg-cobalt-soft" : "bg-ground"}`}>
                      <p className="text-xs text-mute">{a.full_name} · {ROLE[a.role]} · {fmtDate(c.created_at)} {fmtTime(c.created_at)}</p>
                      <p className="mt-0.5 whitespace-pre-wrap">{c.body}</p>
                    </li>
                  );
                })}
              </ul>
            )}
            <CommentForm repair={r.id} />
          </Section>
        </div>

        <div className="grid gap-4">
          {isOwner && (status === "new" || status === "approved") && (
            <Section title={status === "new" ? "Одобрение" : "Назначение"}>
              <ApproveForm id={r.id} budget={r.budget} due={r.due_date} people={(members ?? []).map((m) => ({ id: m.user_id, label: `${(m.profiles as unknown as { full_name: string }).full_name} · ${ROLE[m.role as Role]}` }))} />
            </Section>
          )}
          {canWork && (
            <Section title="Работа">
              <WorkForm id={r.id} building={building.id} status={status} />
            </Section>
          )}
          {isOwner && status === "done" && r.cost && !booked?.length && (
            <Section title="Разход">
              <p className="mb-3 text-sm text-mute">Майсторът отчете {eur(r.cost)}. Запишете го в разходите на сградата.</p>
              <BookCostButton id={r.id} />
            </Section>
          )}
          <Section title="Календар">
            {!events?.length ? <Empty>Няма насрочени посещения.</Empty> : (
              <ul className="mb-3">
                {events.map((e) => (
                  <li key={e.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-line py-2.5 first:border-0">
                    <span className="num font-semibold">{fmtDate(e.starts_at, { weekday: "short", day: "numeric", month: "short" })} {fmtTime(e.starts_at)}</span>
                    <Tag tone={EVENT_STATUS[e.status].tone}>{EVENT_STATUS[e.status].label}</Tag>
                    {isOwner && e.status === "proposed" && <EventStatusButtons id={e.id} approve />}
                  </li>
                ))}
              </ul>
            )}
            {isOwner && status !== "done" && status !== "rejected" && <ScheduleForm repair={r.id} unit={r.unit_id} assignee={r.assignee_id} />}
            {profile.role === "technician" && mine && status !== "done" && <ProposeVisitForm repair={r.id} unit={r.unit_id} />}
          </Section>
        </div>
      </div>
    </main>
  );
}

function Item({ k, v, bad }: { k: string; v: React.ReactNode; bad?: boolean }) {
  return (
    <div>
      <dt className="text-[13px] text-mute">{k}</dt>
      <dd className={`font-semibold ${bad ? "text-red" : ""}`}>{v}</dd>
    </div>
  );
}
