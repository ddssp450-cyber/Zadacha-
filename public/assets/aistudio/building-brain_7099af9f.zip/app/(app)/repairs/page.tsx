import Link from "next/link";
import { Plus } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { eur, fmtDate, isoDay, REPAIR, type RepairStatus } from "@/lib/vocab";
import { btn, Empty, PageHead, Section, Table, Tag } from "@/components/ui";

const FILTERS: [string, string][] = [["open", "Отворени"], ["new", "Нови"], ["done", "Приключени"], ["all", "Всички"]];

export default async function Repairs({ searchParams }: { searchParams: Promise<{ f?: string; unit?: string }> }) {
  const { supabase, building, profile } = await meWithBuilding();
  const { f = "open", unit } = await searchParams;
  let q = supabase
    .from("repairs")
    .select("id, code, kind, title, location, status, due_date, budget, cost, created_at, units(number), assignee:profiles!repairs_assignee_id_fkey(full_name)")
    .eq("building_id", building.id)
    .order("created_at", { ascending: false });
  if (f === "open") q = q.not("status", "in", "(done,rejected)");
  else if (f !== "all") q = q.eq("status", f);
  if (unit) q = q.eq("unit_id", unit);
  const { data } = await q;
  const today = isoDay();
  const title = profile.role === "builder" ? "Дефекти и задачи" : profile.role === "tenant" ? "Сигнали и ремонти" : "Ремонти";

  return (
    <main className="px-4 py-6 sm:px-8">
      <PageHead title={title} sub={`${data?.length ?? 0} в изгледа`}>
        {profile.role !== "technician" && (
          <Link href="/repairs/new" className={btn}>
            <Plus className="size-4" aria-hidden /> {profile.role === "builder" ? "Докладвай дефект" : profile.role === "tenant" ? "Подай сигнал" : "Нова заявка"}
          </Link>
        )}
      </PageHead>
      <Section title="Заявки">
        <nav aria-label="Филтър" className="mb-3 flex flex-wrap gap-1.5">
          {FILTERS.map(([k, label]) => (
            <Link key={k} href={`/repairs?f=${k}`} aria-current={f === k ? "true" : undefined}
              className={`rounded-full px-3 py-1 text-[13px] font-semibold ${f === k ? "bg-cobalt text-white" : "bg-ground text-mute hover:text-ink"}`}>
              {label}
            </Link>
          ))}
        </nav>
        {!data?.length ? <Empty>Няма заявки в този изглед.</Empty> : (
          <Table head={["№", "Проблем", "Къде", "Отговорник", "Срок", "Бюджет / разход", "Статус"]}>
            {data.map((r) => {
              const u = r.units as unknown as { number: string } | null;
              const late = r.due_date && r.due_date < today && r.status !== "done";
              return (
                <tr key={r.id}>
                  <td className="num font-plate text-[15px] font-bold text-cobalt"><Link href={`/repairs/${r.id}`}>{r.code}</Link></td>
                  <td>
                    <Link href={`/repairs/${r.id}`} className="font-semibold hover:underline">{r.title}</Link>
                    {r.kind === "defect" && <span className="ml-2"><Tag tone="idle">дефект</Tag></span>}
                  </td>
                  <td className="text-mute">{u ? `ап. ${u.number}` : r.location || "—"}</td>
                  <td>{(r.assignee as unknown as { full_name: string } | null)?.full_name ?? <span className="text-mute">—</span>}</td>
                  <td className={`num whitespace-nowrap ${late ? "font-semibold text-red" : ""}`}>{r.due_date ? fmtDate(r.due_date) : "—"}</td>
                  <td className="num whitespace-nowrap">{r.budget ? eur(r.budget) : "—"}{r.cost ? <span className="block text-xs text-mute">разход {eur(r.cost)}</span> : null}</td>
                  <td><Tag tone={late ? "bad" : REPAIR[r.status as RepairStatus].tone}>{late ? "Просрочен срок" : REPAIR[r.status as RepairStatus].label}</Tag></td>
                </tr>
              );
            })}
          </Table>
        )}
      </Section>
    </main>
  );
}
