import { redirect } from "next/navigation";
import { meWithBuilding } from "@/lib/session";
import { PageHead, Section } from "@/components/ui";
import { ReportForm } from "../forms";

export default async function NewRepair() {
  const { supabase, building, profile } = await meWithBuilding();
  if (profile.role === "technician") redirect("/repairs");
  const [{ data: units }, { data: apps }] = await Promise.all([
    supabase.from("units").select("id, number, floor").eq("building_id", building.id).order("floor").order("number"),
    supabase.from("appliances").select("id, name, units(number)").eq("building_id", building.id),
  ]);
  const builder = profile.role === "builder";
  return (
    <main className="mx-auto max-w-2xl px-4 py-6 sm:px-8">
      <PageHead title={builder ? "Нов дефект" : profile.role === "tenant" ? "Нов сигнал" : "Нова ремонтна заявка"} sub="Получава уникален номер и статус. Собственикът одобрява и назначава." />
      <Section title="Описание">
        <ReportForm
          building={building.id}
          builder={builder}
          units={(units ?? []).map((u) => ({ id: u.id, label: `ап. ${u.number}, ет. ${u.floor}` }))}
          appliances={(apps ?? []).map((a) => ({ id: a.id, label: `${a.name}${(a.units as unknown as { number: string } | null) ? `, ап. ${(a.units as unknown as { number: string }).number}` : ""}` }))}
        />
      </Section>
    </main>
  );
}
