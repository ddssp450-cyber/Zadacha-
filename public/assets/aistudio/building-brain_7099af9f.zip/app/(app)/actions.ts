"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/lib/supabase";
import { me } from "@/lib/session";
import type { ActionState } from "@/components/form";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const opt = (fd: FormData, k: string) => s(fd, k) || null;
const num = (fd: FormData, k: string) => {
  const v = s(fd, k).replace(",", ".");
  return v === "" ? null : Number(v);
};
const paths = (fd: FormData) => fd.getAll("paths").map(String).filter(Boolean);
// Stored as <building>/<uuid>-<name>.
const fileName = (p: string) => p.split("/").pop()!.slice(37);

function done(ok: string): ActionState {
  revalidatePath("/", "layout");
  return { ok };
}
function fail(e: { message: string } | null | undefined, fallback = "Действието не успя"): ActionState {
  const m = e?.message ?? fallback;
  if (/row-level security|permission denied/i.test(m)) return { error: "Нямате права за това действие." };
  if (/duplicate key/i.test(m)) return { error: "Такъв запис вече съществува." };
  return { error: m };
}
/** Sofia wall-clock date + time to an ISO instant. */
function sofiaInstant(date: string, time: string) {
  const guess = new Date(`${date}T${time || "09:00"}:00Z`);
  const local = new Date(guess.toLocaleString("en-US", { timeZone: "Europe/Sofia" }));
  return new Date(guess.getTime() - (local.getTime() - guess.getTime())).toISOString();
}

export async function signOut() {
  await (await db()).auth.signOut();
  redirect("/login");
}

export async function createBuilding(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, profile } = await me();
  const name = s(fd, "name");
  if (!name) return { error: "Въведете име на сградата." };
  const { data, error } = await supabase.from("buildings").insert({ name, address: s(fd, "address"), owner_id: profile.id }).select("id").single();
  if (error) return fail(error);
  const floors = Number(s(fd, "floors") || 0);
  const per = Number(s(fd, "per_floor") || 0);
  if (floors > 0 && per > 0 && floors * per <= 400) {
    let n = 1;
    const units = [];
    for (let f = 1; f <= floors; f++) for (let i = 0; i < per; i++) units.push({ building_id: data.id, floor: f, number: String(n++) });
    await supabase.from("units").insert(units);
  }
  return done("Сградата е създадена.");
}

export async function createUnit(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const number = s(fd, "number");
  if (!number) return { error: "Въведете номер на апартамента." };
  const { error } = await supabase.from("units").insert({
    building_id: s(fd, "building"), number, floor: Number(s(fd, "floor") || 1), entrance: s(fd, "entrance") || "А", area: num(fd, "area"),
  });
  return error ? fail(error) : done(`Апартамент ${number} е добавен.`);
}

export async function invite(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const email = s(fd, "email").toLowerCase();
  const role = s(fd, "role");
  if (!/^\S+@\S+\.\S+$/.test(email)) return { error: "Невалиден имейл." };
  if (role === "tenant" && !s(fd, "unit")) return { error: "Изберете апартамент за наемателя." };
  const { error } = await supabase.from("invitations").insert({ email, role, building_id: s(fd, "building"), unit_id: role === "tenant" ? s(fd, "unit") : null });
  return error ? fail(error) : done(`Поканата е записана. ${email} влиза с имейла си и получава достъп автоматично.`);
}

export async function createPayment(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, building } = await me();
  const amount = num(fd, "amount");
  if (!amount || amount <= 0) return { error: "Въведете сума над 0." };
  if (!s(fd, "due_date")) return { error: "Изберете краен срок." };
  const units = s(fd, "unit") === "all"
    ? ((await supabase.from("units").select("id, tenant_id").eq("building_id", building!.id).not("tenant_id", "is", null)).data ?? [])
    : ((await supabase.from("units").select("id, tenant_id").eq("id", s(fd, "unit"))).data ?? []);
  if (!units.length) return { error: "Няма апартамент с наемател." };
  const rows = units.map((u) => ({
    building_id: building!.id, unit_id: u.id, tenant_id: u.tenant_id, kind: s(fd, "kind") || "rent",
    title: s(fd, "title") || "Наем", amount, period: s(fd, "period"), due_date: s(fd, "due_date"),
  }));
  const { error } = await supabase.from("payments").insert(rows);
  return error ? fail(error) : done(rows.length > 1 ? `Създадени ${rows.length} задължения.` : "Задължението е създадено.");
}

export async function declarePayment(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const paid = num(fd, "paid");
  if (!paid || paid <= 0) return { error: "Въведете платената сума." };
  const extracted = s(fd, "extracted");
  const { error } = await supabase.rpc("declare_payment", {
    p_id: s(fd, "id"), p_paid: paid, p_proof: paths(fd)[0] ?? null, p_extracted: extracted ? JSON.parse(extracted) : null,
  });
  return error ? fail(error) : done("Плащането е отбелязано. Собственикът ще го провери.");
}

export async function reviewPayment(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const approve = s(fd, "decision") === "approve";
  const note = opt(fd, "note");
  if (!approve && !note) return { error: "Напишете причина за отказа, за да я види наемателят." };
  const { error } = await supabase.rpc("review_payment", { p_id: s(fd, "id"), p_approve: approve, p_note: note });
  return error ? fail(error) : done(approve ? "Плащането е потвърдено." : "Плащането е отхвърлено.");
}

export async function remind(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const { data: p } = await supabase.from("payments").select("id, building_id, tenant_id, title, amount, paid_amount, due_date").eq("id", s(fd, "id")).single();
  if (!p?.tenant_id) return { error: "Няма наемател за това задължение." };
  const { error } = await supabase.from("notifications").insert({
    building_id: p.building_id, user_id: p.tenant_id, link: `/payments#${p.id}`,
    body: `Напомняне: ${p.title}, ${Number(p.amount) - Number(p.paid_amount)} €, срок ${p.due_date}`,
  });
  return error ? fail(error) : done("Напомнянето е изпратено.");
}

export async function createAppliance(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, building } = await me();
  const name = s(fd, "name");
  if (!name) return { error: "Въведете име на уреда." };
  const { data, error } = await supabase.from("appliances").insert({
    building_id: building!.id, unit_id: opt(fd, "unit"), name, kind: s(fd, "kind") || "other", model: s(fd, "model"), serial: s(fd, "serial"),
    warranty_until: opt(fd, "warranty_until"), next_service: opt(fd, "next_service"), notes: s(fd, "notes"), photo_path: paths(fd)[0] ?? null,
  }).select("id").single();
  if (error) return fail(error);
  const docs = paths(fd).slice(1);
  if (docs.length) await supabase.from("files").insert(docs.map((p) => ({ building_id: building!.id, appliance_id: data.id, path: p, name: fileName(p), kind: "document" })));
  return done("Уредът е добавен.");
}

export async function addFiles(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const list = paths(fd);
  if (!list.length) return { error: "Прикачете поне един файл." };
  const { error } = await supabase.from("files").insert(list.map((p) => ({
    building_id: s(fd, "building"), repair_id: opt(fd, "repair"), appliance_id: opt(fd, "appliance"),
    path: p, name: fileName(p), kind: s(fd, "kind") || "photo",
  })));
  return error ? fail(error) : done("Файловете са качени.");
}

export async function reportRepair(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, building, profile } = await me();
  const title = s(fd, "title");
  if (!title) return { error: "Опишете накратко проблема." };
  const { data, error } = await supabase.from("repairs").insert({
    building_id: building!.id, title, description: s(fd, "description"), location: s(fd, "location"),
    unit_id: opt(fd, "unit"), appliance_id: opt(fd, "appliance"), due_date: profile.role === "builder" ? opt(fd, "due_date") : null,
    kind: profile.role === "builder" ? "defect" : "repair", reported_by: profile.id,
    ...(profile.role === "builder" && { assignee_id: null }),
  }).select("id, code").single();
  if (error) return fail(error);
  const list = paths(fd);
  if (list.length) await supabase.from("files").insert(list.map((p) => ({ building_id: building!.id, repair_id: data.id, path: p, name: fileName(p), kind: "before" })));
  revalidatePath("/", "layout");
  redirect(`/repairs/${data.id}`);
}

export async function updateRepair(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const id = s(fd, "id");
  const step = s(fd, "step");
  const patch: Record<string, unknown> = {};
  if (step === "approve") {
    Object.assign(patch, { status: "approved", assignee_id: opt(fd, "assignee"), budget: num(fd, "budget"), due_date: opt(fd, "due_date") });
  } else if (step === "reject") patch.status = "rejected";
  else if (step === "start") patch.status = "in_progress";
  else if (step === "finish") {
    if (!s(fd, "result")) return { error: "Опишете какво е направено." };
    Object.assign(patch, { status: "done", cost: num(fd, "cost"), materials: s(fd, "materials"), result: s(fd, "result") });
  } else return { error: "Непознато действие." };
  const { data: r, error } = await supabase.from("repairs").update(patch).eq("id", id).select("id, building_id, code, cost").single();
  if (error) return fail(error);
  const list = paths(fd);
  if (list.length) await supabase.from("files").insert(list.map((p) => ({ building_id: r.building_id, repair_id: id, path: p, name: fileName(p), kind: step === "finish" ? "after" : "photo" })));
  return done(step === "finish" ? `${r.code} е приключен.` : "Заявката е обновена.");
}

export async function bookCost(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const { data: r } = await supabase.from("repairs").select("id, building_id, code, title, cost").eq("id", s(fd, "id")).single();
  if (!r?.cost) return { error: "Няма записан разход." };
  const { error } = await supabase.from("expenses").insert({ building_id: r.building_id, repair_id: r.id, category: "repair", amount: r.cost, note: `${r.code} ${r.title}` });
  return error ? fail(error) : done("Разходът е записан.");
}

export async function comment(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, profile } = await me();
  const body = s(fd, "body");
  if (!body) return { error: "Напишете съобщение." };
  const { error } = await supabase.from("comments").insert({ repair_id: s(fd, "repair"), body, author_id: profile.id });
  return error ? fail(error) : done("Изпратено.");
}

export async function createEvent(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, building, profile } = await me();
  const title = s(fd, "title");
  const date = s(fd, "date");
  if (!title || !date) return { error: "Въведете заглавие и дата." };
  const owner = profile.role === "owner";
  const repair = opt(fd, "repair");
  const { error } = await supabase.from("events").insert({
    building_id: building!.id, title, kind: s(fd, "kind") || (repair ? "repair" : "other"),
    description: s(fd, "description"), unit_id: opt(fd, "unit"), repair_id: repair,
    starts_at: sofiaInstant(date, s(fd, "time")), ends_at: s(fd, "end") ? sofiaInstant(date, s(fd, "end")) : null,
    assignee_id: owner ? opt(fd, "assignee") : profile.id, status: owner ? "planned" : "proposed",
    recurrence: owner ? s(fd, "recurrence") || "none" : "none", created_by: profile.id,
  });
  if (error) return fail(error);
  if (owner && repair) await supabase.from("repairs").update({ status: "scheduled" }).eq("id", repair).in("status", ["new", "approved"]);
  return done(owner ? "Събитието е в календара." : "Предложението е изпратено на собственика.");
}

export async function setEventStatus(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase } = await me();
  const status = s(fd, "status");
  const { data, error } = await supabase.from("events").update({ status }).eq("id", s(fd, "id")).select("repair_id").single();
  if (error) return fail(error);
  if (status === "planned" && data.repair_id) await supabase.from("repairs").update({ status: "scheduled" }).eq("id", data.repair_id).in("status", ["new", "approved"]);
  return done("Запазено.");
}

export async function createExpense(_: ActionState, fd: FormData): Promise<ActionState> {
  const { supabase, building } = await me();
  const amount = num(fd, "amount");
  if (amount == null || amount < 0) return { error: "Въведете сума." };
  const { error } = await supabase.from("expenses").insert({
    building_id: building!.id, amount, category: s(fd, "category") || "other", spent_on: s(fd, "spent_on") || undefined,
    note: s(fd, "note"), repair_id: opt(fd, "repair"), file_path: paths(fd)[0] ?? null,
  });
  return error ? fail(error) : done("Разходът е записан.");
}

export async function markRead() {
  const { supabase, profile } = await me();
  await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("user_id", profile.id).is("read_at", null);
  revalidatePath("/", "layout");
}
