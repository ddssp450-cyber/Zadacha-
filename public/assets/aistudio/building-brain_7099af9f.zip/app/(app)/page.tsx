import Link from "next/link";
import { me } from "@/lib/session";
import { collectBrief } from "@/lib/brief";
import { eur, fmtDate, isoDay, PAY, payStatus, REPAIR, type PayStatus, type RepairStatus } from "@/lib/vocab";
import { BriefColumn } from "@/components/brief";
import { Empty, Section, Tag, TextLink } from "@/components/ui";
import { CreateBuildingForm } from "./buildings/forms";

type Unit = { id: string; number: string; floor: number; entrance: string; tenant_id: string | null; profiles: { full_name: string } | null };

function greeting() {
  const h = Number(new Date().toLocaleString("en-GB", { hour: "2-digit", hour12: false, timeZone: "Europe/Sofia" }));
  return h < 11 ? "Добро утро" : h < 18 ? "Добър ден" : "Добър вечер";
}

export default async function Dashboard() {
  const { supabase, profile, building } = await me();
  const first = profile.full_name.split(" ")[0];
  const today = isoDay();
  const dateLine = fmtDate(new Date(), { weekday: "long", day: "numeric", month: "long" });

  if (!building) {
    return (
      <main className="mx-auto max-w-xl px-4 py-10">
        <h1 className="font-plate text-[34px] font-extrabold">{greeting()}, {first}</h1>
        {profile.role === "owner" ? (
          <>
            <p className="mb-6 mt-1 text-mute">Започнете със сградата. Апартаментите се създават заедно с нея.</p>
            <Section title="Нова сграда"><CreateBuildingForm /></Section>
          </>
        ) : (
          <p className="mt-2 text-mute">Още нямате достъп до сграда. Помолете собственика да ви покани с имейла {profile.email}.</p>
        )}
      </main>
    );
  }

  const brief = await collectBrief(supabase, profile, building.id);
  const waiting = brief.items.filter((i) => i.tone === "bad" || i.tone === "wait").length;

  const [{ data: units }, { data: pays }, { data: repairs }] = await Promise.all([
    supabase.from("units").select("id, number, floor, entrance, tenant_id, profiles(full_name)").eq("building_id", building.id).order("floor", { ascending: false }).returns<Unit[]>(),
    supabase.from("payments").select("id, unit_id, status, due_date, amount, paid_amount, title").eq("building_id", building.id).eq("kind", "rent").eq("period", today.slice(0, 7)),
    supabase.from("repairs").select("id, code, title, unit_id, status, kind, due_date").eq("building_id", building.id).not("status", "in", "(done,rejected)").order("created_at", { ascending: false }),
  ]);

  const rentBy = new Map((pays ?? []).map((p) => [p.unit_id, p]));
  const repairBy = new Map<string, number>();
  for (const r of repairs ?? []) if (r.unit_id) repairBy.set(r.unit_id, (repairBy.get(r.unit_id) ?? 0) + 1);
  const floors = new Map<number, Unit[]>();
  for (const u of units ?? []) floors.set(u.floor, [...(floors.get(u.floor) ?? []), u]);
  const showMoney = profile.role === "owner";

  return (
    <div className="xl:grid xl:grid-cols-[1fr_380px]">
      <main className="min-w-0 px-4 py-6 sm:px-8">
        <header className="mb-6">
          <h1 className="font-plate text-[34px] font-extrabold leading-tight tracking-[-0.01em]">
            {greeting()}, {first}
          </h1>
          <p className="text-[15px] text-mute first-letter:uppercase">
            {dateLine} · {waiting === 0 ? "нищо спешно" : waiting === 1 ? "1 нещо чака вас" : `${waiting} неща чакат вас`}
          </p>
        </header>

        {profile.role === "tenant" ? (
          <TenantHome units={units ?? []} rentBy={rentBy} repairs={repairs ?? []} today={today} />
        ) : (
          <>
            <Section
              title={`Фасада · вход ${units?.[0]?.entrance ?? "А"}`}
              action={showMoney ? <Legend /> : <span className="text-xs text-mute">жълта рамка = отворен ремонт</span>}
            >
              {floors.size === 0 ? (
                <Empty>Няма апартаменти. <TextLink href="/buildings">Добавете ги</TextLink>.</Empty>
              ) : (
                <div className="grid gap-2">
                  {[...floors.entries()].map(([floor, list]) => (
                    <div key={floor} className="grid grid-cols-[44px_1fr] items-stretch gap-2">
                      <div className="flex items-center font-plate text-[13px] font-bold text-mute">ЕТ {floor}</div>
                      <div className="grid grid-cols-[repeat(auto-fill,minmax(118px,1fr))] gap-2">
                        {list.map((u) => {
                          const rent = rentBy.get(u.id);
                          const st = rent ? payStatus(rent as { status: PayStatus; due_date: string }, today) : null;
                          const open = repairBy.get(u.id);
                          const href = showMoney ? (rent ? `/payments?unit=${u.id}` : `/buildings#u-${u.id}`) : `/repairs?unit=${u.id}`;
                          return (
                            <Link
                              key={u.id}
                              href={href}
                              className={`plate relative block min-h-[66px] px-3 py-2.5 transition-transform hover:-translate-y-0.5 ${!u.tenant_id ? "plate-empty" : ""} ${open ? "plate-flag" : ""}`}
                            >
                              <b className="font-plate text-[24px] font-extrabold leading-none">{u.number}</b>
                              <span className="mt-1 block truncate text-[12.5px] opacity-90">{u.profiles?.full_name.split(" ").at(-1) ?? "свободен"}</span>
                              {showMoney && st && <PlateTab status={st} />}
                              {!showMoney && open && <span className="absolute right-2 top-2 rounded bg-amber px-1.5 text-[10.5px] font-bold text-ink">ремонт</span>}
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Section>

            {showMoney && (
              <dl className="mt-4 grid gap-px overflow-hidden rounded-xl border border-line bg-line sm:grid-cols-3">
                {brief.stats.map((s) => (
                  <div key={s.label} className="bg-paper px-4 py-3">
                    <dt className="text-[13px] text-mute">{s.label}</dt>
                    <dd className={`num font-plate text-[28px] font-extrabold leading-tight ${s.tone === "bad" ? "text-red" : ""}`}>{s.value}</dd>
                  </div>
                ))}
              </dl>
            )}

            <Section title={profile.role === "builder" ? "Дефекти и задачи" : "Отворени ремонти"} className="mt-4" action={<TextLink href="/repairs">Всички</TextLink>}>
              <RepairList repairs={repairs ?? []} />
            </Section>
          </>
        )}
      </main>
      <BriefColumn profile={profile} brief={brief} />
    </div>
  );
}

function PlateTab({ status }: { status: PayStatus }) {
  const cls: Record<string, string> = {
    ok: "bg-white text-cobalt",
    wait: "bg-amber text-ink",
    bad: "bg-red text-white",
    idle: "bg-white/20 text-white",
    info: "bg-white text-cobalt",
  };
  return <span className={`absolute right-2 top-2 rounded px-1.5 text-[10.5px] font-bold leading-[18px] ${cls[PAY[status].tone]}`}>{PAY[status].short}</span>;
}

function Legend() {
  return (
    <span className="hidden flex-wrap gap-3 text-xs text-mute sm:flex">
      <span>Наем за месеца</span>
      <span className="flex items-center gap-1"><i className="size-2 rounded-full bg-amber" /> за проверка</span>
      <span className="flex items-center gap-1"><i className="size-2 rounded-full bg-red" /> просрочено</span>
      <span className="flex items-center gap-1"><i className="size-2 rounded-sm border-2 border-amber" /> ремонт</span>
    </span>
  );
}

type R = { id: string; code: string; title: string; status: string; kind: string; due_date: string | null };
function RepairList({ repairs }: { repairs: R[] }) {
  if (!repairs.length) return <Empty>Няма отворени ремонти.</Empty>;
  return (
    <ul>
      {repairs.slice(0, 6).map((r) => (
        <li key={r.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-line py-2.5 first:border-0">
          <span className="num w-[58px] font-plate text-[15px] font-bold text-cobalt">{r.code}</span>
          <Link href={`/repairs/${r.id}`} className="min-w-0 flex-1 truncate font-semibold hover:underline">{r.title}</Link>
          {r.kind === "defect" && <Tag tone="idle">дефект</Tag>}
          {r.due_date && <span className="text-[13px] text-mute">срок {fmtDate(r.due_date)}</span>}
          <Tag tone={REPAIR[r.status as RepairStatus].tone}>{REPAIR[r.status as RepairStatus].label}</Tag>
        </li>
      ))}
    </ul>
  );
}

function TenantHome({ units, rentBy, repairs, today }: { units: Unit[]; rentBy: Map<string, { id: string; status: string; due_date: string; amount: number; paid_amount: number; title: string }>; repairs: R[]; today: string }) {
  const u = units[0];
  if (!u) return <Empty>Собственикът още не ви е свързал с апартамент.</Empty>;
  const rent = rentBy.get(u.id);
  const st = rent ? payStatus(rent as { status: PayStatus; due_date: string }, today) : null;
  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-stretch gap-4">
        <div className="plate px-5 py-4">
          <p className="text-[12px] uppercase tracking-[0.1em] opacity-80">Ет. {u.floor} · вход {u.entrance}</p>
          <p className="font-plate text-[44px] font-extrabold leading-none">ап. {u.number}</p>
        </div>
        <div className="flex min-w-[240px] flex-1 flex-col justify-center rounded-xl border border-line bg-paper px-5 py-4">
          {rent ? (
            <>
              <p className="text-[13px] text-mute">{rent.title} · срок {fmtDate(rent.due_date)}</p>
              <p className="num font-plate text-[32px] font-extrabold leading-tight">{eur(Number(rent.amount) - Number(rent.paid_amount) || rent.amount)}</p>
              <div className="flex items-center gap-3">
                {st && <Tag tone={PAY[st].tone}>{PAY[st].label}</Tag>}
                {st !== "confirmed" && <TextLink href={`/payments#${rent.id}`}>Отбележи плащане</TextLink>}
              </div>
            </>
          ) : (
            <p className="text-mute">Няма наем за този месец.</p>
          )}
        </div>
      </div>
      <Section title="Моите сигнали" action={<TextLink href="/repairs/new">Подай сигнал</TextLink>}>
        <RepairList repairs={repairs} />
      </Section>
    </div>
  );
}
