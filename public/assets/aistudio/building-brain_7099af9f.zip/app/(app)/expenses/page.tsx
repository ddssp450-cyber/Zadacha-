import Link from "next/link";
import { redirect } from "next/navigation";
import { FileText } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { eur, EXPENSE_CATEGORY, fmtDate, isoDay } from "@/lib/vocab";
import { Empty, PageHead, Section, Table, Tag } from "@/components/ui";
import { DocumentForm, ExpenseForm } from "./forms";

const FILE_KIND: Record<string, string> = { photo: "Снимка", before: "Преди", after: "След", report: "Отчет", document: "Документ", invoice: "Фактура" };

export default async function Expenses() {
  const { supabase, building, profile, isOwner } = await meWithBuilding();
  if (profile.role !== "owner" && profile.role !== "builder") redirect("/");

  const [{ data: expenses }, { data: files }, { data: repairs }] = await Promise.all([
    isOwner ? supabase.from("expenses").select("id, amount, category, spent_on, note, file_path, repairs(id, code)").eq("building_id", building.id).order("spent_on", { ascending: false }) : Promise.resolve({ data: [] }),
    supabase.from("files").select("id, path, name, kind, created_at, repair_id, repairs(code)").eq("building_id", building.id).in("kind", ["document", "invoice", "report"]).order("created_at", { ascending: false }),
    isOwner ? supabase.from("repairs").select("id, code, title").eq("building_id", building.id).order("created_at", { ascending: false }) : Promise.resolve({ data: [] }),
  ]);
  const docPaths = [...(files ?? []).map((f) => f.path), ...(expenses ?? []).map((e) => e.file_path).filter((x): x is string => !!x)];
  const signed = docPaths.length ? (await supabase.storage.from("files").createSignedUrls(docPaths, 900)).data ?? [] : [];
  const url = new Map(signed.map((s) => [s.path, s.signedUrl ?? undefined]));

  const list = expenses ?? [];
  const today = isoDay();
  const yearAgo = `${Number(today.slice(0, 4)) - 1}${today.slice(4)}`;
  const byCat = Object.entries(
    list.filter((e) => e.spent_on >= yearAgo).reduce<Record<string, number>>((m, e) => ({ ...m, [e.category]: (m[e.category] ?? 0) + Number(e.amount) }), {}),
  ).sort((a, b) => b[1] - a[1]);
  const maxCat = Math.max(1, ...byCat.map(([, v]) => v));
  const months = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(`${today.slice(0, 7)}-15T12:00:00Z`);
    d.setUTCMonth(d.getUTCMonth() - (5 - i));
    const key = d.toISOString().slice(0, 7);
    return { key, label: d.toLocaleDateString("bg-BG", { month: "short", timeZone: "UTC" }), total: list.filter((e) => e.spent_on.startsWith(key)).reduce((s, e) => s + Number(e.amount), 0) };
  });
  const maxMonth = Math.max(1, ...months.map((m) => m.total));
  const yearTotal = byCat.reduce((s, [, v]) => s + v, 0);

  return (
    <main className="px-4 py-6 sm:px-8">
      <PageHead title={isOwner ? "Разходи и документи" : "Документи"} sub={isOwner ? `${eur(yearTotal)} за последните 12 месеца` : "Отчети, документи и фактури по сградата"} />
      <div className="grid gap-4 2xl:grid-cols-[1fr_340px] 2xl:items-start">
        <div className="grid gap-4">
          {isOwner && (
            <div className="grid gap-4 lg:grid-cols-2">
              <Section title="По категория · 12 месеца">
                {byCat.length === 0 ? <Empty>Няма разходи.</Empty> : (
                  <ul className="grid gap-[2px]">
                    {byCat.map(([k, v]) => (
                      <li key={k} className="grid grid-cols-[110px_1fr_auto] items-center gap-3 py-1 text-[14px]">
                        <span>{EXPENSE_CATEGORY[k] ?? k}</span>
                        <span className="group relative h-5 rounded-r bg-ground" tabIndex={0} aria-label={`${EXPENSE_CATEGORY[k] ?? k}: ${eur(v)}`}>
                          <span className="block h-full rounded-r-[4px] bg-cobalt transition-opacity group-hover:opacity-80" style={{ width: `${(v / maxCat) * 100}%` }} />
                        </span>
                        <span className="num w-[86px] text-right font-semibold">{eur(v)}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </Section>
              <Section title="По месеци">
                <div className="flex h-[150px] items-end gap-[2px] border-b border-line" role="list">
                  {months.map((m) => (
                    <div key={m.key} role="listitem" tabIndex={0} aria-label={`${m.label}: ${eur(m.total)}`} className="group relative flex h-full flex-1 flex-col justify-end outline-none">
                      <span className="pointer-events-none absolute -top-1 left-1/2 z-10 hidden -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md bg-ink px-2 py-1 text-xs text-white group-hover:block group-focus:block">
                        <b className="num">{eur(m.total)}</b> <span className="opacity-75">{m.label}</span>
                      </span>
                      <span className="mx-auto w-full max-w-[44px] rounded-t-[4px] bg-cobalt transition-opacity group-hover:opacity-80" style={{ height: `${Math.max((m.total / maxMonth) * 100, m.total ? 2 : 0)}%` }} />
                    </div>
                  ))}
                </div>
                <div className="mt-1.5 flex gap-[2px] text-center text-xs text-mute">
                  {months.map((m) => <span key={m.key} className="flex-1">{m.label}</span>)}
                </div>
              </Section>
            </div>
          )}

          {isOwner && (
            <Section title="Всички разходи">
              {list.length === 0 ? <Empty>Няма разходи.</Empty> : (
                <Table head={["Дата", "Категория", "Бележка", "Ремонт", "Сума", ""]}>
                  {list.map((e) => {
                    const r = e.repairs as unknown as { id: string; code: string } | null;
                    return (
                      <tr key={e.id}>
                        <td className="num whitespace-nowrap">{fmtDate(e.spent_on, { day: "numeric", month: "short", year: "numeric" })}</td>
                        <td><Tag tone="idle">{EXPENSE_CATEGORY[e.category] ?? e.category}</Tag></td>
                        <td>{e.note || "—"}</td>
                        <td>{r ? <Link href={`/repairs/${r.id}`} className="font-semibold text-cobalt">{r.code}</Link> : "—"}</td>
                        <td className="num whitespace-nowrap text-right font-semibold">{eur(e.amount)}</td>
                        <td>{e.file_path && url.get(e.file_path) && <a href={url.get(e.file_path)} target="_blank" rel="noreferrer" aria-label="Фактура" className="text-cobalt"><FileText className="size-4" /></a>}</td>
                      </tr>
                    );
                  })}
                </Table>
              )}
            </Section>
          )}

          <Section title="Документи">
            {!files?.length ? <Empty>Няма документи.</Empty> : (
              <ul>
                {files.map((f) => (
                  <li key={f.id} className="flex flex-wrap items-center gap-3 border-t border-line py-2.5 first:border-0">
                    <a href={url.get(f.path)} target="_blank" rel="noreferrer" className="inline-flex min-w-0 flex-1 items-center gap-2 font-semibold text-cobalt hover:underline">
                      <FileText className="size-4 shrink-0" /> <span className="truncate">{f.name}</span>
                    </a>
                    <Tag tone="idle">{FILE_KIND[f.kind]}</Tag>
                    {(f.repairs as unknown as { code: string } | null) && <Link href={`/repairs/${f.repair_id}`} className="text-sm text-mute hover:text-cobalt">{(f.repairs as unknown as { code: string }).code}</Link>}
                    <span className="text-sm text-mute">{fmtDate(f.created_at)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        </div>
        <div className="grid gap-4">
          {isOwner && (
            <Section title="Нов разход">
              <ExpenseForm building={building.id} repairs={(repairs ?? []).map((r) => ({ id: r.id, label: `${r.code} ${r.title}` }))} />
            </Section>
          )}
          <Section title="Качи документ"><DocumentForm building={building.id} /></Section>
        </div>
      </div>
    </main>
  );
}
