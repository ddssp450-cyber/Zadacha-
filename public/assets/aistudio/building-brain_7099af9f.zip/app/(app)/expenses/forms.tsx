"use client";
import { ActionForm, FileField } from "@/components/form";
import { Field, input } from "@/components/ui";
import { EXPENSE_CATEGORY } from "@/lib/vocab";
import { addFiles, createExpense } from "../actions";

export function ExpenseForm({ building, repairs }: { building: string; repairs: { id: string; label: string }[] }) {
  return (
    <ActionForm action={createExpense} submit="Запиши разхода">
      <div className="grid grid-cols-2 gap-3">
        <Field label="Сума, €"><input name="amount" inputMode="decimal" required className={`${input} num`} /></Field>
        <Field label="Дата"><input name="spent_on" type="date" className={input} /></Field>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Категория">
          <select name="category" className={input}>
            {Object.entries(EXPENSE_CATEGORY).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </Field>
        <Field label="Ремонт">
          <select name="repair" className={input} defaultValue="">
            <option value="">—</option>
            {repairs.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}
          </select>
        </Field>
      </div>
      <Field label="Бележка"><input name="note" className={input} /></Field>
      <Field label="Фактура"><FileField building={building} multiple={false} /></Field>
    </ActionForm>
  );
}

export function DocumentForm({ building }: { building: string }) {
  return (
    <ActionForm action={addFiles} submit="Качи документите">
      <input type="hidden" name="building" value={building} />
      <Field label="Вид">
        <select name="kind" className={input}>
          <option value="document">Документ</option>
          <option value="invoice">Фактура</option>
          <option value="report">Отчет</option>
        </select>
      </Field>
      <FileField building={building} />
    </ActionForm>
  );
}
