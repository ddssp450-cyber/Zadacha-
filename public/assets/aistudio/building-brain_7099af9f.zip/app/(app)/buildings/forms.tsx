"use client";
import { ActionForm } from "@/components/form";
import { Field, input } from "@/components/ui";
import { createBuilding, createUnit } from "../actions";

export function CreateBuildingForm() {
  return (
    <ActionForm action={createBuilding} submit="Създай сградата">
      <Field label="Име"><input name="name" required className={input} placeholder="ул. Кожух 12" /></Field>
      <Field label="Адрес"><input name="address" className={input} placeholder="Лозенец, София" /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Етажи" hint="по желание"><input name="floors" type="number" min={1} max={40} className={input} /></Field>
        <Field label="Апартаменти на етаж"><input name="per_floor" type="number" min={1} max={20} className={input} /></Field>
      </div>
    </ActionForm>
  );
}

export function CreateUnitForm({ building }: { building: string }) {
  return (
    <ActionForm action={createUnit} submit="Добави апартамент" className="grid gap-3 sm:grid-cols-[1fr_1fr_1fr_1fr_auto] sm:items-end">
      <input type="hidden" name="building" value={building} />
      <Field label="Номер"><input name="number" required className={input} placeholder="14" /></Field>
      <Field label="Етаж"><input name="floor" type="number" required className={input} defaultValue={1} /></Field>
      <Field label="Вход"><input name="entrance" className={input} defaultValue="А" /></Field>
      <Field label="Площ, м²"><input name="area" inputMode="decimal" className={input} /></Field>
    </ActionForm>
  );
}
