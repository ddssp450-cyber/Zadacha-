import { me } from "@/lib/session";
import { Empty, PageHead, Section, Table, TextLink } from "@/components/ui";
import { CreateBuildingForm, CreateUnitForm } from "./forms";

export default async function Buildings() {
  const { supabase, buildings, isOwner } = await me();
  const { data: units } = await supabase
    .from("units")
    .select("id, building_id, number, floor, entrance, area, tenant_id, profiles(full_name, email)")
    .order("floor")
    .order("number");

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-8">
      <PageHead title={isOwner ? "Сгради и апартаменти" : "Моят апартамент"} sub={isOwner ? `${buildings.length} сгради · ${units?.length ?? 0} апартамента` : undefined} />
      <div className="grid gap-4">
        {buildings.map((b) => {
          const list = (units ?? []).filter((u) => u.building_id === b.id);
          return (
            <Section key={b.id} title={`${b.name}${b.address ? ` · ${b.address}` : ""}`}>
              {list.length === 0 ? (
                <Empty>Няма апартаменти.</Empty>
              ) : (
                <Table head={["Ап.", "Етаж", "Вход", "Площ", "Наемател"]}>
                  {list.map((u) => {
                    const t = u.profiles as unknown as { full_name: string; email: string } | null;
                    return (
                      <tr key={u.id} id={`u-${u.id}`}>
                        <td className="font-plate text-[17px] font-bold text-cobalt">{u.number}</td>
                        <td className="num">{u.floor}</td>
                        <td>{u.entrance}</td>
                        <td className="num">{u.area ? `${u.area} м²` : "—"}</td>
                        <td>{t ? <>{t.full_name} <span className="text-mute">· {t.email}</span></> : isOwner ? <TextLink href={`/people?unit=${u.id}`}>Покани наемател</TextLink> : "свободен"}</td>
                      </tr>
                    );
                  })}
                </Table>
              )}
              {isOwner && b && (
                <div className="mt-4 border-t border-line pt-4">
                  <CreateUnitForm building={b.id} />
                </div>
              )}
            </Section>
          );
        })}
        {isOwner && (
          <Section title="Нова сграда">
            <div className="max-w-md"><CreateBuildingForm /></div>
          </Section>
        )}
      </div>
    </main>
  );
}
