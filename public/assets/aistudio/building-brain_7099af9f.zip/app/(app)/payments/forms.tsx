"use client";
import { useState } from "react";
import { Sparkles } from "lucide-react";
import { ActionForm, FileField, Submit } from "@/components/form";
import { btnDanger, btnGhost, Field, input } from "@/components/ui";
import { createPayment, declarePayment, remind, reviewPayment } from "../actions";

export function NewPaymentForm({ units }: { units: { id: string; label: string }[] }) {
  const today = new Date();
  const period = today.toISOString().slice(0, 7);
  return (
    <ActionForm action={createPayment} submit="Създай задължение">
      <Field label="Апартамент">
        <select name="unit" className={input} required defaultValue="">
          <option value="" disabled>Изберете…</option>
          <option value="all">Всички с наематели</option>
          {units.map((u) => <option key={u.id} value={u.id}>{u.label}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Вид">
          <select name="kind" className={input}>
            <option value="rent">Наем</option>
            <option value="bill">Сметка</option>
          </select>
        </Field>
        <Field label="Сума, €"><input name="amount" inputMode="decimal" required className={`${input} num`} /></Field>
      </div>
      <Field label="Основание"><input name="title" className={input} placeholder={`Наем ${period.slice(5)}.${period.slice(0, 4)}`} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Период"><input name="period" type="month" defaultValue={period} className={input} /></Field>
        <Field label="Краен срок"><input name="due_date" type="date" required className={input} /></Field>
      </div>
    </ActionForm>
  );
}

export function ReviewForm({ id }: { id: string }) {
  const [rejecting, setRejecting] = useState(false);
  return (
    <ActionForm action={reviewPayment} className="flex flex-wrap items-center gap-2">
      <input type="hidden" name="id" value={id} />
      {rejecting ? (
        <>
          <input name="note" required autoFocus placeholder="Причина, напр. сумата не съвпада" className={`${input} max-w-[260px] py-1.5 text-sm`} />
          <Submit name="decision" value="reject" className={btnDanger}>Отхвърли</Submit>
          <button type="button" className="text-sm text-mute" onClick={() => setRejecting(false)}>Назад</button>
        </>
      ) : (
        <>
          <Submit name="decision" value="approve" className={btnGhost}>Потвърди</Submit>
          <button type="button" className="text-[13px] font-semibold text-red" onClick={() => setRejecting(true)}>Отхвърли</button>
        </>
      )}
    </ActionForm>
  );
}

export function RemindForm({ id }: { id: string }) {
  return (
    <ActionForm action={remind} className="flex items-center gap-2">
      <input type="hidden" name="id" value={id} />
      <Submit className={btnGhost}>Напомни</Submit>
    </ActionForm>
  );
}

type Extracted = { amount?: number | null; date?: string | null; reference?: string | null; currency?: string | null };

export function DeclareForm({ id, building, owed }: { id: string; building: string; owed: number }) {
  const [paid, setPaid] = useState(String(owed));
  const [extracted, setExtracted] = useState<Extracted | null>(null);
  const [reading, setReading] = useState(false);

  async function read(file: File) {
    if (!/^image\/|application\/pdf/.test(file.type)) return;
    setReading(true);
    const fd = new FormData();
    fd.set("file", file);
    const res = await fetch("/api/extract", { method: "POST", body: fd }).catch(() => null);
    const data = await res?.json().catch(() => null);
    setReading(false);
    if (data?.extracted) {
      setExtracted(data.extracted);
      if (typeof data.extracted.amount === "number" && data.extracted.currency !== "BGN") setPaid(String(data.extracted.amount));
    }
  }

  return (
    <ActionForm action={declarePayment} submit="Отбележи като платено" className="grid gap-3 rounded-lg bg-ground p-3">
      <input type="hidden" name="id" value={id} />
      {extracted && <input type="hidden" name="extracted" value={JSON.stringify(extracted)} />}
      <div className="grid gap-3 sm:grid-cols-[160px_1fr] sm:items-end">
        <Field label="Платена сума, €"><input name="paid" inputMode="decimal" required value={paid} onChange={(e) => setPaid(e.target.value)} className={`${input} num`} /></Field>
        <Field label="Платежно (screenshot или PDF)">
          <FileField building={building} multiple={false} onUploaded={(f) => read(f)} />
        </Field>
      </div>
      {reading && <p className="flex items-center gap-1.5 text-sm text-mute"><Sparkles className="size-4 animate-pulse text-cobalt" /> AI чете платежното…</p>}
      {extracted && (
        <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
          <Sparkles className="size-4 text-cobalt" aria-hidden />
          <span>AI прочете: <b className="num">{extracted.amount ?? "—"} {extracted.currency ?? ""}</b></span>
          <span>дата <b>{extracted.date ?? "—"}</b></span>
          <span className="text-mute">„{extracted.reference ?? "без основание"}“</span>
          <span className="w-full text-xs text-mute">Проверете сумата. Собственикът потвърждава плащането, не AI.</span>
        </p>
      )}
    </ActionForm>
  );
}
