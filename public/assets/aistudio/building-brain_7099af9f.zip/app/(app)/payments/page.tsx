import Link from "next/link";
import { FileText, Sparkles } from "lucide-react";
import { meWithBuilding } from "@/lib/session";
import { eur, fmtDate, isoDay, PAY, payStatus, type PayStatus } from "@/lib/vocab";
import { Empty, PageHead, Section, Table, Tag } from "@/components/ui";
import { DeclareForm, NewPaymentForm, RemindForm, ReviewForm } from "./forms";

type Row = {
  id: string; unit_id: string; title: string; kind: string; amount: number; paid_amount: number; period: string; due_date: string;
  status: PayStatus; proof_path: string | null; proof_extracted: { amount?: number; date?: string; reference?: string } | null;
  review_note: string | null; declared_at: string | null; units: { number: string } | null; profiles: { full_name: string } | null;
};

const FILTERS: [string, string][] = [["all", "Всички"], ["review", "За проверка"], ["overdue", "Просрочени"], ["unpaid", "Неплатени"], ["confirmed", "Платени"]];

export default async function Payments({ searchParams }: { searchParams: Promise<{ status?: string; unit?: string }> }) {
  const { supabase, building, profile, isOwner } = await meWithBuilding();
  const { status = "all", unit } = await searchParams;
  const today = isoDay();

  let q = supabase
    .from("payments")
    .select("id, unit_id, title, kind, amount, paid_amount, period, due_date, status, proof_path, proof_extracted, review_note, declared_at, units(number), profiles(full_name)")
    .eq("building_id", building.id)
    .order("due_date", { ascending: false });
  if (unit) q = q.eq("unit_id", unit);
  const { data } = await q.returns<Row[]>();
  const all = (data ?? []).map((p) => ({ ...p, st: payStatus(p, today) }));
  const rows = all.filter((p) =>
    status === "all" ? true : status === "review" ? p.st === "declared" || p.st === "pending_review" : status === "unpaid" ? p.st === "unpaid" || p.st === "partial" : p.st === status,
  );

  const proofs = rows.map((r) => r.proof_path).filter((x): x is string => !!x);
  const signed = proofs.length ? (await supabase.storage.from("files").createSignedUrls(proofs, 600)).data ?? [] : [];
  const urlOf = new Map(signed.map((s) => [s.path, s.signedUrl ?? undefined]));

  const count = (f: string) => all.filter((p) => (f === "review" ? p.st === "declared" || p.st === "pending_review" : f === "unpaid" ? p.st === "unpaid" || p.st === "partial" : f === "all" ? true : p.st === f)).length;
  const outstanding = all.filter((p) => p.st !== "confirmed").reduce((s, p) => s + Number(p.amount) - Number(p.paid_amount), 0);

  if (!isOwner) {
    const open = all.filter((p) => p.st !== "confirmed");
    const history = all.filter((p) => p.st === "confirmed");
    return (
      <main className="mx-auto max-w-3xl px-4 py-6 sm:px-8">
        <PageHead title="Плащания" sub={outstanding > 0 ? `Дължите ${eur(outstanding)}` : "Нямате задължения"} />
        <div className="grid gap-4">
          {open.length === 0 && <Empty>Всичко е платено и потвърдено.</Empty>}
          {open.map((p) => (
            <section key={p.id} id={p.id} className="scroll-mt-6 rounded-xl border border-line bg-paper p-4 sm:p-5">
              <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{p.title}</p>
                  <p className="text-sm text-mute">срок {fmtDate(p.due_date, { day: "numeric", month: "long" })}</p>
                </div>
                <div className="text-right">
                  <p className="num font-plate text-[26px] font-extrabold leading-none">{eur(p.amount)}</p>
                  <Tag tone={PAY[p.st].tone}>{PAY[p.st].label}</Tag>
                </div>
              </div>
              {p.review_note && p.st !== "declared" && p.st !== "pending_review" && (
                <p className="mb-3 rounded-lg bg-red-soft px-3 py-2 text-sm text-red">Собственикът отхвърли предишното плащане: {p.review_note}</p>
              )}
              {p.st === "declared" || p.st === "pending_review" ? (
                <p className="text-sm text-mute">Декларирахте {eur(p.paid_amount)} на {fmtDate(p.declared_at!)}. Чака потвърждение от собственика.</p>
              ) : (
                <DeclareForm id={p.id} building={building.id} owed={Number(p.amount) - Number(p.paid_amount)} />
              )}
            </section>
          ))}
          <Section title="История">
            {history.length === 0 ? <Empty>Няма потвърдени плащания.</Empty> : (
              <ul>
                {history.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 border-t border-line py-2.5 first:border-0">
                    <span>{p.title}</span>
                    <span className="num font-semibold">{eur(p.paid_amount)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Section>
        </div>
      </main>
    );
  }

  const { data: units } = await supabase.from("units").select("id, number, profiles(full_name)").eq("building_id", building.id).not("tenant_id", "is", null).order("floor");
  return (
    <main className="px-4 py-6 sm:px-8">
      <PageHead title="Плащания" sub={`Неплатено общо ${eur(outstanding)} · ${profile.full_name}`} />
      <div className="grid gap-4 2xl:grid-cols-[1fr_340px] 2xl:items-start">
        <Section
          title={unit ? `Ап. ${rows[0]?.units?.number ?? ""}` : "Задължения"}
          action={unit ? <Link href="/payments" className="text-sm font-semibold text-cobalt">Всички апартаменти</Link> : undefined}
        >
          <nav aria-label="Филтър" className="mb-3 flex flex-wrap gap-1.5">
            {FILTERS.map(([k, label]) => (
              <Link
                key={k}
                href={`/payments?status=${k}${unit ? `&unit=${unit}` : ""}`}
                aria-current={status === k ? "true" : undefined}
                className={`rounded-full px-3 py-1 text-[13px] font-semibold ${status === k ? "bg-cobalt text-white" : "bg-ground text-mute hover:text-ink"}`}
              >
                {label} <span className="num opacity-70">{count(k)}</span>
              </Link>
            ))}
          </nav>
          {rows.length === 0 ? <Empty>Няма плащания в този филтър.</Empty> : (
            <Table head={["Ап.", "Основание", "Наемател", "Сума", "Срок", "Статус", ""]}>
              {rows.map((p) => {
                const proof = p.proof_path ? urlOf.get(p.proof_path) : null;
                const review = p.st === "declared" || p.st === "pending_review";
                return (
                  <tr key={p.id} id={p.id} className="scroll-mt-6 target:bg-amber-soft">
                    <td className="font-plate text-[17px] font-bold text-cobalt">{p.units?.number}</td>
                    <td>
                      <p className="font-semibold">{p.title}</p>
                      {review && (
                        <p className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[12.5px] text-mute">
                          {proof ? <a href={proof} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold text-cobalt hover:underline"><FileText className="size-3.5" />платежно</a> : <span>без файл</span>}
                          {p.proof_extracted && <span className="inline-flex items-center gap-1"><Sparkles className="size-3 text-cobalt" />AI: {p.proof_extracted.amount ?? "—"} €, „{p.proof_extracted.reference ?? "—"}“</span>}
                        </p>
                      )}
                    </td>
                    <td>{p.profiles?.full_name ?? <span className="text-mute">—</span>}</td>
                    <td className="num whitespace-nowrap">
                      {eur(p.amount)}
                      {Number(p.paid_amount) > 0 && Number(p.paid_amount) < Number(p.amount) && <span className="block text-xs text-mute">платени {eur(p.paid_amount)}</span>}
                      {review && <span className="block text-xs text-mute">декл. {eur(p.paid_amount)}</span>}
                    </td>
                    <td className="num whitespace-nowrap">{fmtDate(p.due_date)}</td>
                    <td><Tag tone={PAY[p.st].tone}>{PAY[p.st].label}</Tag></td>
                    <td className="whitespace-nowrap">
                      {review ? <ReviewForm id={p.id} /> : p.st === "overdue" || p.st === "unpaid" || p.st === "partial" ? <RemindForm id={p.id} /> : null}
                    </td>
                  </tr>
                );
              })}
            </Table>
          )}
        </Section>
        <Section title="Ново задължение">
          <NewPaymentForm units={(units ?? []).map((u) => ({ id: u.id, label: `ап. ${u.number} · ${(u.profiles as unknown as { full_name: string } | null)?.full_name ?? ""}` }))} />
        </Section>
      </div>
    </main>
  );
}
