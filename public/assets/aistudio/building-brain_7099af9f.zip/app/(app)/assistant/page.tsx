import { me } from "@/lib/session";
import { aiEnabled } from "@/lib/ai/gemini";
import { Chat } from "@/components/chat";
import { PageHead } from "@/components/ui";

export default async function Assistant() {
  const { building } = await me();
  return (
    <main className="mx-auto max-w-3xl px-4 py-6 sm:px-8">
      <PageHead title="AI асистент" sub="Търси, смята, подготвя чернови и задачи. Записва само след вашето потвърждение." />
      {!aiEnabled() && (
        <p className="mb-4 rounded-lg bg-amber-soft px-3 py-2 text-sm text-[#6b4e00]">AI не е настроен: добавете GEMINI_API_KEY в .env.local и рестартирайте сървъра.</p>
      )}
      <Chat building={building?.id} full />
    </main>
  );
}
