import { NextResponse } from "next/server";
import { me } from "@/lib/session";
import type { Proposal } from "@/lib/ai/tools";
import { createEvent, remind, reviewPayment } from "@/app/(app)/actions";

// Runs a proposal the user explicitly confirmed. Same server actions as the forms, same RLS.
export async function POST(req: Request) {
  const { supabase, building, profile } = await me();
  const p = (await req.json().catch(() => null)) as Proposal | null;
  if (!p || !building) return NextResponse.json({ error: "Невалидно предложение" }, { status: 400 });
  const args = p.args as Record<string, string | boolean | string[] | undefined>;
  const unitId = async (n?: unknown) =>
    n ? (await supabase.from("units").select("id").eq("building_id", building.id).eq("number", String(n)).maybeSingle()).data?.id ?? null : null;

  if (p.type === "event") {
    const fd = new FormData();
    for (const k of ["title", "kind", "date", "time", "description", "recurrence"]) if (args[k]) fd.set(k, String(args[k]));
    if (args.end_time) fd.set("end", String(args.end_time));
    const u = await unitId(args.unit_number);
    if (u) fd.set("unit", u);
    if (args.repair_code) {
      const { data } = await supabase.from("repairs").select("id").eq("code", String(args.repair_code)).maybeSingle();
      if (data) fd.set("repair", data.id);
    }
    const r = await createEvent(null, fd);
    return NextResponse.json(r?.error ? { error: r.error } : { ok: r?.ok, href: "/calendar?view=list" });
  }

  if (p.type === "repair") {
    const { data, error } = await supabase.from("repairs").insert({
      building_id: building.id, title: String(args.title ?? "").slice(0, 200), description: String(args.description ?? ""),
      location: String(args.location ?? ""), unit_id: await unitId(args.unit_number),
      kind: profile.role === "builder" ? "defect" : "repair", reported_by: profile.id,
    }).select("id, code").single();
    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    const paths = ((args.paths as string[]) ?? []).filter((x) => x.startsWith(`${building.id}/`));
    if (paths.length) await supabase.from("files").insert(paths.map((path) => ({ building_id: building.id, repair_id: data.id, path, name: path.split("/").pop()!.slice(37), kind: "before" })));
    return NextResponse.json({ ok: `Заявка ${data.code} е създадена.`, href: `/repairs/${data.id}` });
  }

  if (p.type === "payment_review") {
    const fd = new FormData();
    fd.set("id", String(args.payment_id));
    fd.set("decision", args.approve ? "approve" : "reject");
    if (args.note) fd.set("note", String(args.note));
    const r = await reviewPayment(null, fd);
    return NextResponse.json(r?.error ? { error: r.error } : { ok: r?.ok, href: "/payments" });
  }

  if (p.type === "reminders") {
    let sent = 0;
    for (const id of (args.payment_ids as string[]) ?? []) {
      const fd = new FormData();
      fd.set("id", id);
      const r = await remind(null, fd);
      if (r?.ok) sent++;
    }
    return NextResponse.json({ ok: `Изпратени ${sent} напомняния.`, href: "/payments" });
  }
  return NextResponse.json({ error: "Непознато действие" }, { status: 400 });
}
