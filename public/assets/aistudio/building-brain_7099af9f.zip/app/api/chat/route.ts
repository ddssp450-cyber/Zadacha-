import { NextResponse } from "next/server";
import { me } from "@/lib/session";
import { AiError, generate, textOf, type Content, type Part } from "@/lib/ai/gemini";
import { runTool, toolsFor, type Proposal } from "@/lib/ai/tools";
import { fmtDate, isoDay, ROLE } from "@/lib/vocab";

type Msg = { role: "user" | "assistant"; text: string; images?: { mimeType: string; data: string; path?: string }[] };

export async function POST(req: Request) {
  const { profile, building, supabase } = await me();
  if (!building) return NextResponse.json({ reply: "Още нямате сграда. Създайте я от „Сгради и апартаменти“.", proposals: [] });

  const body = (await req.json().catch(() => null)) as { messages?: Msg[] } | null;
  const msgs = (body?.messages ?? []).slice(-16);
  if (!msgs.length || msgs.at(-1)!.role !== "user") return NextResponse.json({ error: "Празно съобщение" }, { status: 400 });

  const last = msgs.at(-1)!;
  const photoPaths = (last.images ?? []).map((i) => i.path).filter((p): p is string => !!p);
  const contents: Content[] = msgs.map((m, i) => ({
    role: m.role === "user" ? "user" : "model",
    parts: [
      { text: m.text.slice(0, 4000) || "(снимки)" },
      // Images only for the newest turn: keeps requests small; earlier turns stay as text.
      ...(i === msgs.length - 1 ? (last.images ?? []).slice(0, 4).filter((x) => /^image\/|application\/pdf/.test(x.mimeType)).map((x): Part => ({ inlineData: { mimeType: x.mimeType, data: x.data } })) : []),
    ],
  }));

  const today = isoDay();
  const system = [
    `Ти си AI асистентът на Building Brain за сграда „${building.name}“ (${building.address}).`,
    `Говориш с ${profile.full_name}, роля: ${ROLE[profile.role]}. Днес е ${fmtDate(new Date(), { weekday: "long", day: "numeric", month: "long", year: "numeric" })} (${today}), часова зона Europe/Sofia.`,
    "Отговаряй на български, кратко и конкретно. Суми в евро (€), апартаменти като „ап. 7“.",
    "Всеки факт взимай от инструментите. Ако данните липсват, кажи го. Никога не измисляй плащания, хора, суми, дати или извършени действия.",
    "Виждаш само данните, до които потребителят има достъп. Не обещавай повече.",
    "Действия (събития, заявки, потвърждаване на плащания, напомняния) само ПРЕДЛАГАШ с propose_* инструментите. Нищо не е записано, докато потребителят не натисне „Потвърди“. Кажи го ясно и не твърди, че си записал нещо.",
    "Преди да предложиш събитие, провери календара за конфликти (list_events / find_free_slots) и спомени конфликтите.",
    "Изчисления (суми, проценти) прави точно от числата, върнати от инструментите.",
    "Без markdown заглавия и таблици. Кратки редове; списък с „– “ е позволен.",
  ].join("\n");

  const proposals: Proposal[] = [];
  try {
    for (let step = 0; step < 8; step++) {
      const res = await generate({ system, contents, tools: toolsFor(profile.role) });
      contents.push(res);
      const calls = res.parts.filter((p): p is Extract<Part, { functionCall: unknown }> => "functionCall" in p);
      if (!calls.length) return NextResponse.json({ reply: textOf(res) || "Нямам отговор.", proposals });
      const responses: Part[] = [];
      for (const c of calls) {
        const out = await runTool({ supabase, profile, building }, c.functionCall.name, c.functionCall.args ?? {}, proposals, photoPaths);
        responses.push({ functionResponse: { name: c.functionCall.name, response: { result: out } } });
      }
      contents.push({ role: "user", parts: responses });
    }
    return NextResponse.json({ reply: "Задачата е твърде дълга. Опитайте с по-конкретен въпрос.", proposals });
  } catch (e) {
    const msg = e instanceof AiError ? e.message : "AI не отговори. Опитайте отново.";
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}
