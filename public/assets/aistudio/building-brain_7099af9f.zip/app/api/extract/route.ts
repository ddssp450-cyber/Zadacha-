import { NextResponse } from "next/server";
import { me } from "@/lib/session";
import { aiEnabled, generate, textOf } from "@/lib/ai/gemini";

// Reads amount/date/reference from a payment proof. Suggestion only: the tenant edits, the owner confirms.
export async function POST(req: Request) {
  await me();
  if (!aiEnabled()) return NextResponse.json({ error: "AI не е настроен" }, { status: 503 });
  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File) || file.size > 8 * 1024 * 1024 || !/^image\/|application\/pdf/.test(file.type))
    return NextResponse.json({ error: "Нужна е снимка или PDF до 8 MB" }, { status: 400 });
  const data = Buffer.from(await file.arrayBuffer()).toString("base64");
  try {
    const res = await generate({
      json: true,
      contents: [{
        role: "user",
        parts: [
          { inlineData: { mimeType: file.type, data } },
          { text: 'Това е платежно нареждане или банкова разписка. Върни само JSON: {"amount": число в EUR или null, "currency": "EUR"|"BGN"|null, "date": "YYYY-MM-DD" или null, "reference": основание на плащането или null, "payer": наредител или null}. Ако нещо не се вижда ясно, сложи null. Не гадай.' },
        ],
      }],
    });
    const parsed = JSON.parse(textOf(res).replace(/^```json|```$/g, ""));
    return NextResponse.json({ extracted: parsed });
  } catch {
    return NextResponse.json({ error: "Не успях да прочета документа" }, { status: 502 });
  }
}
