"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { browserDb } from "@/lib/supabase-browser";
import { btn, input } from "@/components/ui";

const DEMO = [
  ["owner@demo.bg", "Собственик"],
  ["tenant@demo.bg", "Наемател, ап. 7"],
  ["builder@demo.bg", "Строител"],
  ["tech@demo.bg", "Майстор"],
];

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const { error } = await browserDb().auth.signInWithOtp({ email: email.trim(), options: { shouldCreateUser: true } });
    setBusy(false);
    if (error) setError(error.message);
    else setSent(true);
  }

  async function verify(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const { error } = await browserDb().auth.verifyOtp({ email: email.trim(), token: code.trim(), type: "email" });
    setBusy(false);
    if (error) setError("Кодът не е валиден или е изтекъл. Поискайте нов.");
    else {
      router.replace("/");
      router.refresh();
    }
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-cobalt px-4 py-10">
      <div className="w-full max-w-[400px] settle">
        <div className="plate plate-deep mb-6 px-5 py-4 text-center">
          <p className="font-plate text-[34px] font-extrabold leading-none tracking-[0.02em]">BUILDING BRAIN</p>
          <p className="mt-1.5 text-[13px] text-[#c9d4ee]">Една сграда. Един календар. Един асистент.</p>
        </div>
        <div className="rounded-xl bg-paper p-6 text-ink">
          {!sent ? (
            <form onSubmit={send} className="grid gap-4">
              <h1 className="text-xl font-bold">Вход</h1>
              <label className="grid gap-1 text-sm">
                <span className="font-semibold">Имейл</span>
                <input className={input} type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ime@primer.bg" />
              </label>
              <button className={btn} disabled={busy}>
                {busy && <Loader2 className="size-4 animate-spin" aria-hidden />} Изпрати код за вход
              </button>
              <div className="border-t border-line pt-4">
                <p className="mb-2 text-xs font-bold uppercase tracking-[0.08em] text-mute">Демо сграда</p>
                <div className="grid grid-cols-2 gap-2">
                  {DEMO.map(([m, label]) => (
                    <button key={m} type="button" onClick={() => setEmail(m)} className="rounded-lg border border-line px-2.5 py-2 text-left text-[13px] hover:border-cobalt hover:bg-cobalt-soft">
                      <span className="block font-semibold">{label}</span>
                      <span className="text-mute">{m}</span>
                    </button>
                  ))}
                </div>
              </div>
            </form>
          ) : (
            <form onSubmit={verify} className="grid gap-4">
              <h1 className="text-xl font-bold">Въведете кода</h1>
              <p className="text-sm text-mute">
                Изпратихме 6-цифрен код на <b className="text-ink">{email}</b>.
                {location.hostname === "localhost" || location.hostname === "127.0.0.1" ? (
                  <> Локално писмата са в <a className="font-semibold text-cobalt underline" href="http://127.0.0.1:54324" target="_blank" rel="noreferrer">пощенската кутия на Supabase</a>.</>
                ) : null}
              </p>
              <input className={`${input} num text-center font-plate text-2xl tracking-[0.3em]`} inputMode="numeric" autoComplete="one-time-code" required maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} aria-label="Код за вход" autoFocus />
              <button className={btn} disabled={busy || code.length < 6}>
                {busy && <Loader2 className="size-4 animate-spin" aria-hidden />} Влез
              </button>
              <button type="button" className="text-sm font-semibold text-cobalt" onClick={() => { setSent(false); setCode(""); }}>
                Друг имейл
              </button>
            </form>
          )}
          {error && <p role="alert" className="mt-3 rounded-lg bg-red-soft px-3 py-2 text-sm text-red">{error}</p>}
        </div>
      </div>
    </main>
  );
}
