import type { Metadata } from "next";
import { Sofia_Sans, Sofia_Sans_Condensed } from "next/font/google";
import "./globals.css";

const sofia = Sofia_Sans({ variable: "--font-sofia", subsets: ["latin", "cyrillic"], weight: ["400", "500", "600", "700"] });
const sofiaCond = Sofia_Sans_Condensed({ variable: "--font-sofia-cond", subsets: ["latin", "cyrillic"], weight: ["600", "700", "800"] });

export const metadata: Metadata = {
  title: "Building Brain",
  description: "Една сграда. Един календар. Един интелигентен асистент.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="bg">
      <body className={`${sofia.variable} ${sofiaCond.variable} font-sans antialiased`}>{children}</body>
    </html>
  );
}
