# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Stack

Next.js (App Router) + TypeScript + Tailwind CSS, Supabase (Postgres, auth, private file storage) running locally in Docker. AI: Google Gemini API, called server-side only.

## Users

- **Owner / landlord** — creates buildings, apartments and invitations; confirms payments, approves repair budgets, runs the calendar. Opens the app to learn "what happened, who paid, what's broken, what do I do today".
- **Tenant** — sees only their apartment: what they owe, declares payments with proof, reports faults with photos, follows repairs and events that concern them.
- **Builder** — sees the buildings assigned to them: construction tasks, defects (description, location, deadline), uploads photos/documents/reports, marks defects fixed.
- **Technician** — sees assigned repairs, proposes visit times, logs work, cost, materials, before/after photos.

Each role sees only what it is entitled to; access is enforced in the database, not only in the UI.

## Product Purpose

One place for all communication and management of a building. AI organises the data, summarises the day per role, helps with daily tasks through natural language, and surfaces problems that would otherwise be missed.

## Positioning

"One building. One calendar. One intelligent assistant." Payments, repairs, appliances, construction defects and the calendar share one data model, so the assistant can answer across all of them for the person asking.

## Operating Context

- Rent and bills with exact amount, period, due date; tenants declare payment and upload a screenshot/PDF; owners confirm or reject. Statuses: неплатено, декларирано платено, чака потвърждение, платено — потвърдено, частично платено, просрочено.
- Repairs get a unique number and status; owner approves, assigns a technician, sets deadline and budget, schedules it in the calendar.
- Appliances (климатик, бойлер, асансьор…) have a profile: photo, model, warranty, documents, fault/repair history.
- Calendar: month, week and list views; recurring tasks; every item has owner, date, time, status, description, building/apartment.

## Capabilities and Constraints

- UI language: Bulgarian. Currency: EUR.
- AI never invents data or claims actions it did not take; summaries are built from stored records.
- AI may extract amount/date/reference from a payment proof but never confirms a payment by itself.
- Confirming payments, approving expenses, mass messages and saving important events always require an explicit user confirmation.
- Build order: accounts & roles, payments, repairs, calendar first; AI wired on top.

## Brand Commitments

Name: BUILDING BRAIN. Tagline: "One building. One calendar. One intelligent assistant." The user wants the interface minimal, modern, distinctive and clearly hand-crafted, not template-looking. No logo or colours supplied yet.

## Evidence on Hand

Only the demo building seeded in `supabase/seed.sql`. No real customers, testimonials or metrics exist; do not fabricate any.

## Product Principles

1. Today first: every role lands on what needs their attention now.
2. Nothing happens silently: money and important actions need a human confirmation.
3. Every claim traces to a record the user can open.
4. A role sees its own world, nothing more.
