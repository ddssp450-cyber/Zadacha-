# BUILDING BRAIN — summary (24 Oct 2026)

A website for managing an apartment building in Bulgarian. Owners, tenants, builders and technicians each see their own part of it, and an AI assistant (Google Gemini) summarizes the day and helps with tasks.

## Status

- **Built:** every screen in the spec, the database with per-role access rules, and a demo building.
- **Checks:** typecheck, lint, the production build and the logic tests all pass. Impeccable's design detector found no problems.
- **Access rules:** tested directly in the database for each role. A tenant sees only their own apartment, can't change the amount owed, and only the owner approves repairs, assigns people and sets budgets.
- **Not tested yet:** the app hasn't been run in a browser, and the Gemini connection is untested. Both need the `.env.local` file (see "How to run").

## What it does

| Area | Owner | Tenant | Builder | Technician |
|---|---|---|---|---|
| Dashboard | Building façade of apartment plates with rent status, money for the month, AI "today" list | Own apartment, rent due, own reports | Defects, deadlines, owner's questions | Assigned repairs and visits |
| Payments | Creates rent/bills, checks proof, confirms or rejects, sends reminders | Marks paid, uploads screenshot/PDF; AI pre-fills amount and date | — | — |
| Repairs | Approves, assigns, sets budget and deadline, schedules, records the cost | Reports faults with photos | Reports defects, uploads reports, marks them fixed | Proposes visit times, logs work, cost, materials, before/after photos |
| Calendar | Month, week and list views, recurring tasks, overdue items, approves proposed visit times | Events that concern them | Construction tasks | Own visits |
| Also | Appliances (warranty, service dates, history), expenses with charts, documents, invitations by email | Own appliances | Documents | — |

**AI assistant** (chat on every page, plus a full page):

- Answers from the stored data only, within what that user is allowed to see.
- Can do sums and find free time slots.
- Can draft calendar events, repair requests (including from attached photos), payment confirmations and reminders. Nothing is saved until the user presses **Потвърди**.

## Design

The look was chosen with the Impeccable design skill: Sofia's blue-and-white enamel house-number plates.

- Cobalt `#1d4596` with a white inset border.
- Bulgarian-made font Sofia Sans.
- One set of status colors used on every screen.

## Tech

- Next.js 15, TypeScript and Tailwind 4.
- Supabase: Postgres, login by email code, and private file storage. Runs locally in Docker.
- Gemini, called over REST from the server only.
- The access rules live in the database (`supabase/migrations`).

## How to run

1. Start Docker. Then run `npm install`, `npx supabase start` and `npx supabase db reset`.
2. Create `.env.local` with your Supabase URL, the anon key and your Gemini key. See README.md.
3. Run `npm run dev` and open http://localhost:3000.
4. Log in as `owner@demo.bg`, `tenant@demo.bg`, `builder@demo.bg` or `tech@demo.bg`. The login code arrives at http://127.0.0.1:54324.

## Not done yet

- Run the app with real keys and check every role in the browser.
- Impeccable's final review and DESIGN.md.
- Reminders show inside the app only; they are not sent by email.
- Light mode only.
- Replace the Gemini key that was in the downloaded file.

`node_modules`, build output and `.env.local` are not in this zip.
