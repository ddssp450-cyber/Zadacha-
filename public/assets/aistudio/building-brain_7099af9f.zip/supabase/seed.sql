-- Demo building. All people, money and addresses here are synthetic.
-- Sign in with any of these emails; the code arrives in the local inbox (http://127.0.0.1:54324).

do $$
declare
  u record;
begin
  for u in select * from (values
    ('11111111-0000-0000-0000-000000000001'::uuid, 'owner@demo.bg',   'Мария Иванова',   'owner'),
    ('33333333-0000-0000-0000-000000000001'::uuid, 'builder@demo.bg', 'Иван Петков',     'builder'),
    ('44444444-0000-0000-0000-000000000001'::uuid, 'tech@demo.bg',    'Георги Тодоров',  'technician'),
    ('22222222-0000-0000-0000-000000000004'::uuid, 'ap4@demo.bg',     'Елена Ангелова',  'tenant'),
    ('22222222-0000-0000-0000-000000000005'::uuid, 'ap5@demo.bg',     'Петър Христов',   'tenant'),
    ('22222222-0000-0000-0000-000000000006'::uuid, 'ap6@demo.bg',     'Стефан Колев',    'tenant'),
    ('22222222-0000-0000-0000-000000000007'::uuid, 'tenant@demo.bg',  'Николай Николов', 'tenant'),
    ('22222222-0000-0000-0000-000000000008'::uuid, 'ap8@demo.bg',     'Ива Тодорова',    'tenant'),
    ('22222222-0000-0000-0000-000000000009'::uuid, 'ap9@demo.bg',     'Борис Димитров',  'tenant'),
    ('22222222-0000-0000-0000-000000000010'::uuid, 'ap10@demo.bg',    'Антон Георгиев',  'tenant'),
    ('22222222-0000-0000-0000-000000000011'::uuid, 'ap11@demo.bg',    'Даниела Петрова', 'tenant'),
    ('22222222-0000-0000-0000-000000000012'::uuid, 'ap12@demo.bg',    'Христо Илиев',    'tenant')
  ) as t(id, email, name, role)
  loop
    insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
      confirmation_token, recovery_token, email_change_token_new, email_change)
    values ('00000000-0000-0000-0000-000000000000', u.id, 'authenticated', 'authenticated', u.email, '', now(),
      '{"provider":"email","providers":["email"]}', jsonb_build_object('full_name', u.name, 'role', u.role), now(), now(),
      '', '', '', '');
    insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
    values (gen_random_uuid(), u.id, u.id::text, jsonb_build_object('sub', u.id::text, 'email', u.email), 'email', now(), now(), now());
  end loop;
end $$;

insert into buildings (id, owner_id, name, address) values
  ('b0000000-0000-0000-0000-000000000001', '11111111-0000-0000-0000-000000000001', 'ул. Кожух 12', 'ул. Кожух 12, Лозенец, София');

insert into building_members values
  ('b0000000-0000-0000-0000-000000000001', '33333333-0000-0000-0000-000000000001', 'builder'),
  ('b0000000-0000-0000-0000-000000000001', '44444444-0000-0000-0000-000000000001', 'technician');

insert into units (id, building_id, number, floor, area, tenant_id)
select ('a0000000-0000-0000-0000-0000000000' || lpad(n::text, 2, '0'))::uuid,
       'b0000000-0000-0000-0000-000000000001', n::text, f, a,
       case when n in (1, 2, 3, 13) then null
            else ('22222222-0000-0000-0000-0000000000' || lpad(n::text, 2, '0'))::uuid end
from (values (1,1,48),(2,1,52),(3,1,64),(4,2,58),(5,2,72),(6,2,61),(7,3,58),(8,3,72),(9,3,61),
             (10,4,58),(11,4,72),(12,4,61),(13,4,44)) v(n, f, a);

-- Rent: last month all confirmed; this month a mix of every state.
insert into payments (building_id, unit_id, tenant_id, kind, title, amount, paid_amount, period, due_date, status, declared_at, reviewed_at)
select u.building_id, u.id, u.tenant_id, 'rent', 'Наем ' || to_char(date_trunc('month', current_date) - interval '1 month', 'MM.YYYY'),
       r.amount, r.amount, to_char(date_trunc('month', current_date) - interval '1 month', 'YYYY-MM'),
       (date_trunc('month', current_date) - interval '1 month')::date + 4, 'confirmed', now() - interval '30 days', now() - interval '29 days'
from units u join (values ('4',450),('5',520),('6',480),('7',520),('8',480),('9',500),('10',450),('11',520),('12',480)) r(n, amount) on r.n = u.number;

insert into payments (building_id, unit_id, tenant_id, kind, title, amount, paid_amount, period, due_date, status, declared_at, reviewed_at, proof_extracted)
select u.building_id, u.id, u.tenant_id, 'rent', 'Наем ' || to_char(current_date, 'MM.YYYY'), r.amount, r.paid,
       to_char(current_date, 'YYYY-MM'), current_date + r.due, r.status::payment_status,
       case when r.status <> 'unpaid' then now() - interval '1 day' end,
       case when r.status in ('confirmed', 'partial') then now() - interval '12 hours' end,
       case when r.n = '7' then '{"amount": 520, "date": "демо", "reference": "Наем ап. 7"}'::jsonb end
from units u join (values
  ('4', 450, 450, 'confirmed', -9), ('5', 520, 520, 'declared', -9), ('6', 480, 480, 'confirmed', -9),
  ('7', 520, 520, 'declared', -9), ('8', 480, 480, 'confirmed', -9), ('9', 500, 0, 'unpaid', 6),
  ('10', 450, 450, 'confirmed', -9), ('11', 520, 0, 'unpaid', -9), ('12', 480, 300, 'partial', -9)
) r(n, amount, paid, status, due) on r.n = u.number;

insert into payments (building_id, unit_id, tenant_id, kind, title, amount, period, due_date, status)
select u.building_id, u.id, u.tenant_id, 'bill', 'Такса поддръжка асансьор', 18, to_char(current_date, 'YYYY-MM'), current_date + 3, 'unpaid'
from units u where u.tenant_id is not null;

insert into appliances (id, building_id, unit_id, owner_id, name, kind, model, serial, warranty_until, next_service, notes) values
  ('c0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', null, '11111111-0000-0000-0000-000000000001',
   'Асансьор вход А', 'elevator', 'Schindler 3300', 'SCH-33-8841', current_date + 400, current_date + 12, 'Годишен технически преглед от ГДНСК.'),
  ('c0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000009', '11111111-0000-0000-0000-000000000001',
   'Бойлер', 'boiler', 'Tesy BiLight 80 л', 'TS-80-22917', current_date - 40, null, 'Гаранцията изтече.'),
  ('c0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000009', '11111111-0000-0000-0000-000000000001',
   'Климатик хол', 'ac', 'Daikin Sensira 12', 'DK-12-55031', current_date + 300, current_date + 20, ''),
  ('c0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000005', '11111111-0000-0000-0000-000000000001',
   'Климатик спалня', 'ac', 'Mitsubishi MSZ-HR35', 'MI-35-11840', current_date + 500, current_date + 20, ''),
  ('c0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000004', '11111111-0000-0000-0000-000000000001',
   'Бойлер', 'boiler', 'Ariston Pro1 Eco 50 л', 'AR-50-70412', current_date + 20, null, 'Гаранцията изтича скоро.'),
  ('c0000000-0000-0000-0000-000000000006', 'b0000000-0000-0000-0000-000000000001', null, '11111111-0000-0000-0000-000000000001',
   'Хидрофорна помпа', 'pump', 'Grundfos Hydrojet JP5', 'GR-JP5-0932', current_date + 90, current_date + 45, 'В мазето, до водомера.');

insert into repairs (id, building_id, unit_id, appliance_id, kind, title, description, location, reported_by, assignee_id, status, due_date, budget, cost, materials, result, created_at, resolved_at) values
  ('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', null, 'c0000000-0000-0000-0000-000000000001', 'repair',
   'Вратата на асансьора заяжда', 'Вратата на ет. 2 се затваря бавно.', 'Асансьор, ет. 2', '22222222-0000-0000-0000-000000000004',
   '44444444-0000-0000-0000-000000000001', 'done', current_date - 20, 300, 240, 'Ролка врата, смазка', 'Сменена ролка, вратата работи нормално.', now() - interval '28 days', now() - interval '21 days'),
  ('d0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000005', 'c0000000-0000-0000-0000-000000000004', 'repair',
   'Климатикът не охлажда', 'Духа топъл въздух на режим охлаждане.', 'Ап. 5, спалня', '22222222-0000-0000-0000-000000000005',
   '44444444-0000-0000-0000-000000000001', 'scheduled', current_date + 2, 180, null, '', '', now() - interval '4 days', null),
  ('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000001', null, null, 'defect',
   'Пукнатина в мазилката на стълбището', 'Диагонална пукнатина около 60 см до прозореца.', 'Стълбище, ет. 2–3', '33333333-0000-0000-0000-000000000001',
   '33333333-0000-0000-0000-000000000001', 'in_progress', current_date + 9, 400, null, 'Мрежа, лепило', '', now() - interval '6 days', null),
  ('d0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000009', 'c0000000-0000-0000-0000-000000000002', 'repair',
   'Бойлерът тече от фланеца', 'Капе под бойлера, локва на пода сутрин.', 'Ап. 9, баня', '22222222-0000-0000-0000-000000000009',
   null, 'new', null, null, null, '', '', now() - interval '5 hours', null),
  ('d0000000-0000-0000-0000-000000000005', 'b0000000-0000-0000-0000-000000000001', null, null, 'defect',
   'Теч от покрива над ет. 4', 'След дъжда има мокро петно на тавана пред ап. 11 и 12.', 'Покрив / коридор ет. 4', '33333333-0000-0000-0000-000000000001',
   '33333333-0000-0000-0000-000000000001', 'new', current_date + 5, null, null, '', '', now() - interval '2 hours', null);

insert into comments (repair_id, author_id, body, created_at) values
  ('d0000000-0000-0000-0000-000000000005', '11111111-0000-0000-0000-000000000001', 'Колко е спешно? Да викаме ли покривджия още тази седмица?', now() - interval '1 hour'),
  ('d0000000-0000-0000-0000-000000000003', '33333333-0000-0000-0000-000000000001', 'Мрежата е поставена, утре шпакловка.', now() - interval '1 day');

insert into events (building_id, unit_id, repair_id, title, description, kind, starts_at, ends_at, assignee_id, status, recurrence, created_by) values
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Оглед на асансьора', 'Месечен сервиз по договор.', 'maintenance',
   current_date + time '10:30', current_date + time '11:30', '44444444-0000-0000-0000-000000000001', 'planned', 'monthly', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Почистване на общите части', '', 'cleaning',
   date_trunc('week', current_date) + interval '1 day 9 hours', date_trunc('week', current_date) + interval '1 day 11 hours', null, 'planned', 'weekly', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000005', 'd0000000-0000-0000-0000-000000000002', 'Посещение: климатик ап. 5', 'Диагностика и зареждане с фреон.', 'repair',
   current_date + 2 + time '14:00', current_date + 2 + time '15:30', '44444444-0000-0000-0000-000000000001', 'planned', 'none', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, 'd0000000-0000-0000-0000-000000000003', 'Шпакловка стълбище ет. 2–3', '', 'construction',
   current_date + 1 + time '08:00', current_date + 1 + time '16:00', '33333333-0000-0000-0000-000000000001', 'planned', 'none', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Хидроизолация на покрива — оглед', 'Оферта и оглед с покривджия.', 'construction',
   current_date + 6 + time '10:00', current_date + 6 + time '12:00', '33333333-0000-0000-0000-000000000001', 'planned', 'none', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Годишен технически преглед на асансьора', 'ГДНСК инспектор.', 'inspection',
   current_date + 12 + time '09:00', current_date + 12 + time '10:00', null, 'planned', 'yearly', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000013', null, 'Оглед ап. 13 с кандидат-наемател', '', 'viewing',
   current_date + 4 + time '17:30', current_date + 4 + time '18:00', null, 'planned', 'none', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Смяна на крушките на стълбището', 'Ет. 3 и 4 са тъмни.', 'maintenance',
   current_date - 1 + time '18:00', null, null, 'planned', 'none', '11111111-0000-0000-0000-000000000001'),
  ('b0000000-0000-0000-0000-000000000001', null, null, 'Общо събрание на етажната собственост', 'Бюджет за покрива.', 'meeting',
   current_date + 8 + time '19:00', current_date + 8 + time '20:00', null, 'planned', 'none', '11111111-0000-0000-0000-000000000001');

insert into expenses (building_id, repair_id, category, amount, spent_on, note) values
  ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'repair', 240, current_date - 21, 'Р-0001 ролка врата асансьор'),
  ('b0000000-0000-0000-0000-000000000001', null, 'cleaning', 120, date_trunc('month', current_date)::date + 1, 'Почистване общи части, месечно'),
  ('b0000000-0000-0000-0000-000000000001', null, 'utilities', 64.80, date_trunc('month', current_date)::date + 5, 'Ток общи части'),
  ('b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000003', 'repair', 85, current_date - 3, 'Р-0003 мрежа и лепило'),
  ('b0000000-0000-0000-0000-000000000001', null, 'maintenance', 95, current_date - 35, 'Абонамент асансьор'),
  ('b0000000-0000-0000-0000-000000000001', null, 'repair', 310, current_date - 50, 'Ремонт хидрофор');
