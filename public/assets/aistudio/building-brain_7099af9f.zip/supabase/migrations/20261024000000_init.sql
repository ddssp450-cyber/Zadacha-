-- Building Brain core schema. Access is enforced here with RLS; the UI only mirrors it.

create type app_role as enum ('owner', 'tenant', 'builder', 'technician');
create type payment_status as enum ('unpaid', 'declared', 'pending_review', 'confirmed', 'partial', 'overdue');
create type repair_status as enum ('new', 'approved', 'scheduled', 'in_progress', 'done', 'rejected');
create type event_status as enum ('proposed', 'planned', 'done', 'cancelled');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  email text not null,
  full_name text not null default '',
  phone text,
  role app_role not null default 'owner',
  created_at timestamptz not null default now()
);

create table buildings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references profiles on delete cascade,
  name text not null,
  address text not null default '',
  created_at timestamptz not null default now()
);

create table units (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  number text not null,
  floor int not null default 1,
  entrance text not null default 'А',
  area numeric(7,2),
  tenant_id uuid references profiles on delete set null,
  unique (building_id, entrance, number)
);

create table building_members (
  building_id uuid not null references buildings on delete cascade,
  user_id uuid not null references profiles on delete cascade,
  role app_role not null check (role in ('builder', 'technician')),
  primary key (building_id, user_id)
);

create table invitations (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  unit_id uuid references units on delete cascade,
  email text not null,
  role app_role not null check (role <> 'owner'),
  created_by uuid not null references profiles default auth.uid(),
  accepted_at timestamptz,
  created_at timestamptz not null default now()
);

create table payments (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  unit_id uuid not null references units on delete cascade,
  tenant_id uuid references profiles on delete set null,
  kind text not null default 'rent' check (kind in ('rent', 'bill')),
  title text not null,
  amount numeric(10,2) not null check (amount > 0),
  paid_amount numeric(10,2) not null default 0,
  period text not null default '',
  due_date date not null,
  status payment_status not null default 'unpaid',
  proof_path text,
  proof_extracted jsonb,
  declared_at timestamptz,
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now()
);

create table appliances (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  unit_id uuid references units on delete set null,
  owner_id uuid references profiles on delete set null default auth.uid(),
  name text not null,
  kind text not null default 'other',
  model text not null default '',
  serial text not null default '',
  warranty_until date,
  next_service date,
  photo_path text,
  notes text not null default '',
  created_at timestamptz not null default now()
);

create sequence repair_code_seq;
create table repairs (
  id uuid primary key default gen_random_uuid(),
  code text not null unique default 'Р-' || lpad(nextval('repair_code_seq')::text, 4, '0'),
  building_id uuid not null references buildings on delete cascade,
  unit_id uuid references units on delete set null,
  appliance_id uuid references appliances on delete set null,
  kind text not null default 'repair' check (kind in ('repair', 'defect')),
  title text not null,
  description text not null default '',
  location text not null default '',
  reported_by uuid references profiles on delete set null default auth.uid(),
  assignee_id uuid references profiles on delete set null,
  status repair_status not null default 'new',
  due_date date,
  budget numeric(10,2),
  cost numeric(10,2),
  materials text not null default '',
  result text not null default '',
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

create table events (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  unit_id uuid references units on delete set null,
  repair_id uuid references repairs on delete cascade,
  title text not null,
  description text not null default '',
  kind text not null default 'other'
    check (kind in ('repair', 'construction', 'viewing', 'maintenance', 'cleaning', 'inspection', 'meeting', 'other')),
  starts_at timestamptz not null,
  ends_at timestamptz,
  assignee_id uuid references profiles on delete set null,
  status event_status not null default 'planned',
  recurrence text not null default 'none' check (recurrence in ('none', 'weekly', 'monthly', 'yearly')),
  created_by uuid references profiles on delete set null default auth.uid(),
  created_at timestamptz not null default now()
);

create table expenses (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  repair_id uuid references repairs on delete set null,
  category text not null default 'repair',
  amount numeric(10,2) not null check (amount >= 0),
  spent_on date not null default current_date,
  note text not null default '',
  file_path text,
  created_at timestamptz not null default now()
);

create table files (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  repair_id uuid references repairs on delete cascade,
  appliance_id uuid references appliances on delete cascade,
  path text not null unique,
  name text not null,
  kind text not null default 'photo' check (kind in ('photo', 'before', 'after', 'report', 'document', 'invoice')),
  uploaded_by uuid references profiles on delete set null default auth.uid(),
  created_at timestamptz not null default now()
);

create table comments (
  id uuid primary key default gen_random_uuid(),
  repair_id uuid not null references repairs on delete cascade,
  author_id uuid not null references profiles on delete cascade default auth.uid(),
  body text not null check (length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create table notifications (
  id uuid primary key default gen_random_uuid(),
  building_id uuid not null references buildings on delete cascade,
  user_id uuid not null references profiles on delete cascade,
  body text not null,
  link text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index on units (tenant_id);
create index on payments (unit_id);
create index on payments (tenant_id);
create index on repairs (building_id, status);
create index on events (building_id, starts_at);

-- Access helpers. security definer so policies can call them without recursive RLS.
create function is_owner(b uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from buildings where id = b and owner_id = auth.uid()) $$;

create function is_member(b uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from building_members where building_id = b and user_id = auth.uid()) $$;

create function is_tenant_in(b uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from units where building_id = b and tenant_id = auth.uid()) $$;

create function is_unit_tenant(u uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from units where id = u and tenant_id = auth.uid()) $$;

create function can_see(b uuid) returns boolean language sql stable security definer set search_path = public as
$$ select is_owner(b) or is_member(b) or is_tenant_in(b) $$;

create function my_role() returns app_role language sql stable security definer set search_path = public as
$$ select role from profiles where id = auth.uid() $$;

create function shares_building(other uuid) returns boolean language sql stable security definer set search_path = public as
$$
  with mine as (
    select id b from buildings where owner_id = auth.uid()
    union select building_id from building_members where user_id = auth.uid()
    union select building_id from units where tenant_id = auth.uid()
  ), theirs as (
    select id b from buildings where owner_id = other
    union select building_id from building_members where user_id = other
    union select building_id from units where tenant_id = other
  )
  select exists (select 1 from mine join theirs using (b))
$$;

alter table profiles enable row level security;
alter table buildings enable row level security;
alter table units enable row level security;
alter table building_members enable row level security;
alter table invitations enable row level security;
alter table payments enable row level security;
alter table appliances enable row level security;
alter table repairs enable row level security;
alter table events enable row level security;
alter table expenses enable row level security;
alter table files enable row level security;
alter table comments enable row level security;
alter table notifications enable row level security;

create policy "self or neighbours" on profiles for select using (id = auth.uid() or shares_building(id));
create policy "edit self" on profiles for update using (id = auth.uid()) with check (id = auth.uid() and role = my_role());

create policy "see" on buildings for select using (can_see(id));
create policy "owner creates" on buildings for insert with check (owner_id = auth.uid() and my_role() = 'owner');
create policy "owner edits" on buildings for update using (owner_id = auth.uid());
create policy "owner deletes" on buildings for delete using (owner_id = auth.uid());

create policy "see" on units for select using (is_owner(building_id) or is_member(building_id) or tenant_id = auth.uid());
create policy "owner writes" on units for all using (is_owner(building_id)) with check (is_owner(building_id));

create policy "see" on building_members for select using (can_see(building_id));
create policy "owner writes" on building_members for all using (is_owner(building_id)) with check (is_owner(building_id));

create policy "owner" on invitations for all using (is_owner(building_id)) with check (is_owner(building_id));

create policy "see" on payments for select using (is_owner(building_id) or tenant_id = auth.uid());
create policy "owner writes" on payments for all using (is_owner(building_id)) with check (is_owner(building_id));

create policy "see" on appliances for select using (
  is_owner(building_id) or is_member(building_id) or owner_id = auth.uid()
  or (unit_id is not null and is_unit_tenant(unit_id))
  or (unit_id is null and is_tenant_in(building_id)));
create policy "add" on appliances for insert with check (
  is_owner(building_id) or (owner_id = auth.uid() and unit_id is not null and is_unit_tenant(unit_id)));
create policy "edit" on appliances for update using (is_owner(building_id) or owner_id = auth.uid());
create policy "delete" on appliances for delete using (is_owner(building_id) or owner_id = auth.uid());

create policy "see" on repairs for select using (
  is_owner(building_id) or assignee_id = auth.uid() or reported_by = auth.uid()
  or (kind = 'defect' and is_member(building_id) and my_role() = 'builder')
  or (unit_id is not null and is_unit_tenant(unit_id)));
create policy "report" on repairs for insert with check (reported_by = auth.uid() and can_see(building_id) and status = 'new');
create policy "edit" on repairs for update using (
  is_owner(building_id) or assignee_id = auth.uid()
  or (kind = 'defect' and is_member(building_id) and my_role() = 'builder'));
create policy "owner deletes" on repairs for delete using (is_owner(building_id));

-- Non-owners may move work along, but approval, assignment and money stay with the owner.
create function guard_repair() returns trigger language plpgsql as $$
begin
  if not is_owner(new.building_id) then
    if new.assignee_id is distinct from old.assignee_id or new.budget is distinct from old.budget
       or new.due_date is distinct from old.due_date or new.status in ('approved', 'rejected')
       and new.status is distinct from old.status then
      raise exception 'Само собственикът може да одобрява, назначава и да променя бюджет и срок';
    end if;
  end if;
  if new.status = 'done' and old.status <> 'done' then new.resolved_at = now(); end if;
  return new;
end $$;
create trigger guard_repair before update on repairs for each row execute function guard_repair();

create policy "see" on events for select using (
  is_owner(building_id) or assignee_id = auth.uid()
  or (kind = 'construction' and is_member(building_id) and my_role() = 'builder')
  or (unit_id is not null and is_unit_tenant(unit_id))
  or (unit_id is null and is_tenant_in(building_id) and kind in ('cleaning', 'inspection', 'maintenance', 'meeting', 'other')));
create policy "owner writes" on events for all using (is_owner(building_id)) with check (is_owner(building_id));
create policy "assignee proposes" on events for insert with check (
  assignee_id = auth.uid() and status = 'proposed' and can_see(building_id));
create policy "assignee updates" on events for update using (assignee_id = auth.uid())
  with check (assignee_id = auth.uid() and status in ('proposed', 'done', 'cancelled'));

create policy "owner" on expenses for all using (is_owner(building_id)) with check (is_owner(building_id));

create policy "see" on files for select using (
  is_owner(building_id) or uploaded_by = auth.uid()
  or (repair_id is not null and exists (select 1 from repairs r where r.id = repair_id))
  or (appliance_id is not null and exists (select 1 from appliances a where a.id = appliance_id)));
create policy "upload" on files for insert with check (uploaded_by = auth.uid() and can_see(building_id));
create policy "delete" on files for delete using (is_owner(building_id) or uploaded_by = auth.uid());

create policy "see" on comments for select using (exists (select 1 from repairs r where r.id = repair_id));
create policy "write" on comments for insert with check (author_id = auth.uid() and exists (select 1 from repairs r where r.id = repair_id));

create policy "mine" on notifications for select using (user_id = auth.uid());
create policy "read" on notifications for update using (user_id = auth.uid());
create policy "owner sends" on notifications for insert with check (is_owner(building_id));

-- Tenant declares a payment; only status/proof fields change, never the amount owed.
create function declare_payment(p_id uuid, p_paid numeric, p_proof text, p_extracted jsonb default null)
returns payments language plpgsql security definer set search_path = public as $$
declare p payments;
begin
  select * into p from payments where id = p_id and tenant_id = auth.uid();
  if not found then raise exception 'Плащането не е намерено'; end if;
  if p.status = 'confirmed' then raise exception 'Плащането вече е потвърдено'; end if;
  if p_paid is null or p_paid <= 0 then raise exception 'Невалидна сума'; end if;
  update payments set
    paid_amount = least(p_paid, amount),
    proof_path = coalesce(p_proof, proof_path),
    proof_extracted = coalesce(p_extracted, proof_extracted),
    status = case when p_proof is not null or proof_path is not null then 'pending_review'::payment_status else 'declared'::payment_status end,
    declared_at = now(), review_note = null
  where id = p_id returning * into p;
  return p;
end $$;

-- Owner confirms or rejects. Partial when less than owed was paid.
create function review_payment(p_id uuid, p_approve boolean, p_note text default null)
returns payments language plpgsql security definer set search_path = public as $$
declare p payments;
begin
  select * into p from payments where id = p_id;
  if not found or not is_owner(p.building_id) then raise exception 'Нямате права'; end if;
  update payments set
    status = case when not p_approve then 'unpaid'::payment_status
                  when paid_amount >= amount then 'confirmed'::payment_status else 'partial'::payment_status end,
    paid_amount = case when p_approve then paid_amount else 0 end,
    reviewed_at = now(), review_note = p_note
  where id = p_id returning * into p;
  return p;
end $$;

-- Profile on signup; an open invitation decides role and attaches the unit or membership.
create function attach_invitation(inv invitations, uid uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  update profiles set role = inv.role where id = uid and role <> 'owner';
  if inv.role = 'tenant' and inv.unit_id is not null then
    update units set tenant_id = uid where id = inv.unit_id;
    update payments set tenant_id = uid where unit_id = inv.unit_id and tenant_id is null;
  elsif inv.role in ('builder', 'technician') then
    insert into building_members values (inv.building_id, uid, inv.role) on conflict do nothing;
  end if;
  update invitations set accepted_at = now() where id = inv.id;
end $$;

create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare inv invitations;
begin
  insert into profiles (id, email, full_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
          coalesce((new.raw_user_meta_data->>'role')::app_role, 'owner'));
  for inv in select * from invitations where lower(email) = lower(new.email) and accepted_at is null loop
    update profiles set role = inv.role where id = new.id;
    perform attach_invitation(inv, new.id);
  end loop;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create function invitation_for_existing() returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid;
begin
  select id into uid from profiles where lower(email) = lower(new.email);
  if uid is not null then perform attach_invitation(new, uid); end if;
  return new;
end $$;
create trigger on_invitation after insert on invitations for each row execute function invitation_for_existing();

-- Private storage: an object is readable only when a row the user can see points at it.
insert into storage.buckets (id, name, public) values ('files', 'files', false);

create policy "read linked" on storage.objects for select using (
  bucket_id = 'files' and (
    owner = auth.uid()
    or exists (select 1 from public.files f where f.path = name)
    or exists (select 1 from public.payments p where p.proof_path = name)
    or exists (select 1 from public.appliances a where a.photo_path = name)
    or exists (select 1 from public.expenses e where e.file_path = name)));
create policy "upload to own building" on storage.objects for insert with check (
  bucket_id = 'files' and public.can_see((storage.foldername(name))[1]::uuid));
